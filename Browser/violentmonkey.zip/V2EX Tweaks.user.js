// ==UserScript==
// @name         V2EX Tweaks
// @namespace    https://tampermonkey.net/
// @version      2.5.32
// @description  V2EX 日常增强：可选在新标签页打开帖子与用户主页；用户多标签（批量添加 / 本地存储 / 导入导出 / 智能合并）；回复自动带楼层号；回复嵌套树 + 合并分页；未读新回复标记 + j/k 跳转；高赞阅览室（图片 Lightbox）；Base64 解码（熵过滤）；折叠状态持久化；悬停引用预览；多页加载失败重试；每日签到；Imgur 代理。
// @author       vivaldi@v2ex
// @match        https://v2ex.com/*
// @match        https://www.v2ex.com/*
// @match        https://edge.v2ex.com/*
// @grant        GM_addStyle
// @grant        GM_setClipboard
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_deleteValue
// @grant        GM_addValueChangeListener
// @grant        GM_registerMenuCommand
// @grant        GM_unregisterMenuCommand
// @grant        GM.registerMenuCommand
// @grant        GM_notification
// @grant        GM_xmlhttpRequest
// @grant        GM.xmlHttpRequest
// @connect      v2ex.com
// @connect      www.v2ex.com
// @connect      edge.v2ex.com
// @run-at       document-end
// @noframes
// @license      MIT
// @downloadURL https://update.greasyfork.org/scripts/572364/V2EX%20Tweaks.user.js
// @updateURL https://update.greasyfork.org/scripts/572364/V2EX%20Tweaks.meta.js
// ==/UserScript==

(() => {
  'use strict';

  // 某些 Safari 脚本管理器不识别 @noframes；运行时再兜底一次，避免
  // 签到用的隐藏 iframe 重复启动整套增强脚本或抢占签到锁。
  if (window.top !== window.self) return;

  // =========================
  // 0) 统一配置
  // =========================
  const CONFIG = {
    daily: {
      page: '/mission/daily',
      requestTimeoutMs: 12000,
      verifyRetries: 3,
      verifyIntervalMs: 900,
      // V2EX 的每日奖励按服务器所在时区（UTC+8）跨天，不能用 UTC 日期判断
      timeZone: 'Asia/Shanghai',
      storeKey: 'v2ex_daily_check_ymd_v4',
    },
    tags: {
      storeKey: 'v2ex_user_tags_v2',
      maxTagLength: 24,
      maxTagsPerUser: 12,
      // 墓碑保留时长：超过该时长的删除记录在合并时被清理
      tombstoneTtlMs: 180 * 24 * 60 * 60 * 1000,
      exportVersion: 2,
    },
    b64: {
      minLen: 8,
      targetSelectors: ['.topic_content', '.reply_content'],
      excludeList: [
        'boss', 'bilibili', 'Bilibili', 'Encrypto', 'encrypto',
        'Window10', 'airpords', 'Windows7',
      ],
      // Shannon 熵阈值：低于此值的解码结果视为乱码/误判，直接跳过
      entropyThreshold: 3.0,
    },
    nav: {
      scrollOffsetRatio: 0.22,
    },
    links: {
      // 未设置过时沿用 V2EX 和浏览器原有的链接行为。
      openTopicsAndMembersInNewTab: false,
      storeKey: 'v2ex_open_topics_members_new_tab',
    },
    imgur: {
      // 保持已有代理行为；用户可从脚本管理器菜单关闭。
      proxyEnabled: true,
      storeKey: 'v2ex_imgur_proxy_enabled',
    },
    threadTree: {
      collapseKeyPrefix: 'v2_collapse_',
      readKeyPrefix: 'v2_last_read_',
      pageFetchConcurrency: 4,
      pageFetchTimeoutMs: 15000,
    },
  };

  // =========================
  // 1) 通用小工具
  // =========================
  const log = (...args) => console.log('[V2EX-Enhance]', ...args);
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const randInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

  // 合并增量扫描：祖先节点已覆盖后代时，只扫描一次；定时器不被持续变更推迟。
  function createSubtreeBatch(process, wait = 150) {
    const pending = new Set();
    let timer = null;
    function flush() {
      timer = null;
      const batch = new Set(pending);
      pending.clear();
      for (const node of batch) {
        if (!node.isConnected) continue;
        let covered = false;
        for (let parent = node.parentNode; parent; parent = parent.parentNode) {
          if (batch.has(parent)) { covered = true; break; }
        }
        if (!covered) process(node);
      }
    }
    return node => {
      pending.add(node);
      if (timer === null) timer = setTimeout(flush, wait);
    };
  }

  function notify(title, text, timeout = 3500) {
    try { GM_notification({ title, text, timeout }); } catch (_) {}
  }

  // 不是所有管理器都提供 GM_addStyle（Greasemonkey 只有 GM.addStyle），
  // 缺了它就直接抛异常、整个脚本停在这里——楼层树连跑都没跑。退回自己插 <style>。
  function addStyle(css) {
    try {
      if (typeof GM_addStyle === 'function') return GM_addStyle(css);
    } catch (err) {
      log('GM_addStyle 失败，改用 <style> 注入：', err);
    }
    try {
      const style = document.createElement('style');
      style.textContent = css;
      (document.head || document.documentElement).appendChild(style);
      return style;
    } catch (err) {
      log('样式注入失败：', err);
      return null;
    }
  }

  // V2EX 服务端按 UTC+8 跨天，签到判重必须用同一时区，否则 16:00Z–24:00Z 这段
  // 时间里（北京时间次日 0–8 点）会误判为"今天已签到"而漏签。
  const YMD_FORMATTER = (() => {
    try {
      return new Intl.DateTimeFormat('en-CA', {
        timeZone: CONFIG.daily.timeZone,
        year: 'numeric', month: '2-digit', day: '2-digit',
      });
    } catch (_) { return null; }
  })();

  function ymd(time = Date.now()) {
    if (YMD_FORMATTER) {
      // en-CA 固定输出 YYYY-MM-DD
      return YMD_FORMATTER.format(time);
    }
    return new Date(time + 8 * 60 * 60 * 1000).toISOString().slice(0, 10);
  }

  function isTopicPage() {
    return /^\/t\/\d+(?:\/|$)/.test(location.pathname);
  }

  function debounce(fn, wait) {
    let timer = 0;
    return (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => fn(...args), wait);
    };
  }

  // GM_* 在部分管理器（或 @grant 缺失时）不存在，统一降级到 localStorage
  const GM = {
    get(key, fallback) {
      try { return typeof GM_getValue === 'function' ? GM_getValue(key, fallback) : JSON.parse(localStorage.getItem(key) ?? 'null') ?? fallback; }
      catch (_) { return fallback; }
    },
    set(key, value) {
      try {
        if (typeof GM_setValue === 'function') GM_setValue(key, value);
        else localStorage.setItem(key, JSON.stringify(value));
        return true;
      } catch (err) { log('Storage write failed:', err); return false; }
    },
    onChange(key, handler) {
      try {
        if (typeof GM_addValueChangeListener === 'function') {
          GM_addValueChangeListener(key, (_k, _old, next, remote) => { if (remote) handler(next); });
          return;
        }
      } catch (_) {}
      window.addEventListener('storage', e => { if (e.key === key) handler(undefined); });
    },
  };

  // 原位更新菜单文案，避免注销后重注册把开关挪到菜单末尾。
  // 旧管理器若不支持同 ID 更新，就按首次注册顺序重建所有本脚本菜单。
  const ScriptMenu = (() => {
    const entries = [];
    const register = typeof GM_registerMenuCommand === 'function'
      ? GM_registerMenuCommand
      : globalThis.GM?.registerMenuCommand?.bind(globalThis.GM);
    const unregister = typeof GM_unregisterMenuCommand === 'function'
      ? GM_unregisterMenuCommand
      : globalThis.GM?.unregisterMenuCommand?.bind(globalThis.GM);

    function registerEntry(entry) {
      const caption = unregister ? entry.caption() : entry.fallback;
      entry.id = register(caption, entry.callback) ?? caption;
      entry.currentCaption = caption;
    }

    function add(caption, callback, fallback = caption) {
      if (!register) return () => {};
      const entry = { caption: typeof caption === 'function' ? caption : () => caption, callback, fallback, id: null };
      entries.push(entry);
      try { registerEntry(entry); } catch (err) { log('注册脚本菜单失败：', err); }
      return () => {
        if (!unregister || entry.id === null || entry.currentCaption === entry.caption()) return;
        try {
          const nextCaption = entry.caption();
          const updatedId = register(nextCaption, entry.callback, { id: entry.id }) ?? nextCaption;
          if (updatedId === entry.id) { entry.currentCaption = nextCaption; return; }
          // 不支持原位更新：移除新产生的项，再按固定顺序重新注册全部菜单。
          unregister(updatedId);
          for (const item of entries) if (item.id !== null) unregister(item.id);
          for (const item of entries) registerEntry(item);
        } catch (err) { log('更新脚本菜单失败：', err); }
      };
    }

    return { add, canRefresh: () => !!unregister };
  })();

  function createToggleMenu(label, isEnabled, toggle) {
    let refresh = null;
    return function refreshMenu() {
      if (refresh) { refresh(); return; }
      refresh = ScriptMenu.add(
        () => `${label}：${isEnabled() ? '已开启（点击关闭）' : '已关闭（点击开启）'}`,
        () => {
          if (!toggle()) return;
          if (!ScriptMenu.canRefresh()) notify('V2EX 浏览偏好', `${label}${isEnabled() ? '已开启' : '已关闭'}`);
        },
        `切换${label}`,
      );
    };
  }

  // #rrggbb → [r, g, b]，解析不出来时返回 null 交给调用方决定退路
  function parseHex(hex) {
    const m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
    if (!m) return null;
    const n = parseInt(m[1], 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }

  // 把 hex 颜色转成 rgba，用于标签胶囊的底色/边框（避免依赖 color-mix 的浏览器支持）
  function hexToRgba(hex, alpha) {
    const rgb = parseHex(hex);
    if (!rgb) return `rgba(138, 148, 166, ${alpha})`;
    return `rgba(${rgb[0]}, ${rgb[1]}, ${rgb[2]}, ${alpha})`;
  }

  // 往白色方向混，用于夜间模式下把偏暗的标签色提亮到可读
  function lightenHex(hex, amount) {
    const rgb = parseHex(hex);
    if (!rgb) return hex;
    const mix = c => Math.round(c + (255 - c) * amount);
    return `rgb(${mix(rgb[0])}, ${mix(rgb[1])}, ${mix(rgb[2])})`;
  }

  // Shannon 熵：衡量字符串的信息多样性
  // 低熵 = 字符分布单一，高概率是乱码或短英文单词误判
  function shannonEntropy(str) {
    if (!str.length) return 0;
    const freq = {};
    for (const c of str) freq[c] = (freq[c] || 0) + 1;
    const len = str.length;
    let h = 0;
    for (const count of Object.values(freq)) {
      const p = count / len;
      h -= p * Math.log2(p);
    }
    return h;
  }

  // =========================
  // 2) 样式（合并注入）
  // =========================

  // ── 全站样式：用户标签胶囊 / 编辑气泡 / 管理面板 / Toast ──
  addStyle(`
    :root {
      --v2t-font: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
      --v2t-surface: #fff;
      --v2t-surface-2: #f7f8fa;
      --v2t-text: #2b2f38;
      --v2t-text-dim: #8a94a6;
      --v2t-border: #e6e9f0;
      --v2t-shadow: 0 12px 40px rgba(18, 24, 40, 0.16);
      /* 标签体系专用主色（紫）。刻意避开脚本里代表"系统状态"的蓝
         （NEW / 引用 / b64 / 新回复计数条），两者不该被看成同一类东西。 */
      --v2t-accent: #8b45c9;
      --v2t-accent-soft: rgba(139, 69, 201, 0.15);
    }
    #Wrapper.Night {
      --v2t-surface: #23252b;
      --v2t-surface-2: #2b2e35;
      --v2t-text: #dfe2e8;
      --v2t-text-dim: #8b93a3;
      --v2t-border: #3a3d45;
      --v2t-shadow: 0 12px 40px rgba(0, 0, 0, 0.55);
      --v2t-accent: #c084e8;
      --v2t-accent-soft: rgba(192, 132, 232, 0.2);
    }

    /* ── 胶囊 ──
       圆角药丸 + 前导圆点。同为药丸形的还有右端的楼层号，但一紫一蓝、
       一个贴用户名一个贴行右缘，位置和颜色都分得开 */
    .v2t-slot { display: inline-flex; align-items: center; flex-wrap: wrap; gap: 4px; vertical-align: middle; margin-left: 6px; }
    .v2t-chip {
      display: inline-flex; align-items: center; max-width: 160px;
      padding: 0 8px 0 6px; height: 17px; line-height: 17px;
      font-size: 11px; font-weight: 600; font-family: var(--v2t-font);
      letter-spacing: 0.2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
      border-radius: 9px; cursor: pointer; user-select: none;
      background: var(--v2t-chip-bg); color: var(--v2t-chip-fg);
      border: 1px solid var(--v2t-chip-bd);
      transition: filter 0.12s, transform 0.12s;
    }
    .v2t-chip::before {
      content: ''; flex: none;
      width: 4px; height: 4px; margin-right: 5px;
      border-radius: 50%; background: var(--v2t-chip-dot, currentColor); opacity: 0.9;
    }
    .v2t-chip:hover { filter: brightness(0.94); }
    .v2t-chip:active { transform: scale(0.96); }
    #Wrapper.Night .v2t-chip {
      background: var(--v2t-chip-bg-n); color: var(--v2t-chip-fg-n); border-color: var(--v2t-chip-bd-n);
    }
    /* 未打标签时的 + 按钮平时完全隐藏（且不可点击），仅在该行悬停/聚焦时浮现 */
    .v2t-add {
      display: inline-flex; align-items: center; justify-content: center;
      width: 15px; height: 15px; border-radius: 4px;
      font-size: 12px; line-height: 1; font-family: var(--v2t-font);
      color: var(--v2t-text-dim); border: 1px dashed var(--v2t-border);
      cursor: pointer; user-select: none; opacity: 0; pointer-events: none;
      transition: opacity 0.15s, color 0.15s, border-color 0.15s;
    }
    .v2t-add:focus-visible,
    .cell:hover .v2t-add, .hot-card:hover .v2t-add, .header:hover .v2t-add { opacity: 1; pointer-events: auto; }
    .v2t-add:hover { color: var(--v2t-accent); border-color: var(--v2t-accent); }
    /* 列表页的 .topic_info 只是一行 12px 小字，楼层里那颗 17px 的胶囊会把
       整行撑高、几十条主题叠起来很明显。这里整体缩一档，不改变形状语言。 */
    .topic_info .v2t-slot { margin-left: 5px; gap: 3px; }
    .topic_info .v2t-chip {
      height: 15px; line-height: 15px; font-size: 10px;
      padding: 0 7px 0 5px; border-radius: 8px; max-width: 120px;
    }
    .topic_info .v2t-chip::before { width: 3px; height: 3px; margin-right: 4px; }
    .topic_info .v2t-add { width: 13px; height: 13px; font-size: 11px; border-radius: 3px; }

    /* ── 编辑气泡 ── */
    #v2t-editor {
      position: fixed; z-index: 100001; box-sizing: border-box;
      width: min(356px, calc(100vw - 16px)); max-height: calc(100vh - 16px); overflow-y: auto;
      background: var(--v2t-surface); color: var(--v2t-text);
      border: 1px solid var(--v2t-border); border-radius: 10px;
      box-shadow: var(--v2t-shadow); padding: 12px;
      font-family: var(--v2t-font); font-size: 13px;
      opacity: 0; pointer-events: none; transform: translateY(6px) scale(0.98);
      transition: opacity 0.14s ease, transform 0.14s ease;
    }
    #v2t-editor.visible { opacity: 1; pointer-events: auto; transform: none; }
    #v2t-editor .v2t-ed-head {
      display: flex; align-items: center; gap: 6px;
      margin-bottom: 10px; font-size: 12px; color: var(--v2t-text-dim);
    }
    #v2t-editor .v2t-ed-head img { width: 18px; height: 18px; border-radius: 4px; object-fit: cover; flex: none; }
    #v2t-editor .v2t-ed-head b { color: var(--v2t-text); font-size: 13px; font-weight: 600; }
    #v2t-editor input[type="text"] {
      width: 100%; box-sizing: border-box; height: 30px; padding: 0 9px;
      border: 1px solid var(--v2t-border); border-radius: 6px;
      background: var(--v2t-surface-2); color: var(--v2t-text);
      font-size: 13px; font-family: inherit; outline: none;
      transition: border-color 0.15s, box-shadow 0.15s;
    }
    #v2t-editor input[type="text"]:focus {
      border-color: var(--v2t-accent);
      box-shadow: 0 0 0 3px var(--v2t-accent-soft);
    }
    #v2t-editor .v2t-tag-list { display: flex; flex-direction: column; gap: 7px; }
    #v2t-editor .v2t-tag-row { display: grid; grid-template-columns: minmax(0, 1fr) 30px 24px; gap: 7px; align-items: center; }
    #v2t-editor .v2t-tag-remove {
      display: inline-flex; align-items: center; justify-content: center;
      width: 24px; height: 24px; padding: 0; border: 0; border-radius: 5px;
      background: transparent; color: var(--v2t-text-dim); cursor: pointer; font-size: 17px;
    }
    #v2t-editor .v2t-tag-remove:hover { color: #e0483a; background: rgba(224, 72, 58, 0.08); }
    #v2t-editor .v2t-add-row { margin-top: 8px; padding: 0; border: 0; background: transparent; color: var(--v2t-accent); font: 12px var(--v2t-font); cursor: pointer; }
    #v2t-editor .v2t-add-row:disabled { color: var(--v2t-text-dim); cursor: default; }
    #v2t-editor .v2t-recent { display: flex; flex-wrap: wrap; gap: 5px; margin-top: 10px; }
    #v2t-editor .v2t-recent-item {
      font-size: 11px; padding: 1px 7px; border-radius: 4px; cursor: pointer;
      background: var(--v2t-surface-2); color: var(--v2t-text-dim);
      border: 1px solid var(--v2t-border); max-width: 110px;
      overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    }
    #v2t-editor .v2t-recent-item:hover { color: var(--v2t-accent); border-color: var(--v2t-accent); }
    #v2t-editor .v2t-ed-actions { display: flex; align-items: center; gap: 8px; margin-top: 12px; }
    #v2t-editor .v2t-ed-actions .v2t-spacer { margin-left: auto; }

    .v2t-btn {
      height: 27px; padding: 0 12px; border-radius: 6px;
      border: 1px solid var(--v2t-border); background: var(--v2t-surface);
      color: var(--v2t-text); font-size: 12px; font-family: var(--v2t-font);
      cursor: pointer; transition: background 0.15s, border-color 0.15s, color 0.15s;
    }
    .v2t-btn:hover { background: var(--v2t-surface-2); }
    .v2t-btn:disabled { opacity: 0.5; cursor: default; }
    .v2t-btn.primary { background: var(--v2t-accent); border-color: var(--v2t-accent); color: #fff; }
    .v2t-btn.primary:hover { filter: brightness(1.06); background: var(--v2t-accent); }
    .v2t-btn.danger { color: #e0483a; }
    .v2t-btn.danger:hover { background: rgba(224, 72, 58, 0.08); border-color: rgba(224, 72, 58, 0.4); }

    /* ── 标签颜色：Path 式偏心短弧 ──
       中心保留当前颜色；点击后 8 个固定色位沿上方短弧弹开。候选色不再因
       当前颜色变化而换位，也不做全包围圆或横向面板。弧层挂在 body 上，
       因此不会被编辑气泡、批量栏或管理面板的 overflow 裁切。 */
    .v2t-color-picker {
      position: relative; width: 30px; height: 30px; flex: 0 0 30px;
      display: inline-flex; align-items: center; justify-content: center;
      isolation: isolate;
    }
    .v2t-color-current,
    .v2t-color-option {
      box-sizing: border-box; padding: 0; cursor: pointer;
      appearance: none; -webkit-appearance: none; touch-action: manipulation;
      font-family: var(--v2t-font);
    }
    .v2t-color-current {
      position: relative; z-index: 3; width: 30px; height: 30px;
      display: inline-flex; align-items: center; justify-content: center;
      border: 1px solid transparent; border-radius: 50%;
      background: transparent; color: #fff; box-shadow: none;
      transition: transform 180ms cubic-bezier(.2, .9, .2, 1),
                  background 120ms ease, border-color 120ms ease, box-shadow 120ms ease;
    }
    .v2t-color-current::before {
      content: ''; width: 21px; height: 21px; border-radius: 50%;
      background: var(--v2t-swatch, #9b6cf2);
      box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.24),
                  0 1px 3px rgba(18, 24, 40, 0.18),
                  0 0 0 1px rgba(18, 24, 40, 0.10);
    }
    .v2t-color-current::after {
      content: '×'; position: absolute; inset: 0;
      display: flex; align-items: center; justify-content: center;
      color: #fff; font-size: 14px; line-height: 1; font-weight: 700;
      text-shadow: 0 1px 2px rgba(0, 0, 0, 0.38);
      opacity: 0; transform: rotate(-45deg) scale(0.5);
      transition: opacity 120ms ease, transform 180ms cubic-bezier(.2, .9, .2, 1);
      pointer-events: none;
    }
    .v2t-color-current:hover { background: var(--v2t-surface-2); }
    .v2t-color-current:active { transform: scale(0.90); }
    .v2t-color-picker.open .v2t-color-current {
      transform: scale(0.91); background: var(--v2t-accent-soft);
      border-color: rgba(139, 69, 201, 0.22);
      box-shadow: 0 0 0 3px rgba(139, 69, 201, 0.08);
    }
    .v2t-color-picker.open .v2t-color-current::after {
      opacity: 0.96; transform: rotate(0) scale(1);
    }
    .v2t-color-current:focus-visible,
    .v2t-color-option:focus-visible { outline: 2px solid var(--v2t-accent); outline-offset: 3px; }
    .v2t-color-orbit {
      position: fixed; left: 0; top: 0; z-index: 100003;
      width: 1px; height: 1px; overflow: visible; pointer-events: none;
      --v2t-orbit-surface: rgba(255, 255, 255, 0.93);
      --v2t-orbit-ring: #fff;
      --v2t-orbit-shadow: 0 5px 15px rgba(24, 30, 45, 0.16),
                          0 0 0 1px rgba(24, 30, 45, 0.07);
    }
    .v2t-color-option {
      position: absolute; left: 0; top: 0; width: 30px; height: 30px;
      display: inline-flex; align-items: center; justify-content: center;
      border: 0; border-radius: 50%; background: var(--v2t-orbit-surface);
      box-shadow: var(--v2t-orbit-shadow);
      opacity: 0; pointer-events: none;
      transform: translate(-50%, -50%) scale(0.38);
      transition: transform 125ms cubic-bezier(.4, 0, .6, 1), opacity 70ms ease;
      will-change: transform, opacity;
    }
    .v2t-color-option::before {
      content: ''; width: 20px; height: 20px; border-radius: 50%;
      background: var(--v2t-swatch);
      box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.23),
                  0 0 0 1px rgba(18, 24, 40, 0.08);
      transition: transform 110ms ease, filter 110ms ease;
    }
    .v2t-color-orbit.open .v2t-color-option {
      opacity: 1; pointer-events: auto;
      transform: translate(calc(-50% + var(--v2t-x)), calc(-50% + var(--v2t-y))) scale(1);
      transition-duration: 225ms, 95ms;
      transition-timing-function: cubic-bezier(.18, .89, .28, 1.22), ease;
      transition-delay: calc(var(--v2t-seq) * 7ms), calc(var(--v2t-seq) * 4ms);
    }
    .v2t-color-option:hover::before,
    .v2t-color-option:focus-visible::before { transform: scale(1.12); filter: brightness(1.04); }
    .v2t-color-option[aria-selected="true"] {
      box-shadow: var(--v2t-orbit-shadow),
                  0 0 0 2px var(--v2t-orbit-ring),
                  0 0 0 4px var(--v2t-swatch);
    }
    .v2t-color-option[aria-selected="true"]::after {
      content: '✓'; position: absolute; inset: 0;
      display: flex; align-items: center; justify-content: center;
      color: #fff; font-size: 11px; line-height: 1; font-weight: 800;
      text-shadow: 0 1px 2px rgba(0, 0, 0, 0.40); pointer-events: none;
    }
    :root:has(#Wrapper.Night) .v2t-color-orbit {
      --v2t-orbit-surface: rgba(43, 46, 53, 0.96);
      --v2t-orbit-ring: #23252b;
      --v2t-orbit-shadow: 0 6px 18px rgba(0, 0, 0, 0.36),
                          0 0 0 1px rgba(255, 255, 255, 0.08);
    }
    :root:has(#Wrapper.Night) .v2t-color-current::before,
    :root:has(#Wrapper.Night) .v2t-color-option::before {
      box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.18),
                  0 0 0 1px rgba(255, 255, 255, 0.07);
    }
    @media (prefers-reduced-motion: reduce) {
      .v2t-color-current, .v2t-color-current::after,
      .v2t-color-option, .v2t-color-option::before { transition: none !important; }
    }

    /* ── 管理面板 ── */
    #v2t-manager {
      position: fixed; inset: 0; z-index: 100000;
      background: rgba(20, 24, 34, 0.42); backdrop-filter: blur(2px);
      display: flex; align-items: center; justify-content: center;
      opacity: 0; visibility: hidden; transition: opacity 0.18s, visibility 0.18s;
      font-family: var(--v2t-font);
    }
    #v2t-manager.active { opacity: 1; visibility: visible; }
    #v2t-manager.embedded {
      position: static; inset: auto; z-index: auto;
      display: block; opacity: 1; visibility: visible;
      background: transparent; backdrop-filter: none; transition: none;
    }
    #v2t-manager .v2t-panel {
      width: min(680px, 92vw); max-height: min(76vh, 720px);
      display: flex; flex-direction: column;
      background: var(--v2t-surface); color: var(--v2t-text);
      border-radius: 14px; box-shadow: var(--v2t-shadow);
      transform: translateY(10px) scale(0.99); transition: transform 0.18s ease;
      overflow: hidden;
    }
    #v2t-manager.active .v2t-panel { transform: none; }
    #v2t-manager.embedded .v2t-panel {
      width: 100%; max-height: none; border-radius: 0; box-shadow: none;
      transform: none; transition: none; overflow: visible;
    }
    #v2t-manager .v2t-panel-head {
      display: flex; align-items: center; gap: 10px;
      padding: 14px 16px; border-bottom: 1px solid var(--v2t-border);
    }
    #v2t-manager .v2t-title { font-size: 15px; font-weight: 600; }
    #v2t-manager .v2t-count { font-size: 12px; color: var(--v2t-text-dim); }
    #v2t-manager .v2t-search {
      margin-left: auto; width: 170px; height: 28px; padding: 0 10px;
      border: 1px solid var(--v2t-border); border-radius: 6px;
      background: var(--v2t-surface-2); color: var(--v2t-text);
      font-size: 12px; font-family: inherit; outline: none;
    }
    #v2t-manager .v2t-search:focus { border-color: var(--v2t-accent); }
    #v2t-manager .v2t-list { overflow-y: auto; flex: 1; padding: 4px 0; }
    #v2t-manager.embedded .v2t-list { overflow: visible; }
    #v2t-manager .v2t-row {
      display: flex; align-items: center; gap: 10px;
      padding: 8px 16px; border-bottom: 1px solid var(--v2t-border);
    }
    #v2t-manager .v2t-row:last-child { border-bottom: none; }
    #v2t-manager .v2t-row:hover { background: var(--v2t-surface-2); }
    #v2t-manager .v2t-row a.v2t-user { color: var(--v2t-text); font-size: 13px; text-decoration: none; font-weight: 500; }
    #v2t-manager .v2t-row a.v2t-user:hover { color: var(--v2t-accent); }
    #v2t-manager .v2t-row .v2t-slot { max-width: 310px; }
    #v2t-manager .v2t-row .v2t-time { margin-left: auto; font-size: 11px; color: var(--v2t-text-dim); font-variant-numeric: tabular-nums; }
    #v2t-manager .v2t-row .v2t-row-act {
      font-size: 11px; color: var(--v2t-text-dim); cursor: pointer; padding: 2px 4px; border-radius: 4px;
    }
    #v2t-manager .v2t-row .v2t-row-act:hover { color: var(--v2t-accent); background: var(--v2t-surface); }
    #v2t-manager .v2t-row .v2t-row-act.danger:hover { color: #e0483a; }
    #v2t-manager .v2t-inline-editor { width: 100%; }
    #v2t-manager .v2t-inline-editor-head { display: flex; align-items: center; gap: 8px; margin-bottom: 9px; font-size: 13px; }
    #v2t-manager .v2t-inline-tag-list { display: flex; flex-direction: column; gap: 7px; }
    #v2t-manager .v2t-inline-tag-row { display: grid; grid-template-columns: minmax(0, 1fr) 30px 24px; gap: 7px; align-items: center; }
    #v2t-manager .v2t-inline-tag-row input {
      box-sizing: border-box; width: 100%; height: 29px; padding: 0 7px;
      border: 1px solid var(--v2t-border); border-radius: 5px;
      background: var(--v2t-surface); color: var(--v2t-text); font: 12px var(--v2t-font); outline: none;
    }
    #v2t-manager .v2t-inline-tag-row input:focus { border-color: var(--v2t-accent); }
    #v2t-manager .v2t-inline-remove {
      width: 24px; height: 24px; padding: 0; border: 0; border-radius: 5px;
      background: transparent; color: var(--v2t-text-dim); font-size: 17px; cursor: pointer;
    }
    #v2t-manager .v2t-inline-remove:hover { color: #e0483a; background: rgba(224, 72, 58, 0.08); }
    #v2t-manager .v2t-inline-add { margin-top: 7px; padding: 0; border: 0; background: transparent; color: var(--v2t-accent); font: 12px var(--v2t-font); cursor: pointer; }
    #v2t-manager .v2t-inline-actions { display: flex; gap: 7px; justify-content: flex-end; margin-top: 10px; }
    #v2t-manager.embedded .v2t-row { flex-wrap: wrap; }
    #v2t-manager .v2t-empty { padding: 48px 16px; text-align: center; color: var(--v2t-text-dim); font-size: 13px; }
    #v2t-manager .v2t-panel-foot {
      display: flex; align-items: center; gap: 8px;
      padding: 12px 16px; border-top: 1px solid var(--v2t-border);
      background: var(--v2t-surface-2);
    }
    #v2t-manager .v2t-panel-foot .v2t-spacer { margin-left: auto; }
    #v2t-manager .v2t-merge {
      padding: 12px 16px; border-top: 1px solid var(--v2t-border);
      background: var(--v2t-surface-2); font-size: 12px; line-height: 1.7;
    }
    #v2t-manager .v2t-merge b { color: var(--v2t-accent); font-variant-numeric: tabular-nums; }
    #v2t-manager .v2t-merge .v2t-merge-opts { display: flex; flex-wrap: wrap; gap: 12px; margin: 8px 0 10px; }
    #v2t-manager .v2t-merge label { display: inline-flex; align-items: center; gap: 5px; cursor: pointer; color: var(--v2t-text); }

    /* ── Toast ── */
    #v2t-toast {
      position: fixed; left: 50%; bottom: 32px; z-index: 100002;
      transform: translate(-50%, 10px); opacity: 0; pointer-events: none;
      padding: 8px 16px; border-radius: 20px;
      background: rgba(22, 27, 46, 0.92); color: #eef2ff;
      font-size: 12.5px; font-family: var(--v2t-font);
      box-shadow: 0 6px 24px rgba(0, 0, 0, 0.25);
      transition: opacity 0.18s ease, transform 0.18s ease;
    }
    #v2t-toast.visible { opacity: 1; transform: translate(-50%, 0); }

  `);

  if (isTopicPage()) addStyle(`
    /* ===== 楼层树 ===== */
    :root {
      --indent-width: 18px;
      --rail-gap: 13px;      /* 竖导轨到子回复左边缘的横向距离 = 肘接横线的长度 */
      --rail-width: 1px;     /* 1px 的细线比 2px 干净得多，靠透明度补可见性 */
      --elbow-top: 19px;     /* 肘接横线的高度，对准子回复头像的上半部 */
      --line-color: #b5bfc9;
      --line-hover: #7fa0f5;
      --bg-hover: #fafbff;
      --new-accent: #4a7af0;
      --reply-muted: #687480;
      --reply-surface: var(--box-background-color, #fff);
      --reply-toggle-ink: #8093a5;
      --reply-toggle-bg: #f1f5f8;
      --reply-toggle-hover: #e7eef4;
      /* 未读提示只出现在楼层号：柔和底色增加识别度，不另加边框。 */
      --new-pill-bg: #e8efff;
      --new-pill-fg: #365fbe;
    }

    .box { padding-bottom: 0 !important; }

    /* Avatars are the only nodes; the root keeps its original horizontal position. */
    .reply-tree { position: relative; --reply-indent: 28px; }
    .reply-row { position: relative; margin-left: calc(var(--reply-level) * var(--reply-indent)); }
    .reply-row[hidden], .reply-row [hidden] { display: none !important; }
    .reply-row > .cell { position: relative; min-width: 0; }
    .reply-connectors { position: absolute; inset: 0; width: 100%; height: 100%; pointer-events: none; overflow: visible; }
    .reply-connectors path { fill: none; stroke: var(--reply-connector, #dfe1e4); stroke-width: 1; }
    .reply-parent-highlight { background: var(--bg-hover) !important; }
    .reply-parent-link {
      display: inline-flex; align-items: center; gap: 4px; flex: 0 0 auto;
      padding: 2px 4px; border-radius: 4px; font-size: 12px; line-height: 1.6;
      color: var(--reply-muted) !important; text-decoration: none; white-space: nowrap;
    }
    .reply-parent-link svg { width: 14px; height: 14px; flex: none; }
    .reply-parent-link:hover { color: var(--new-accent) !important; background: var(--bg-hover); }
    .reply-branch-toggle {
      position: absolute; z-index: 1; display: grid; place-items: center; width: 24px; height: 24px;
      border: 0; border-radius: 4px; padding: 0; background: transparent;
      color: var(--reply-toggle-ink); font: 16px/1 system-ui; cursor: pointer; touch-action: manipulation;
    }
    /* Compact visible badge inside the unchanged 24px hit area. */
    .reply-branch-toggle::before {
      content: ''; position: absolute; width: 16px; height: 16px; border-radius: 4px;
      background: var(--reply-toggle-bg);
    }
    .reply-branch-toggle svg { position: relative; width: 12px; height: 12px; stroke-width: 1.8; pointer-events: none; }
    .reply-branch-toggle:hover::before {
      background: var(--reply-toggle-hover);
    }
    .reply-branch-toggle[aria-expanded="false"] svg { transform: rotate(-90deg); }
    .reply-collapsed-hint:hover { color: var(--new-accent); background: var(--bg-hover); }
    .reply-branch-toggle:focus-visible, .reply-collapsed-hint:focus-visible, .reply-parent-link:focus-visible {
      outline: 2px solid var(--new-accent); outline-offset: 2px;
    }
    .reply-collapsed-hint { display: block; padding: 8px 0 0; border: 0; background: transparent; color: var(--reply-muted); font: inherit; font-size: 12px; cursor: pointer; }
    .reply-wrapper > .cell > table { table-layout: fixed; }
    .reply-wrapper .reply_content { overflow-wrap: anywhere; }
    .reply-wrapper .reply_content pre { max-width: 100%; overflow-x: auto; }
    .reply-wrapper .reply_content img { max-width: 100%; height: auto; }
    .reply-wrapper .v2-reply-head { display: grid; grid-template-columns: minmax(0, 1fr) auto; align-items: start; }
    .rh-details { display: flex; align-items: center; flex-wrap: wrap; min-width: 0; gap: 4px 8px; }
    .reply-wrapper .v2-reply-head > .fr { grid-column: 2; grid-row: 1; white-space: nowrap; }
    .reply-wrapper .v2-reply-head .rh-id { max-width: 100%; }
    .reply-wrapper .v2-reply-head .rh-meta {
      flex: 0 1 auto; min-width: 0; flex-wrap: wrap; white-space: normal; gap: 4px 8px;
      color: var(--reply-muted); overflow-wrap: anywhere;
    }
    .reply-wrapper .v2-reply-head .ago, .reply-wrapper .v2-reply-head .fade {
      color: var(--reply-muted); font-size: 12px !important; line-height: 1.5;
    }
    @media (max-width: 600px) {
      .reply-tree { --reply-indent: 24px; }
      .reply-wrapper .v2-reply-head { gap: 4px 8px; }
      .reply-wrapper .v2-reply-head .rh-gap { display: none; }
      .reply-wrapper .v2-reply-head .rh-meta { flex-basis: 100%; }
      .reply-wrapper > .cell > table > tbody > tr > td:first-child { width: 32px; }
    }
    @media (pointer: coarse) {
      .reply-parent-link, .reply-collapsed-hint { min-height: 44px; min-width: 44px; box-sizing: border-box; }
    }

    /* 分隔线与内边距沿用 V2EX 原装（--box-border-color 由 V2EX 定义，夜间模式会自动切换），
       之前自己写死的 #f5f5f5 在白底上几乎看不见 */
    .reply-wrapper .cell {
      padding: 10px !important;
      border-bottom: 0 !important;
      background: transparent;
      transition: background 0.12s;
    }
    .reply-row > .cell::after { content: ''; position: absolute; left: 68px; right: 0; bottom: 0; height: 1px; background: var(--box-border-color, rgba(128,128,128,.228)); }
    @media (max-width: 600px) { .reply-row > .cell::after { left: 52px; } }
    @media (hover: hover) and (pointer: fine) {
      .reply-wrapper > .cell:hover { background-color: var(--bg-hover); }
    }
    .reply-wrapper .avatar {
      display: block;
      width: 100% !important; min-width: 0 !important; max-width: 100% !important;
      height: auto !important; min-height: 0 !important; max-height: none !important;
      aspect-ratio: 1 / 1; object-fit: cover; flex: none;
      max-inline-size: 100% !important;
      border-radius: 4px; margin: 0 auto;
    }
    .reply_content { font-size: 14px; line-height: 1.5; margin-top: 2px; }
    .ago, .fade { font-size: 11px !important; }

    /* ===== 回复头部 =====
       时间保持 V2EX 原来的位置——紧跟用户名，宽度随内容，不占定宽列。
       [用户名 ●标签] [时间 ♥95] ——弹性留白—— [♥ ↩] [19]
       弹性留白吃掉所有宽度差，右端那组按钮 + 楼层号整体贴住行右边缘。 */
    .v2-reply-head { display: flex; align-items: center; gap: 4px 8px; min-width: 0; }
    .v2-reply-head .rh-id {
      display: flex; align-items: center; gap: 4px;
      flex: 0 1 auto; min-width: 0;
    }
    .v2-reply-head .rh-id > strong {
      display: inline-flex; align-items: center;
      flex: 0 1 auto; min-width: 0;
    }
    /* 只让用户名本身省略号截断，标签胶囊永远完整显示 */
    .v2-reply-head .rh-id > strong > a {
      min-width: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }
    .v2-reply-head .rh-id .v2t-slot { flex: 0 0 auto; }
    /* 时间 + ♥ 计数：跟在用户名后面，宽度随内容 */
    .v2-reply-head .rh-meta {
      display: flex; align-items: center; gap: 8px;
      flex: 0 0 auto; white-space: nowrap;
    }
    .v2-reply-head .rh-gap { flex: 1 1 auto; min-width: 8px; }
    /* 感谢/回复按钮 + 楼层号：整体右边缘贴住行的右边缘（同 V2EX 原样） */
    .v2-reply-head > .fr {
      float: none !important;
      display: inline-flex; align-items: center;
      flex: 0 0 auto; margin: 0 !important;
    }
    /* 普通楼层号完全沿用 V2EX 原生样式；未读仅在原有数字上叠加颜色。
       外扩的浅色底不占布局空间，字号、字重和内边距都保持原样。 */
    .cell.reply-new .fr .no,
    .cell.reply-new:hover .fr .no {
      color: var(--new-pill-fg) !important;
      background: var(--new-pill-bg) !important;
      box-shadow: 0 0 0 2px var(--new-pill-bg);
    }

    #v2ex-new-count-bar {
      padding: 6px 12px;
      background: linear-gradient(90deg, #eef2ff 0%, #f8f9ff 100%);
      border-bottom: 1px solid #dde5ff;
      border-radius: 4px 4px 0 0;
      font-size: 12px; color: #6680cc;
      display: flex; align-items: center; gap: 6px;
      user-select: none;
    }
    #v2ex-new-count-bar .ncb-dot { width:6px; height:6px; background:var(--new-accent); border-radius:50%; flex-shrink:0; }
    #v2ex-new-count-bar strong { color: var(--new-accent); font-weight: 700; }
    #v2ex-new-count-bar .ncb-hint { margin-left: auto; opacity: 0.5; font-size: 11px; }

    #v2ex-loading-bar {
      padding: 8px; background: #fff;
      text-align: center; border-bottom: 1px solid #eee;
      font-size: 12px; color: #999;
    }
    .cell[style*="text-align: center"], #bottom-pagination, a[name="last_page"] { display: none; }

    /* ── 多页加载失败重试横幅 ── */
    #v2ex-retry-banner {
      padding: 8px 14px;
      background: #fff8e6; border-bottom: 1px solid #ffe0a0;
      border-radius: 4px 4px 0 0;
      font-size: 12px; color: #a06000;
      display: flex; align-items: center; gap: 10px;
    }
    #v2ex-retry-banner button {
      padding: 2px 10px;
      border: 1px solid #f0b030; border-radius: 4px;
      background: #fff; color: #a06000;
      cursor: pointer; font-size: 12px;
      transition: background 0.15s;
    }
    #v2ex-retry-banner button:hover { background: #fff8e6; }
    #v2ex-retry-banner button:disabled { opacity: 0.5; cursor: default; }

    /* ===== j/k 导航 HUD ===== */
    #v2ex-nav-hud {
      position: fixed; bottom: 28px; right: 28px; z-index: 99998;
      display: flex; align-items: center; gap: 6px;
      padding: 6px 14px 6px 10px;
      background: rgba(22,27,46,0.90); color: #dde4ff;
      border-radius: 20px; font-size: 12px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      letter-spacing: 0.3px; backdrop-filter: blur(8px);
      box-shadow: 0 4px 20px rgba(0,0,0,0.25), 0 0 0 1px rgba(255,255,255,0.06);
      pointer-events: none; opacity: 0;
      transform: translateY(8px) scale(0.97);
      transition: opacity 0.18s ease, transform 0.18s ease;
    }
    #v2ex-nav-hud.visible { opacity: 1; transform: translateY(0) scale(1); }
    #v2ex-nav-hud .hud-arrow { font-size: 13px; opacity: 0.7; }
    #v2ex-nav-hud .hud-label { font-size: 10px; font-weight: 700; letter-spacing: 1px; color: #7fa8ff; opacity: 0.8; }
    #v2ex-nav-hud .hud-count { font-weight: 600; color: #c5d5ff; font-variant-numeric: tabular-nums; }
    #v2ex-nav-hud .hud-sep { opacity: 0.2; }
    #v2ex-nav-hud .hud-hint { opacity: 0.35; font-size: 11px; font-family: monospace; }
    .reply-nav-active > .cell { outline: 2px solid rgba(74,122,240,0.50) !important; outline-offset: -2px; transition: outline 0.15s ease; }

    /* ===== Base64 解码 ===== */
    .v2-b64-wrap {
      word-break: break-all;
      position: relative;
      display: inline;
    }
    .v2-b64-link { color: #4a7af0 !important; text-decoration: none; }
    .v2-b64-link:hover { color: #3060d8 !important; text-decoration: underline; }
    .v2-b64-plain {
      background: rgba(74, 122, 240, 0.08);
      border-radius: 3px;
      padding: 0 3px;
      color: #3a5ab8;
      cursor: default;
    }
    .v2-b64-plain:hover { background: rgba(74, 122, 240, 0.14); }
    .v2-b64-mark {
      display: inline-block;
      font-size: 9px; font-weight: 700; font-style: normal;
      color: #8aa8f8; border: 1px solid #d0defe; border-radius: 2px;
      padding: 0 3px; line-height: 13px;
      vertical-align: middle; position: relative; top: -1px;
      margin-right: 4px; cursor: default; user-select: none;
      text-decoration: none !important; letter-spacing: 0.2px;
    }
    .v2-b64-actions {
      display: none;
      position: absolute;
      top: -22px;
      right: 0;
      align-items: center;
      background: #fff;
      border: 1px solid #c8d8ff;
      border-radius: 4px;
      overflow: hidden;
      box-shadow: 0 1px 6px rgba(74,122,240,0.13);
      z-index: 10;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    }
    .v2-b64-action {
      font-size: 10px;
      padding: 1px 7px;
      color: #4a7af0;
      cursor: pointer;
      white-space: nowrap;
      line-height: 17px;
      user-select: none;
    }
    .v2-b64-action + .v2-b64-action { border-left: 1px solid #dbe5ff; }
    .v2-b64-wrap:hover .v2-b64-actions { display: inline-flex; }
    .v2-b64-action:hover { background: #eef2ff; }
    .v2-b64-action.copied { color: #52c41a; }

    /* ===== 悬停引用预览 ===== */
    #v2ex-ref-preview {
      position: fixed; z-index: 99997;
      background: #fff;
      border: 1px solid #e4e8f0; border-radius: 8px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.12);
      padding: 10px 14px; max-width: 360px;
      font-size: 13px; line-height: 1.5;
      pointer-events: none;
      opacity: 0; transform: translateY(4px);
      transition: opacity 0.15s, transform 0.15s;
    }
    #v2ex-ref-preview.visible { opacity: 1; transform: translateY(0); }
    .rp-header { display: flex; align-items: center; gap: 6px; margin-bottom: 6px; font-size: 12px; }
    .rp-avatar { width: 16px; height: 16px; border-radius: 3px; object-fit: cover; flex: none; }
    .rp-name { font-weight: 600; color: #444; }
    .rp-floor { color: #aaa; font-size: 11px; }
    .rp-content {
      color: #333; max-height: 120px; overflow: hidden;
      -webkit-mask-image: linear-gradient(180deg, #000 70%, transparent 100%);
      mask-image: linear-gradient(180deg, #000 70%, transparent 100%);
    }
    .v2-ref-link {
      color: var(--new-accent);
      text-decoration: underline; text-decoration-style: dotted;
      text-underline-offset: 2px; cursor: pointer;
    }

    /* ===== Lightbox ===== */
    #v2ex-lightbox {
      position: fixed; inset: 0;
      background: rgba(0,0,0,0.85); z-index: 999999;
      display: flex; align-items: center; justify-content: center;
      cursor: zoom-out; opacity: 0; visibility: hidden;
      transition: opacity 0.2s, visibility 0.2s;
    }
    #v2ex-lightbox.active { opacity: 1; visibility: visible; }
    #v2ex-lightbox img {
      max-width: 92vw; max-height: 92vh;
      object-fit: contain; border-radius: 4px;
      box-shadow: 0 8px 40px rgba(0,0,0,0.5);
      pointer-events: none;
    }

    /* ===== 主题操作：批量标签 / 高赞阅览室 ===== */
    .v2t-bulk-panel {
      display: flex; align-items: center; flex-wrap: wrap; gap: 8px;
      font-family: var(--v2t-font); color: var(--v2t-text);
    }
    .v2t-bulk-panel .v2t-bulk-count { color: var(--v2t-text-dim); font-size: 12px; white-space: nowrap; }
    .v2t-bulk-panel input {
      box-sizing: border-box; height: 28px; padding: 0 8px;
      border: 1px solid var(--v2t-border); border-radius: 5px;
      background: var(--v2t-surface); color: var(--v2t-text); font: 12px var(--v2t-font); outline: none;
    }
    .v2t-bulk-panel input { width: 150px; }
    .v2t-bulk-panel input:focus { border-color: var(--v2t-accent); }
    .v2t-bulk-panel .v2t-color-picker { margin: -2px 2px; }

    #hot-overlay {
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(240,242,245,0.95); z-index: 99999;
      display: flex; justify-content: center; align-items: flex-start;
      overflow-y: scroll; opacity: 0; visibility: hidden;
      transition: opacity 0.15s ease;
    }
    #hot-overlay.active { opacity: 1; visibility: visible; }
    .hot-container {
      width: 92%; max-width: 1000px;
      margin: 30px auto 80px auto;
      background: #fff; border-radius: 8px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.08);
      overflow: hidden; padding: 0;
    }
    .hot-card {
      background: #fff; padding: 14px 24px;
      border-bottom: 1px solid #f0f0f0;
      display: flex; flex-direction: column;
      transition: background 0.1s;
    }
    .hot-card:last-child { border-bottom: none; }
    .hot-card:hover { background: #fafafa; }
    .rank-1 { border-left: 3px solid #faad14; background: linear-gradient(90deg, #fffdf5 0%, #fff 100%); }
    .rank-2 { border-left: 3px solid #ccc; }
    .rank-3 { border-left: 3px solid #d48806; }
    .card-header-row { display: flex; align-items: center; margin-bottom: 6px; font-size: 12px; }
    .user-avatar {
      display: block;
      width: 18px; min-width: 18px; max-width: 18px;
      height: 18px; min-height: 18px; max-height: 18px;
      aspect-ratio: 1 / 1; object-fit: cover; flex: none;
      max-inline-size: none; border-radius: 3px; margin-right: 8px;
    }
    .user-name { font-weight: 600; color: #444; text-decoration: none; margin-right: 8px; }
    .floor-tag {
      background: #f5f5f5; color: #aaa; padding: 0 5px; border-radius: 3px;
      margin-right: 10px; cursor: pointer; font-size: 11px; height: 18px; line-height: 18px;
    }
    .floor-tag:hover { background: #e6f7ff; color: #1890ff; }
    .time-tag { color: #ddd; margin-right: auto; transform: scale(0.9); transform-origin: left; }
    .likes-pill { font-size: 12px; font-weight: 600; padding: 0 6px; }
    .rank-1 .likes-pill { color: #faad14; }
    .rank-normal .likes-pill { color: #ff6b6b; opacity: 0.8; }
    .card-content { font-size: 14px; line-height: 1.6; color: #222; word-wrap: break-word; padding-left: 26px; }
    .card-content p { margin: 0 0 5px 0; }
    .card-content img { max-width: 100%; max-height: 350px; border-radius: 4px; margin: 5px 0; display: block; cursor: zoom-in; }
    .card-content pre { padding: 10px; background: #f8f8f8; border: 1px solid #eee; border-radius: 3px; font-size: 12px; margin: 8px 0; }
    #hot-overlay::-webkit-scrollbar { width: 4px; }
    #hot-overlay::-webkit-scrollbar-thumb { background: #ddd; border-radius: 2px; }

    /* ===== 夜间模式适配 ===== */
    #Wrapper.Night {
      --reply-connector: #484c52;
      --line-color: #50555e;
      --line-hover: #6c8fe8;
      --bg-hover: #2a2d34;
      --new-accent: #6f97ff;
      --reply-muted: #a4adb9;
      --reply-surface: var(--box-background-color, #23252b);
      --reply-toggle-ink: #9aaebe;
      --reply-toggle-bg: #303942;
      --reply-toggle-hover: #394652;
      --new-pill-bg: #303d59;
      --new-pill-fg: #b4c8ff;
    }
    #Wrapper.Night .reply-wrapper .cell { border-bottom-color: #303239 !important; }
    /* 夜间仅调整未读色值，普通楼层号仍交给站点主题。 */
    #Wrapper.Night .cell.reply-new .fr .no,
    #Wrapper.Night .cell.reply-new:hover .fr .no {
      color: var(--new-pill-fg) !important;
      background: var(--new-pill-bg) !important;
    }
    #Wrapper.Night .reply-collapsed-hint { color: var(--reply-muted); }
    #Wrapper.Night #v2ex-new-count-bar {
      background: linear-gradient(90deg, #262b3a 0%, #23252b 100%);
      border-bottom-color: #343a4d; color: #93a6d8;
    }
    #Wrapper.Night #v2ex-loading-bar { background: #23252b; border-bottom-color: #303239; color: #7b818c; }
    #Wrapper.Night #v2ex-retry-banner { background: #33291a; border-bottom-color: #5a4520; color: #e0b25e; }
    #Wrapper.Night #v2ex-retry-banner button { background: #2a2d34; border-color: #5a4520; color: #e0b25e; }
    #Wrapper.Night #v2ex-ref-preview { background: #23252b; border-color: #3a3d45; box-shadow: 0 4px 20px rgba(0,0,0,0.5); }
    #Wrapper.Night .rp-name { color: #dfe2e8; }
    #Wrapper.Night .rp-content { color: #c2c7d0; }
    #Wrapper.Night .v2-b64-plain { background: rgba(111,151,255,0.14); color: #9fb8ff; }
    #Wrapper.Night .v2-b64-actions { background: #23252b; border-color: #3a4a6d; }
    #Wrapper.Night .v2-b64-action { color: #8fabff; }
    #Wrapper.Night .v2-b64-action:hover { background: #2c3346; }
    #Wrapper.Night #hot-overlay { background: rgba(16,18,22,0.94); }
    #Wrapper.Night .hot-container { background: #23252b; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }
    #Wrapper.Night .hot-card { background: #23252b; border-bottom-color: #303239; }
    #Wrapper.Night .hot-card:hover { background: #2a2d34; }
    #Wrapper.Night .rank-1 { background: linear-gradient(90deg, #2e2a1d 0%, #23252b 100%); }
    #Wrapper.Night .user-name { color: #dfe2e8; }
    #Wrapper.Night .card-content { color: #d3d7de; }
    #Wrapper.Night .card-content pre { background: #1c1e23; border-color: #303239; }
    #Wrapper.Night .floor-tag { background: #2b2e35; color: #7b818c; }
    @media (prefers-reduced-motion: reduce) {
      .reply-wrapper .cell, .reply-parent-link,
      .reply-branch-toggle, .reply-branch-toggle svg, .reply-collapsed-hint {
        transition: none !important;
      }
    }
  `);

  // =========================
  // 3) 功能A：每日自动签到
  // =========================
  const Daily = (() => {
    const CLAIMED_RE = /每日登录奖励已(?:领取|发放)|今天的登录奖励已经领取过了(?:哦)?|今天已经领取|已成功领取每日登录奖励|成功领取每日登录奖励|奖励已发放/i;
    // 已领取的任务页会展示连续登录天数，且不再渲染领取按钮
    const CONSECUTIVE_RE = /已连续登录\s*\d+\s*天/;
    const REJECTED_RE = /浏览器有一些奇奇怪怪的设置|请用一个干净安装的浏览器重试/i;

    // 网络抖动/限流属于可重试错误，与"页面结构变了""登录失效"区分开，
    // 避免一次超时就弹一个失败通知并放弃当天签到。
    class RetryableError extends Error {}

    let inFlight = null;
    let retryTimer = 0;
    let networkFailures = 0;
    // Only a server confirmation in this document may skip another check.
    const confirmedDays = new Set();
    function markConfirmed(key, day, member) {
      confirmedDays.add(`${key}:${day}`);
      GM.set(key, day);
      if (currentMember() === member) {
        for (const link of document.querySelectorAll?.('a[href="/mission/daily"]') || []) {
          link.textContent = '今日登录奖励已领取';
        }
      }
    }
    function retryAfter(ms) {
      clearTimeout(retryTimer);
      retryTimer = setTimeout(run, ms);
    }

    function currentMember(doc = document) {
      const href = doc.querySelector('#Top a[href^="/member/"]')?.getAttribute('href');
      try { return href ? decodeURIComponent(new URL(href, location.origin).pathname.slice('/member/'.length)).toLowerCase() : ''; }
      catch (_) { return ''; }
    }

    function verifyMember(doc, member) {
      if (currentMember(doc) !== member) throw new Error('签到页面账号与当前标签页不一致，已停止领取');
    }

    function isSafari() {
      // Safari 不允许扩展后台请求改写 Referer；V2EX 领取接口又会
      // 校验该字段，需要走真实的同源页面跳转。
      return /AppleWebKit/i.test(navigator.userAgent) && /Apple Computer/i.test(navigator.vendor || '');
    }

    async function requestTextWithFetch(target, referer) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), CONFIG.daily.requestTimeoutMs);
      try {
        const options = {
          method: 'GET',
          credentials: 'include',
          cache: 'no-store',
          redirect: 'follow',
          headers: { Accept: 'text/html,application/xhtml+xml' },
          signal: controller.signal,
        };
        if (referer) options.referrer = new URL(referer, location.origin).href;

        const response = await fetch(target.href, options);
        if (!response.ok) throw new RetryableError(`HTTP ${response.status} for ${target.pathname}`);
        return { text: await response.text(), finalUrl: response.url || target.href };
      } catch (err) {
        if (err instanceof RetryableError) throw err;
        const reason = err?.name === 'AbortError' ? '请求超时' : '请求失败';
        throw new RetryableError(`${reason}：${target.pathname}`);
      } finally {
        clearTimeout(timer);
      }
    }

    function requestText(url, referer) {
      const target = new URL(url, location.origin);
      if (target.origin !== location.origin) return Promise.reject(new Error('拒绝跨站签到请求'));
      // Keep every request in this page's cookie jar, including Firefox Containers.
      return requestTextWithFetch(target, referer);
    }
    function parseHtml(html) { return new DOMParser().parseFromString(html, 'text/html'); }

    function pageText(doc) {
      return (doc.body?.textContent || '').replace(/\s+/g, ' ').trim();
    }

    function isSignedOut(doc, finalUrl = location.href) {
      let finalPath = '';
      try { finalPath = new URL(finalUrl, location.origin).pathname; } catch (_) {}
      if (finalPath.startsWith('/signin')) return true;
      const signin = doc.querySelector('#Top a[href^="/signin"], form[action^="/signin"]');
      const member = doc.querySelector('#Top a[href^="/member/"], #Top a[onclick*="/signout?once="]');
      return !!signin && !member;
    }

    function alreadyRedeemed(doc) {
      if (doc.querySelector('#Main .fa-ok-sign')) return true;
      const text = pageText(doc);
      if (CLAIMED_RE.test(text)) return true;
      // 兜底：任务页已渲染连续登录天数却没有领取入口 → 今日已领取
      return CONSECUTIVE_RE.test(text) && !findRedeemUrl(doc);
    }

    function findRedeemUrl(doc) {
      const selectors = [
        'a[href*="/mission/daily/redeem"]',
        'form[action*="/mission/daily/redeem"]',
        '[onclick*="/mission/daily/redeem"]',
      ];
      for (const el of doc.querySelectorAll(selectors.join(','))) {
        const source = [el.getAttribute('href'), el.getAttribute('action'), el.getAttribute('onclick')]
          .filter(Boolean).join(' ');
        const match = source.match(/\/mission\/daily\/redeem\?[^'"<>\s)]*\bonce=([A-Za-z0-9_-]+)/i);
        if (match?.[1]) return `/mission/daily/redeem?once=${encodeURIComponent(match[1])}`;
      }

      // 兼容领取地址被放在内联脚本或转义 HTML 中的旧版页面。
      const match = (doc.documentElement?.innerHTML || '')
        .replaceAll('&amp;', '&')
        .match(/\/mission\/daily\/redeem\?[^'"<>\s)]*\bonce=([A-Za-z0-9_-]+)/i);
      if (match?.[1]) return `/mission/daily/redeem?once=${encodeURIComponent(match[1])}`;
      return null;
    }

    async function loadPage(url, referer) {
      const response = await requestText(url, referer);
      const doc = parseHtml(response.text);
      return { ...response, doc };
    }

    function validateRedeemUrl(redeemUrl) {
      const target = new URL(redeemUrl, location.origin);
      if (target.origin !== location.origin || target.pathname !== '/mission/daily/redeem' || !target.searchParams.get('once')) {
        throw new Error('领取地址无效');
      }
      return target;
    }

    function claimWithDailyFrame(page, member) {
      const dailyUrl = new URL(page, location.origin);
      if (dailyUrl.origin !== location.origin) return Promise.reject(new Error('拒绝跨站签到请求'));

      return new Promise((resolve, reject) => {
        const frame = document.createElement('iframe');
        frame.dataset.v2exDailyFrame = '1';
        frame.hidden = true;
        frame.setAttribute('aria-hidden', 'true');
        frame.title = 'V2EX 每日签到';

        let stage = 'daily';
        let settled = false;
        let verifyTimer = 0;
        let verifyAttempts = 0;

        const cleanup = () => {
          clearTimeout(timeoutTimer);
          clearTimeout(verifyTimer);
          frame.remove();
        };
        const finish = (status, error = null) => {
          if (settled) return;
          settled = true;
          cleanup();
          if (error) reject(error);
          else resolve(status);
        };
        const timeoutTimer = setTimeout(() => {
          finish(null, new RetryableError('Safari 页面跳转签到超时'));
        }, CONFIG.daily.requestTimeoutMs * Math.max(3, CONFIG.daily.verifyRetries + 2));
        const scheduleVerification = () => {
          stage = 'verify-wait';
          verifyTimer = setTimeout(() => {
            if (settled) return;
            stage = 'verify';
            frame.src = dailyUrl.href;
          }, CONFIG.daily.verifyIntervalMs);
        };

        frame.addEventListener('load', () => {
          if (settled) return;

          let doc;
          let finalUrl;
          try {
            doc = frame.contentDocument;
            finalUrl = frame.contentWindow?.location?.href || frame.src;
          } catch (_) {
            finish(null, new RetryableError('Safari 无法访问签到页面'));
            return;
          }
          if (!doc || finalUrl === 'about:blank') return;

          if (isSignedOut(doc, finalUrl)) {
            finish('signed-out');
            return;
          }
          try { verifyMember(doc, member); }
          catch (error) { finish(null, error); return; }
          if (REJECTED_RE.test(pageText(doc))) {
            finish(null, new Error('V2EX 拒绝了当前浏览器环境'));
            return;
          }
          if (alreadyRedeemed(doc)) {
            finish(stage === 'daily' ? 'already-claimed' : 'claimed');
            return;
          }

          if (stage === 'daily') {
            const redeemUrl = findRedeemUrl(doc);
            if (!redeemUrl) {
              finish(null, new Error('未找到领取按钮（页面结构可能已变更）'));
              return;
            }

            let target;
            try { target = validateRedeemUrl(redeemUrl); }
            catch (error) { finish(null, error); return; }

            // 在真实的 /mission/daily 文档里点击链接，让 WebKit 自然生成
            // Referer 和第一方 Cookie；RequestInit.referrer 在 Safari 扩展里会被忽略。
            stage = 'redeem';
            const link = doc.createElement('a');
            link.href = target.href;
            link.hidden = true;
            (doc.body || doc.documentElement).appendChild(link);
            link.click();
            return;
          }

          if (stage === 'redeem') {
            // 领取接口通常跳到 /balance；等该导航完成后回任务页做服务端确认。
            scheduleVerification();
            return;
          }

          if (stage === 'verify') {
            verifyAttempts++;
            if (verifyAttempts < Math.max(1, CONFIG.daily.verifyRetries)) scheduleVerification();
            else finish(null, new RetryableError('领取请求已发送，但服务端未确认成功'));
          }
        });

        frame.src = dailyUrl.href;
        (document.body || document.documentElement).appendChild(frame);
      });
    }

    async function verifyClaimed(page, retries, intervalMs, member) {
      let lastStatus = 'unknown';
      for (let attempt = 0; attempt < retries; attempt++) {
        if (attempt > 0) await sleep(intervalMs);
        const result = await loadPage(page, location.href);
        if (isSignedOut(result.doc, result.finalUrl)) return { status: 'signed-out', result };
        verifyMember(result.doc, member);
        if (REJECTED_RE.test(pageText(result.doc))) return { status: 'rejected', result };
        if (alreadyRedeemed(result.doc)) return { status: 'claimed', result };
        lastStatus = findRedeemUrl(result.doc) ? 'claimable' : 'unknown';
      }
      return { status: lastStatus };
    }

    async function execute() {
      const {
        page,
        verifyRetries, verifyIntervalMs,
      } = CONFIG.daily;
      const member = currentMember();
      if (!member) return 'signed-out';
      // Legacy global success/lock values cannot be attributed to any account.
      const storeKey = `${CONFIG.daily.storeKey}:member:${encodeURIComponent(member)}`;
      const today = ymd();
      if (confirmedDays.has(`${storeKey}:${today}`)) return 'already-done';
      if (isSignedOut(document, location.href)) return 'signed-out';

      // Safari / wBlock Scripts 的后台请求与普通 fetch 都不能可靠地产生
      // V2EX 要求的任务页 Referer，因此改用隐藏的同源页面完成真实导航。
      if (isSafari()) {
        const status = await claimWithDailyFrame(page, member);
        if (status === 'claimed' || status === 'already-claimed') markConfirmed(storeKey, today, member);
        return status;
      }

      const daily = await loadPage(page, location.href);
      if (isSignedOut(daily.doc, daily.finalUrl)) return 'signed-out';
      verifyMember(daily.doc, member);
      if (REJECTED_RE.test(pageText(daily.doc))) throw new Error('V2EX 拒绝了当前浏览器环境');

      if (alreadyRedeemed(daily.doc)) {
        markConfirmed(storeKey, today, member);
        return 'already-claimed';
      }

      const redeemUrl = findRedeemUrl(daily.doc);
      if (!redeemUrl) throw new Error('未找到领取按钮（页面结构可能已变更）');

      const target = validateRedeemUrl(redeemUrl);
      // 领取请求必须带上任务页作为 Referer
      const redeem = await loadPage(target.href, page);
      if (isSignedOut(redeem.doc, redeem.finalUrl)) throw new Error('登录状态已失效');
      verifyMember(redeem.doc, member);
      if (REJECTED_RE.test(pageText(redeem.doc))) throw new Error('V2EX 拒绝了当前浏览器环境');

      // 领取后 V2EX 通常跳转到 /balance，页面本身不含"已领取"字样，
      // 因此需要回到任务页确认，而不是把跳转当作失败。
      let confirmed = alreadyRedeemed(redeem.doc);
      if (!confirmed) {
        const verification = await verifyClaimed(page, verifyRetries, verifyIntervalMs, member);
        if (verification.status === 'signed-out') throw new Error('登录状态已失效');
        if (verification.status === 'rejected') throw new Error('V2EX 拒绝了当前浏览器环境');
        confirmed = verification.status === 'claimed';
      }

      if (!confirmed) throw new RetryableError('领取请求已发送，但服务端未确认成功');

      markConfirmed(storeKey, today, member);
      return 'claimed';
    }

    function run() {
      if (inFlight) return inFlight;
      clearTimeout(retryTimer);
      const member = currentMember();
      // Web Locks belong to the document: navigating away releases them immediately.
      // Older engines still check the server before claiming, without a persistent lock.
      const attempt = navigator.locks?.request && member
        ? navigator.locks.request(`v2ex-daily:${member}`, { ifAvailable: true }, lock => lock ? execute() : 'locked')
        : execute();
      inFlight = Promise.resolve(attempt).then(status => {
        if (status === 'locked') {
          retryAfter(2000);
        } else {
          networkFailures = 0;
          if (status === 'claimed') log('签到：服务端已确认领取成功');
          if (status === 'already-claimed') log('签到：服务端已确认今日已领取');
        }
        return status;
      }).catch(err => {
        networkFailures++;
        // Keep recovering while the page is open; do not abandon the day after 3 failures.
        const delay = Math.min(60000, 5000 * 2 ** Math.min(networkFailures - 1, 4));
        log('签到暂未完成，后台自动重试：', err);
        retryAfter(delay);
        return 'failed';
      }).finally(() => { inFlight = null; });
      return inFlight;
    }

    function boot() {
      const tick = () => run();
      const start = () => setTimeout(tick, 800);
      if (document.readyState === 'complete') start();
      else window.addEventListener('load', start, { once: true });

      // 长期打开的页面也要覆盖"持续可见地跨过北京时间零点"这一场景（kiosk /
      // 常亮标签页），但不再用 15 分钟轮询：自链式定时器直接对准下一个 UTC
      // 16:00（= 北京时间次日零点；UTC 无夏令时，无需任何时区换算）并加抖动，
      // 每天只唤醒一两次。后台标签页跨天仍由 visibilitychange 立刻补签。
      const scheduleMidnightTick = () => {
        const now = Date.now();
        const next = new Date(now);
        next.setUTCHours(16, randInt(0, 300), 0, 0);
        if (next.getTime() <= now) next.setUTCDate(next.getUTCDate() + 1);
        setTimeout(() => { tick(); scheduleMidnightTick(); }, next.getTime() - now);
      };
      scheduleMidnightTick();
      document.addEventListener('visibilitychange', () => { if (!document.hidden) tick(); });
      window.addEventListener('online', tick);
      window.addEventListener('pageshow', tick);
    }
    return { boot, run };
  })();

  // =========================
  // 4) 功能B：Base64 解码（含 Shannon 熵过滤）
  // =========================
  const B64 = (() => {
    const BASE64_RE = /[A-Za-z0-9+/]{8,}={0,2}/g;
    const VALID_BASE64_RE = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/;
    const TARGET_SELECTOR = CONFIG.b64.targetSelectors.join(',');
    const UTF8_DECODER = new TextDecoder('utf-8', { fatal: true });

    function tryDecode(text) {
      const { minLen, excludeList, entropyThreshold } = CONFIG.b64;
      if (text.length <= minLen) return null;
      if (excludeList.includes(text)) return null;
      if (!VALID_BASE64_RE.test(text)) return null;
      try {
        const binary = window.atob(text);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
        const d = UTF8_DECODER.decode(bytes);
        if (!/[A-Za-z0-9\u4e00-\u9fff]/.test(d)) return null;
        // 熵过滤：排除低熵解码（乱码、单调重复字符等误判）
        if (shannonEntropy(d) < entropyThreshold) return null;
        return d;
      } catch (_) { return null; }
    }
    function makeReplacement(raw, decoded) {
      const wrap = document.createElement('span');
      wrap.className = 'v2-b64-wrap';
      if (/^https?:\/\//i.test(decoded)) {
        let href;
        try {
          const u = new URL(decoded);
          if (u.protocol !== 'https:' && u.protocol !== 'http:') return null;
          href = u.href;
        } catch (_) { return null; }
        const a = document.createElement('a');
        a.className = 'v2-b64-link';
        a.href = href; a.target = '_blank'; a.rel = 'noreferrer noopener';
        a.title = href; a.textContent = decoded;
        wrap.appendChild(a);
      } else {
        const span = document.createElement('span');
        span.className = 'v2-b64-plain';
        span.textContent = decoded;
        wrap.appendChild(span);
      }
      const mark = document.createElement('span');
      mark.className = 'v2-b64-mark'; mark.textContent = 'b64';
      mark.title = `decoded from base64\n${raw}`;
      wrap.prepend(mark);

      function createCopyAction(label, copiedLabel, clipboardText, title) {
        const btn = document.createElement('span');
        btn.className = 'v2-b64-action';
        btn.textContent = label;
        btn.title = title;
        btn.dataset.label = label;
        btn.dataset.copiedLabel = copiedLabel;
        btn.dataset.clipboardText = clipboardText;
        return btn;
      }

      // copy 是主动作：复制当前展示的解码结果；raw 才复制原始 base64。
      const actions = document.createElement('span');
      actions.className = 'v2-b64-actions';
      actions.appendChild(createCopyAction('copy', 'copied', decoded, '复制解码后的内容'));
      actions.appendChild(createCopyAction('raw', 'copied', raw, '复制原始 base64'));
      wrap.appendChild(actions);

      return wrap;
    }

    function processTextNode(node) {
      if (!node?.isConnected || !node.nodeValue || node.nodeValue.length <= CONFIG.b64.minLen) return;
      const parent = node.parentElement;
      if (!parent || parent.closest('.v2-b64-wrap, .v2-ref-link, a, script, style, textarea')) return;

      const text = node.nodeValue;
      let last = 0;
      const frag = document.createDocumentFragment();
      let changed = false;
      BASE64_RE.lastIndex = 0;
      let match;
      while ((match = BASE64_RE.exec(text)) !== null) {
        const candidate = match[0];
        const decoded = tryDecode(candidate);
        if (!decoded) continue;
        const replacement = makeReplacement(candidate, decoded);
        if (!replacement) continue;
        changed = true;
        frag.appendChild(document.createTextNode(text.slice(last, match.index)));
        frag.appendChild(replacement);
        last = match.index + candidate.length;
      }
      if (!changed || !node.parentNode) return;
      frag.appendChild(document.createTextNode(text.slice(last)));
      node.parentNode.replaceChild(frag, node);
    }

    function processSubtree(root) {
      if (!root) return;
      if (root.nodeType === Node.TEXT_NODE) {
        processTextNode(root);
        return;
      }
      if (root.nodeType !== Node.ELEMENT_NODE || root.closest('.v2-b64-wrap, .v2-ref-link')) return;
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
        acceptNode(node) {
          if (!node.nodeValue || node.nodeValue.length <= CONFIG.b64.minLen) return NodeFilter.FILTER_REJECT;
          const p = node.parentElement;
          if (p.closest('.v2-b64-wrap, .v2-ref-link, a, script, style, textarea')) return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        },
      });
      const nodes = [];
      while (walker.nextNode()) nodes.push(walker.currentNode);
      nodes.forEach(processTextNode);
    }

    function processContent(contentEl) {
      if (!contentEl || contentEl.dataset.v2b64scanned === '1') return;
      rescanContent(contentEl);
    }

    function rescanContent(contentEl) {
      processSubtree(contentEl);
      contentEl.dataset.v2b64scanned = '1';
    }

    function scanAll() {
      document.querySelectorAll(TARGET_SELECTOR).forEach(processContent);
    }

    function processAddedNode(node) {
      if (node.nodeType === Node.TEXT_NODE) {
        if (node.parentElement?.closest(TARGET_SELECTOR)?.dataset.v2b64scanned === '1') processTextNode(node);
        return;
      }
      if (node.nodeType !== Node.ELEMENT_NODE) return;

      // 合并后的根可能是已经扫描过、但随后又追加正文的容器。
      // 重扫正文仍跳过已生成的解码控件，不能仅凭容器标记漏掉新增文本。
      if (node.matches(TARGET_SELECTOR)) rescanContent(node);
      node.querySelectorAll(TARGET_SELECTOR).forEach(rescanContent);

      const owner = node.closest(TARGET_SELECTOR);
      if (owner?.dataset.v2b64scanned === '1' && node !== owner) processSubtree(node);
    }

    function boot() {
      if (!isTopicPage()) return;
      scanAll();
      const root = document.querySelector('#Main') || document.body;
      document.addEventListener('click', e => {
        const btn = e.target.closest?.('.v2-b64-action');
        if (!btn) return;
        e.preventDefault();
        e.stopPropagation();
        try { GM_setClipboard(btn.dataset.clipboardText || ''); } catch (err) { log('Clipboard error:', err); return; }
        btn.textContent = btn.dataset.copiedLabel;
        btn.classList.add('copied');
        clearTimeout(btn._v2CopyTimer);
        btn._v2CopyTimer = setTimeout(() => {
          if (!btn.isConnected) return;
          btn.textContent = btn.dataset.label;
          btn.classList.remove('copied');
        }, 1200);
      });
      const enqueueScan = createSubtreeBatch(processAddedNode);
      new MutationObserver(mutations => {
        for (const mut of mutations) {
          for (const node of mut.addedNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              if (node.closest('.v2-b64-wrap')) continue;
            } else if (node.nodeType === Node.TEXT_NODE) {
              if (node.parentElement?.closest('.v2-b64-wrap')) continue;
            } else {
              continue;
            }
            enqueueScan(node);
          }
        }
      }).observe(root, { childList: true, subtree: true });
    }
    return { boot };
  })();

  // =========================
  // 5) 功能C：楼层树 + 多页 + 折叠持久化 + 悬停引用预览
  // =========================
  const ThreadTree = (() => {

    // 楼层引用只应来自普通正文。按独立文本节点扫描，避免 textContent
    // 把 <br> 两边拼在一起（例如链接以 # 结尾、下一行以 3. 开头时会伪造 #3）。
    // 同时忽略链接和代码块，防止 URL / 示例代码中的 #数字 被当成回复引用。
    const FLOOR_REF_EXCLUDED_TAGS = new Set(['A', 'CODE', 'PRE', 'SCRIPT', 'STYLE']);

    function extractFloorReferences(contentEl) {
      const floors = [];

      const stack = [contentEl];
      while (stack.length) {
        const node = stack.pop();
        if (node.nodeType === Node.TEXT_NODE) {
          for (const match of (node.nodeValue || '').matchAll(/#(\d+)/g)) floors.push(match[1]);
        } else if (node.nodeType === Node.ELEMENT_NODE && !FLOOR_REF_EXCLUDED_TAGS.has(node.tagName)) {
          for (let child = node.lastChild; child; child = child.previousSibling) stack.push(child);
        }
      }
      return floors;
    }

    // V2EX 原生 replyOne() 只会在输入框里写入“@用户名 ”。在捕获阶段记住
    // 点击前的内容，等原生 onclick 执行完后，再只改写它刚追加的那段，得到
    // “@用户名 #楼层号 ”；这样不会误改用户已经输入的正文。这里必须用下一轮
    // task，不能用微任务：浏览器可能在捕获监听器结束后、目标 onclick 执行前
    // 就清空微任务队列，导致过早检查输入框而漏掉本次回复。
    function initReplyFloorReference() {
      if (document._v2ReplyFloorBound) return;
      document._v2ReplyFloorBound = true;

      document.addEventListener('click', event => {
        const button = event.target.closest?.('[onclick*="replyOne("]');
        if (!button) return;

        const cell = button.closest('div.cell[id^="r_"]');
        const input = document.getElementById('reply_content');
        const memberName = (cell?.querySelector('strong a[href*="/member/"]')?.textContent || '').trim();
        const floorNum = Number((cell?.querySelector('.no')?.textContent || '').match(/\d+/)?.[0]);
        if (!cell || !input || !memberName || !Number.isSafeInteger(floorNum)) return;

        const before = input.value;
        const nativePrefix = `@${memberName} `;
        const floorPrefix = `@${memberName} #${floorNum} `;

        setTimeout(() => {
          if (!input.isConnected) return;
          const current = input.value;
          let next = null;

          if (!before && current === nativePrefix) {
            next = floorPrefix;
          } else if (before && current === `${before}\n${nativePrefix}`) {
            next = `${before}\n${floorPrefix}`;
          } else if (before === nativePrefix && !current) {
            // 原生逻辑在输入框恰好等于同一个 @ 前缀时会清空内容。
            next = floorPrefix;
          }

          if (next === null) return;
          input.value = next;
          input.focus();
          input.setSelectionRange?.(next.length, next.length);
        }, 0);
      }, true);
    }

    // ── 解析单条回复 ──
    function parseReplyCell(cell, idx) {
      if (!cell?.id?.startsWith('r_')) return null;
      const replyId   = cell.id.replace('r_', '');
      const contentEl = cell.querySelector('.reply_content');
      const authorEl  = cell.querySelector('strong a');
      const floorEl   = cell.querySelector('.no');
      const avatarEl  = cell.querySelector('img.avatar');
      if (!contentEl || !authorEl || !floorEl) return null;

      const memberName = (authorEl.textContent || '').trim();
      const content    = contentEl.textContent || '';
      const floor      = (floorEl.textContent || '').trim();
      const floorNum   = Number(floor.match(/\d+/)?.[0]);
      if (!Number.isSafeInteger(floorNum)) return null;
      const likesText  = cell.querySelector('span.small')?.textContent || '';
      const likes      = Number(likesText.match(/\d+/)?.[0] || 0);
      const refMemberNames = [...content.matchAll(/@([a-zA-Z0-9_-]+)/g)].map(([, n]) => n);
      const refFloors      = extractFloorReferences(contentEl);

      return {
        element: cell, floorEl, id: replyId, index: idx,
        memberName, memberLink: authorEl.href, memberAvatar: avatarEl?.src || '',
        content, floor, floorNum, likes,
        refMemberNames: refMemberNames.length ? refMemberNames : undefined,
        refFloors:      refFloors.length      ? refFloors      : undefined,
        children: [],
      };
    }

    // 其它分页的 HTML 要解析成文档再把楼层搬进当前页面。在沙箱环境里
    // （Firefox 的 Xray）DOMParser 建出的文档和页面文档主体不同，跨文档搬运
    // 可能失败，所以优先用页面自己的 document.implementation 建文档。
    function parseReplyDoc(html) {
      try {
        const doc = document.implementation.createHTMLDocument('');
        doc.documentElement.innerHTML = html;
        if (doc.querySelector('div.cell[id^="r_"]')) return doc;
      } catch (err) {
        log('createHTMLDocument 解析失败，回退 DOMParser：', err);
      }
      return new DOMParser().parseFromString(html, 'text/html');
    }

    function extractRepliesFromDoc(doc) {
      // 外来文档的节点先 importNode 成本页面拥有的节点，避免依赖 appendChild 的隐式 adopt
      const foreign = doc !== document;
      return Array.from(doc.querySelectorAll('div.cell[id^="r_"]'))
        .map((cell, idx) => {
          let node = cell;
          if (foreign) {
            try { node = document.importNode(cell, true); }
            catch (err) { log('importNode 失败，直接使用原节点：', err); }
          }
          return parseReplyCell(node, idx);
        })
        .filter(Boolean);
    }

    // ── Map 构建，O(n)，供 inferParent 和 hoverPreview 共用 ──
    function buildLookupMaps(allReplies) {
      const floorMap = new Map();
      const nameMap  = new Map();
      for (const r of allReplies) {
        floorMap.set(r.floorNum, r);
        const key = r.memberName.toLowerCase();
        if (!nameMap.has(key)) nameMap.set(key, []);
        nameMap.get(key).push(r);
      }
      return { floorMap, nameMap };
    }

    function findPreviousCandidate(candidates, index) {
      if (!candidates?.length) return null;
      let low = 0;
      let high = candidates.length - 1;
      let best = null;
      while (low <= high) {
        const middle = (low + high) >> 1;
        const candidate = candidates[middle];
        if (candidate.index < index) {
          best = candidate;
          low = middle + 1;
        } else {
          high = middle - 1;
        }
      }
      return best;
    }

    // ── 父节点推断，Map 查找 + 同名候选二分搜索 ──
    function inferParent(reply, { floorMap, nameMap }) {
      const { refMemberNames, refFloors, index, floorNum } = reply;
      const firstRefFloor = refFloors?.[0] ? Number(refFloors[0]) : null;
      if (firstRefFloor !== null && firstRefFloor < floorNum) {
        const exact = floorMap.get(firstRefFloor);
        if (exact && (!refMemberNames?.length || exact.memberName.toLowerCase() === refMemberNames[0].toLowerCase())) {
          return exact;
        }
      }
      if (!refMemberNames?.length) return null;

      const targetName = refMemberNames[0].toLowerCase();
      const candidates = nameMap.get(targetName);
      const candidate = findPreviousCandidate(candidates, index);
      return candidate?.floorNum < floorNum ? candidate : null;
    }

    // ── 折叠持久化（sessionStorage）──
    function collapseKey(topicId)    { return `${CONFIG.threadTree.collapseKeyPrefix}${topicId}`; }
    function getCollapsedSet(topicId) {
      try { return new Set(JSON.parse(sessionStorage.getItem(collapseKey(topicId)) || '[]')); }
      catch { return new Set(); }
    }
    function saveCollapsedSet(topicId, set) {
      try { sessionStorage.setItem(collapseKey(topicId), JSON.stringify([...set])); }
      catch (err) { log('Collapse state error:', err); }
    }

    function syncReplyVisibility(state) {
      let hiddenThrough = -1;
      for (const model of state.rows) {
        model.row.hidden = model.index <= hiddenThrough;
        const collapsed = state.collapsedSet.has(model.reply.id);
        if (!model.row.hidden && collapsed) hiddenThrough = model.end;
        if (model.toggle) {
          const label = collapsed ? `展开 ${model.count} 条回复` : '收起此分支';
          model.toggle.setAttribute('aria-expanded', String(!collapsed));
          model.toggle.setAttribute('aria-label', label);
          model.toggle.title = label;

          model.hint.hidden = !collapsed;
        }
      }
      state.scheduleLines?.();
    }

    // Flat rows keep ancestry in the presentation model, not in DOM nesting.
    function revealAncestors(el) {
      const row = el?.closest('.reply-row');
      const state = row?._v2Model.state;
      if (!state) return;
      let changed = false;
      for (let parent = row._v2Model.parent; parent; parent = parent.parent) {
        if (state.collapsedSet.delete(parent.reply.id)) changed = true;
      }
      if (!changed) return;
      syncReplyVisibility(state);
      saveCollapsedSet(state.topicId, state.collapsedSet);
    }

    // ── 头部重排 ──
    // V2EX 原始结构是一串行内节点，楼层块靠 float:right 贴右边。这里改成一个
    // flex 行，用一段弹性留白把楼层块推到右边缘：
    // [用户名 + 标签] [时间 ♥] ——弹性留白—— [♥ ↩ 楼层号]
    // 时间维持原位（紧跟用户名）。未读状态直接画在楼层号上，不额外插节点。
    // 结构不符合预期时直接返回，保持 V2EX 原样，不做半吊子改动。
    function layoutReplyHeader(cell) {
      const body = cell.querySelector('.reply_content');
      const bodyContainer = body?.parentElement;
      if (bodyContainer?.querySelector(':scope > .v2-reply-head')) return;
      // New V2EX markup groups identity and actions in nested flex rows.
      // Keep the native action nodes (and their handlers), but normalize the
      // header before adding parent links so they never fall into the rail gutter.
      const nativeHead = bodyContainer?.querySelector(':scope > .flex-one-row');
      const nativeIdentity = nativeHead?.querySelector(':scope > .flex-one-row');
      const nativeActions = nativeHead?.querySelector('.no')?.parentElement;
      if (nativeIdentity?.querySelector('strong a[href*="/member/"]') &&
          nativeActions?.parentElement === nativeHead && nativeActions !== nativeIdentity) {
        nativeHead.classList.remove('flex-one-row');
        nativeHead.classList.add('v2-reply-head');
        nativeIdentity.classList.remove('flex-one-row', 'gap10');
        nativeIdentity.classList.add('rh-details');
        const identity = document.createElement('span');
        identity.className = 'rh-id';
        const meta = document.createElement('span');
        meta.className = 'rh-meta';
        for (const node of [...nativeIdentity.childNodes]) {
          if (node.nodeType === Node.TEXT_NODE && !node.nodeValue.trim()) node.remove();
          else if (node.nodeType === Node.ELEMENT_NODE &&
                   (node.classList.contains('ago') || node.matches('.small.fade'))) meta.append(node);
          else identity.append(node);
        }
        nativeIdentity.append(identity, meta);
        nativeActions.classList.add('fr');
        return;
      }
      const strong = cell.querySelector('strong');
      const container = strong?.parentElement;
      if (!container || container.querySelector(':scope > .v2-reply-head')) return;
      const content = container.querySelector(':scope > .reply_content');
      if (!content) return;

      // 收集 strong 到正文之间的头部节点（.sep5 之前）
      const nodes = [];
      for (let node = strong; node && node !== content; node = node.nextSibling) {
        if (node.nodeType === Node.ELEMENT_NODE && node.classList.contains('sep5')) break;
        nodes.push(node);
      }
      if (!nodes.length) return;

      const head = document.createElement('div');
      head.className = 'v2-reply-head';
      const identity = document.createElement('span');
      identity.className = 'rh-id';
      const meta = document.createElement('span');
      meta.className = 'rh-meta';
      const gap = document.createElement('span');
      gap.className = 'rh-gap';

      // 先把空的 head 挂进文档，再往里搬节点。反过来做的话，一旦中途抛异常，
      // 用户名/时间会跟着游离的 head 一起从页面上消失。
      container.insertBefore(head, container.querySelector(':scope > .sep5') || content);
      head.append(identity, meta, gap);

      const likes = [];
      const times = [];
      for (const node of nodes) {
        if (node.nodeType === Node.TEXT_NODE) {
          // 原来的 &nbsp; 间隔交给 flex gap，非空文本保留在左侧
          if (node.nodeValue.trim()) identity.appendChild(node);
          else node.remove();
          continue;
        }
        if (node.nodeType !== Node.ELEMENT_NODE) { node.remove(); continue; }
        const cls = node.classList;
        if (cls.contains('ago')) times.push(node);
        else if (cls.contains('small') && cls.contains('fade')) likes.push(node);
        else identity.appendChild(node);   // strong / badges / 未知元素一律留在左侧
      }

      // 时间在前、♥ 在后，保持 V2EX 原本的阅读顺序
      meta.append(...times, ...likes);

      // 楼层块（感谢/回复按钮 + 楼层号）整体挪到头部末尾，由 .rh-gap 顶到最右。
      const floor = container.querySelector(':scope > .fr');
      if (floor) head.appendChild(floor);
    }

    // 先生成先序列表，再逆序累计后代数；两遍迭代都不消耗调用栈深度。
    function buildReplyForest(flatReplies, maps) {
      const roots = [];
      const parents = new Map();
      const counts = new Map();
      for (const reply of flatReplies) { reply.children = []; counts.set(reply, 0); }
      for (const reply of flatReplies) {
        const parent = inferParent(reply, maps);
        if (parent) { parent.children.push(reply); parents.set(reply, parent); }
        else roots.push(reply);
      }
      const ordered = [];
      const stack = roots.slice().reverse();
      while (stack.length) {
        const reply = stack.pop();
        ordered.push(reply);
        for (let i = reply.children.length - 1; i >= 0; i--) stack.push(reply.children[i]);
      }
      for (let i = ordered.length - 1; i >= 0; i--) {
        const reply = ordered[i], parent = parents.get(reply);
        if (parent) counts.set(parent, counts.get(parent) + 1 + counts.get(reply));
      }
      return { roots, counts };
    }

    // Flat DOM, capped visual depth: collapse uses logical ancestry, while
    // connectors are measured from real avatars (including responsive layouts).
    function renderTree(flatReplies, maps, container, topicId) {
      const { roots, counts } = buildReplyForest(flatReplies, maps);
      const previous = container._v2CollapseState;
      previous?.observer?.disconnect();
      if (previous?.frame) cancelAnimationFrame(previous.frame);
      const state = { topicId, collapsedSet: getCollapsedSet(topicId), rows: [] };
      const fragment = document.createDocumentFragment();
      const make = (tag, cls) => { const el = document.createElement(tag); el.className = cls; return el; };
      const stack = roots.slice().reverse().map(reply => ({ reply, parent: null, depth: 0 }));
      while (stack.length) {
        const model = stack.pop(), { reply, parent, depth } = model;
        model.state = state; model.index = state.rows.length; model.count = counts.get(reply);
        model.end = model.index + model.count;
        const row = model.row = make('div', 'reply-wrapper reply-row');
        row.dataset.replyId = reply.id; row.dataset.depth = depth; row._v2Model = model;
        row.style.setProperty('--reply-level', Math.min(depth, 3));
        reply.element.classList.remove('inner');
        reply.element.querySelectorAll('.reply-context,.reply-parent-link,.reply-branch-toggle,.reply-collapsed-hint').forEach(el => el.remove());
        try { layoutReplyHeader(reply.element); } catch (err) { log('楼层头部重排失败：', err); }
        const head = reply.element.querySelector('.v2-reply-head');
        let details = head?.querySelector('.rh-details');
        if (head && !details) {
          details = make('div', 'rh-details');
          for (const child of [...head.children]) {
            if (child.classList.contains('rh-gap')) child.remove();
            else if (!child.classList.contains('fr')) details.append(child);
          }
          head.prepend(details);
        }
        const addMeta = el => details ? details.append(el) : reply.element.append(el);
        if (parent) {
          const link = make('a', 'reply-parent-link'); link.href = `#${parent.reply.element.id}`;
          link.innerHTML = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 3 2.5 6.5 6 10M3 6.5h6a4 4 0 0 1 4 4V13"/></svg>';
          link.append(document.createTextNode(`#${parent.reply.floorNum}`));
          link.title = `回复 ${parent.reply.memberName} 的 #${parent.reply.floorNum} 楼`;
          link.setAttribute('aria-label', link.title); addMeta(link);
          link._v2RefReply = parent.reply;
        }
        if (reply.children.length) {
          model.toggle = make('button', 'reply-branch-toggle'); model.toggle.type = 'button';
          model.toggle.innerHTML = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 6 3 3 3-3"/></svg>';
          reply.element.append(model.toggle);
          model.hint = make('button', 'reply-collapsed-hint'); model.hint.type = 'button';
          model.hint.textContent = `展开 ${model.count} 条回复`; reply.element.append(model.hint);
        }
        row.append(reply.element); fragment.append(row); state.rows.push(model);
        for (let i = reply.children.length - 1; i >= 0; i--) stack.push({ reply: reply.children[i], parent: model, depth: depth + 1 });
      }
      const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      svg.classList.add('reply-connectors'); svg.setAttribute('aria-hidden', 'true');
      fragment.append(svg);
      container.replaceChildren(fragment); container.classList.add('reply-tree'); container._v2CollapseState = state;
      // Use fixed indentation steps, but spend only the available reading width.
      // Measure the root body so avatars, padding and host themes are accounted for.
      // Keep 72% of its width (240–480px), with an eight-step safety ceiling.
      function drawLines() {
        state.frame = 0;
        const root = state.rows[0];
        const body = root?.reply.element.querySelector('.reply_content');
        const bodyWidth = body?.getBoundingClientRect().width || 0;
        const step = parseFloat(getComputedStyle(container).getPropertyValue('--reply-indent')) || 28;
        const readingWidth = Math.min(480, Math.max(240, bodyWidth * .72));
        const maxDepth = Math.min(8, Math.max(0, Math.floor((bodyWidth - readingWidth) / step)));
        if (state.maxDepth !== maxDepth) {
          state.maxDepth = maxDepth;
          container.dataset.maxVisualDepth = String(maxDepth);
          for (const model of state.rows) {
            model.row.style.setProperty('--reply-level', Math.min(model.depth, maxDepth));
          }
        }
        const visible = state.rows.filter(model => !model.row.hidden);
        const bounds = container.getBoundingClientRect();
        const positions = new Map();
        const togglePositions = [];
        // Complete all layout reads before writing button positions or SVG paths.
        for (const model of visible) {
          const avatar = model.reply.element.querySelector('.avatar');
          const rect = avatar?.getBoundingClientRect();
          if (model.toggle && rect?.width) {
            const cellRect = model.reply.element.getBoundingClientRect();
            togglePositions.push({
              toggle: model.toggle,
              left: `${rect.right - cellRect.left - 16}px`,
              top: `${rect.bottom - cellRect.top - 16}px`,
            });
          }
          if (rect?.width && rect.height) positions.set(model, {
            x: rect.left + rect.width / 2 - bounds.left,
            left: rect.left - bounds.left, y: rect.top + rect.height / 2 - bounds.top,
            bottom: rect.bottom - bounds.top + 3
          });
        }
        for (const { toggle, left, top } of togglePositions) {
          if (toggle.style.left !== left) toggle.style.left = left;
          if (toggle.style.top !== top) toggle.style.top = top;
        }
        const pathData = [];
        for (const model of visible) {
          const parent = model.parent;
          if (!parent || model.depth > state.maxDepth) continue;
          const start = positions.get(parent), end = positions.get(model);
          if (!start || !end) continue;
          // Stop at the avatar edge. Small indents naturally use a smaller elbow.
          const target = end.left - 2, radius = Math.min(8, Math.max(0, target - start.x));
          if (target < start.x || end.y <= start.bottom) continue;
          pathData.push(`M${start.x} ${start.bottom}V${end.y - radius}Q${start.x} ${end.y} ${start.x + radius} ${end.y}H${target}`);
        }
        // Unchanged geometry must not rebuild SVG or wake incremental scanners.
        const signature = pathData.join('\n');
        if (state.pathSignature === signature) return;
        state.pathSignature = signature;
        const paths = document.createDocumentFragment();
        for (const data of pathData) {
          const path = document.createElementNS(svg.namespaceURI, 'path');
          path.setAttribute('d', data);
          paths.append(path);
        }
        svg.replaceChildren(paths);
      }
      state.scheduleLines = () => { if (!state.frame) state.frame = requestAnimationFrame(drawLines); };
      state.observer = new ResizeObserver(state.scheduleLines);
      state.observer.observe(container);
      for (const model of state.rows) state.observer.observe(model.reply.element);
      syncReplyVisibility(state);
      if (!container._v2AvatarTreeBound) {
        container._v2AvatarTreeBound = true;
        let highlightedParent = null;
        const highlightParent = target => {
          const link = target?.closest?.('.reply-parent-link');
          const nextParent = link?._v2RefReply?.element || null;
          if (highlightedParent === nextParent) return;
          highlightedParent?.classList.remove('reply-parent-highlight');
          highlightedParent = nextParent;
          highlightedParent?.classList.add('reply-parent-highlight');
        };
        container.addEventListener('mouseover', e => highlightParent(e.target));
        container.addEventListener('mouseout', e => highlightParent(e.relatedTarget));
        container.addEventListener('focusin', e => highlightParent(e.target));
        container.addEventListener('focusout', e => highlightParent(e.relatedTarget));
        container.addEventListener('click', e => {
          const model = e.target.closest?.('.reply-row')?._v2Model; if (!model) return;
          const link = e.target.closest('.reply-parent-link');
          if (link) { revealAncestors(document.getElementById(link.hash.slice(1))); return; }
          const control = e.target.closest('.reply-branch-toggle,.reply-collapsed-hint');
          if (!control) return;
          const current = container._v2CollapseState, set = current.collapsedSet;
          if (set.has(model.reply.id)) set.delete(model.reply.id); else set.add(model.reply.id);
          if (control === model.hint) model.toggle.focus({ preventScroll: true });
          syncReplyVisibility(current); saveCollapsedSet(current.topicId, set);
        });
      }
      document.dispatchEvent(new Event('v2ex:replies-updated'));
    }

    // ── 未读标记 ──
    // 阅读进度走 GM 存储而不是 localStorage：脚本 @match 了 v2ex.com /
    // www.v2ex.com / edge.v2ex.com 三个 origin，localStorage 按 origin 隔离，
    // 换个域名进同一个帖子就会被当成没读过。
    function createReadState(topicId) {
      const key = `${CONFIG.threadTree.readKeyPrefix}${topicId}`;
      const stored = GM.get(key, null);
      return {
        key,
        // null = 真的没进过。首次访问不标记，否则满屏都是"新回复"。
        firstVisit: stored === null,
        lastReadFloor: Number.isSafeInteger(stored) ? stored : 0,
      };
    }

    function markUnread(state, replies) {
      if (state.firstVisit) return 0;
      let newCount = 0;
      for (const r of replies) {
        if (r.floorNum <= state.lastReadFloor) continue;
        newCount++;
        // 未读状态全靠这个 class 驱动：楼层数字变为蓝色，
        // 不再往头部塞任何额外节点（见 .cell.reply-new .fr .no）
        r.element.classList.add('reply-new');
        // 楼层号节点在解析阶段就拿到了，不必再 querySelector 一遍
        if (r.floorEl) r.floorEl.title = '未读新回复';
      }
      if (newCount) document.dispatchEvent(new Event('v2ex:replies-updated'));
      return newCount;
    }

    // 只推进到"从 1 楼起连续加载成功"的那个楼层，而不是见到的最大楼层：
    // 中间某页抓失败时，它后面的页照样会带来更大的楼层号，直接存 max 会把
    // 失败页里那几十楼永久标成已读。取连续前缀就能带着缺口安全地存进度，
    // 不必像以前那样"只要有一页失败就整个不写"——那会让这个帖子永远停在
    // firstVisit，之后的新回复一条都标不出来。
    function commitReadState(state, replies) {
      const floors = new Set();
      for (const r of replies) floors.add(r.floorNum);
      let contiguous = 0;
      while (floors.has(contiguous + 1)) contiguous++;
      // 进度只前进不后退；firstVisit 时哪怕是 0 也要落一笔，把"没进过"翻成"进过"
      if (!state.firstVisit && contiguous <= state.lastReadFloor) return;
      GM.set(state.key, contiguous);
    }

    function updateNewCountBar(replyBox, newCount) {
      let bar = document.getElementById('v2ex-new-count-bar');
      if (newCount <= 0) {
        bar?.remove();
        return;
      }
      if (!bar) {
        bar = document.createElement('div');
        bar.id = 'v2ex-new-count-bar';
        const dot = document.createElement('span');
        dot.className = 'ncb-dot';
        const strong = document.createElement('strong');
        const text = document.createElement('span');
        text.append('有 ', strong, ' 条新回复');
        const hint = document.createElement('span');
        hint.className = 'ncb-hint';
        hint.textContent = 'j / k 键跳转';
        bar.append(dot, text, hint);
        bar._countEl = strong;
        replyBox.parentNode.insertBefore(bar, replyBox);
      }
      const countEl = bar._countEl || bar.querySelector('strong');
      if (countEl) countEl.textContent = String(newCount);
    }

    // ── 悬停引用预览（在 B64 完成后运行，延迟 150ms）──
    function initHoverPreview(allReplies, { floorMap, nameMap }) {
      // 非全局：用于 acceptNode 内的测试（无 lastIndex 副作用）
      const REF_TEST_RE = /@[a-zA-Z0-9_-]+|#\d+/;
      // 全局：用于 exec 循环
      const REF_EXEC_RE = /(@[a-zA-Z0-9_-]+|#\d+)/g;

      let card      = null;
      let hideTimer = null;

      function getCard() {
        if (!card?.isConnected) {
          card = document.getElementById('v2ex-ref-preview');
        }
        if (!card) {
          card = document.createElement('div');
          card.id = 'v2ex-ref-preview';
          document.body.appendChild(card);
        }
        return card;
      }

      function showCard(refReply, anchorEl) {
        clearTimeout(hideTimer);
        // Adjacent, fully visible replies already provide the reference context.
        // Use visible DOM order rather than floor numbers (DFS can reorder them).
        const currentRow = anchorEl.closest('.reply-row');
        const targetRow = refReply.element.closest('.reply-row');
        let previousRow = currentRow?.previousElementSibling;
        while (previousRow?.hidden) previousRow = previousRow.previousElementSibling;
        const contentRect = refReply.element.querySelector('.reply_content')?.getBoundingClientRect();
        const targetRect = refReply.element.getBoundingClientRect();
        if (targetRow && previousRow === targetRow && !targetRow.hidden &&
            contentRect?.width > 0 && contentRect.height > 0 &&
            targetRect.top >= 0 && contentRect.bottom <= window.innerHeight &&
            contentRect.left >= 0 && contentRect.right <= window.innerWidth) {
          card?.classList.remove('visible');
          return;
        }
        const c = getCard();
        const header = document.createElement('div');
        header.className = 'rp-header';
        if (refReply.memberAvatar) {
          const avatar = document.createElement('img');
          avatar.className = 'rp-avatar';
          avatar.src = refReply.memberAvatar;
          avatar.alt = '';
          header.appendChild(avatar);
        }
        const name = document.createElement('span');
        name.className = 'rp-name';
        name.textContent = refReply.memberName;
        const floor = document.createElement('span');
        floor.className = 'rp-floor';
        floor.textContent = refReply.floor.startsWith('#') ? refReply.floor : `#${refReply.floor}`;
        header.append(name, floor);

        const content = document.createElement('div');
        content.className = 'rp-content';
        const source = refReply.element.querySelector('.reply_content');
        if (source) content.append(...source.cloneNode(true).childNodes);
        else content.textContent = refReply.content;
        c.replaceChildren(header, content);

        const rect  = anchorEl.getBoundingClientRect();
        const cardRect = c.getBoundingClientRect();
        const cardW = Math.min(360, cardRect.width || 360);
        const cardH = cardRect.height || 160;
        const left  = Math.max(4, Math.min(rect.left, window.innerWidth - cardW - 10));
        const top   = (window.innerHeight - rect.bottom > cardH + 10)
          ? rect.bottom + 6
          : Math.max(4, rect.top - cardH - 6);
        c.style.left = `${left}px`;
        c.style.top  = `${top}px`;
        c.classList.add('visible');
      }

      function hideCard() {
        hideTimer = setTimeout(() => card?.classList.remove('visible'), 120);
      }

      function findPreviousReplyByName(name, replyIndex) {
        const candidates = nameMap.get(name.toLowerCase());
        return findPreviousCandidate(candidates, replyIndex);
      }

      function bindPreview(anchor, refReply) {
        anchor.classList.add('v2-ref-link');
        anchor._v2RefReply = refReply;
        if (document._v2RefPreviewBound) return;
        document._v2RefPreviewBound = true;
        document.addEventListener('focusin', e => {
          const target = e.target.closest?.('.v2-ref-link');
          if (target?._v2RefReply) showCard(target._v2RefReply, target);
        });
        document.addEventListener('focusout', e => {
          if (e.target.closest?.('.v2-ref-link')) hideCard();
        });
        document.addEventListener('mouseover', e => {
          const target = e.target.closest?.('.v2-ref-link');
          if (!target?._v2RefReply || (e.relatedTarget instanceof Node && target.contains(e.relatedTarget))) return;
          showCard(target._v2RefReply, target);
        });
        document.addEventListener('mouseout', e => {
          const target = e.target.closest?.('.v2-ref-link');
          if (!target?._v2RefReply || (e.relatedTarget instanceof Node && target.contains(e.relatedTarget))) return;
          hideCard();
        });
      }

      for (const reply of allReplies) {
        const parentLink = reply.element.querySelector('.reply-parent-link');
        if (parentLink?._v2RefReply) bindPreview(parentLink, parentLink._v2RefReply);
        const contentEl = reply.element.querySelector('.reply_content');
        if (!contentEl) continue;

        // V2EX 会把 @ 与用户名拆成相邻文本和链接，直接绑定现有会员链接。
        contentEl.querySelectorAll('a[href^="/member/"]:not(.v2-ref-link)').forEach(anchor => {
          const previous = anchor.previousSibling;
          if (previous?.nodeType !== Node.TEXT_NODE || !/@\s*$/.test(previous.nodeValue || '')) return;
          const refReply = findPreviousReplyByName(anchor.textContent?.trim() || '', reply.index);
          if (refReply) bindPreview(anchor, refReply);
        });

        const walker = document.createTreeWalker(contentEl, NodeFilter.SHOW_TEXT, {
          acceptNode(node) {
            if (!node.nodeValue) return NodeFilter.FILTER_REJECT;
            if (node.parentElement?.closest('.v2-b64-wrap, .v2-ref-link')) return NodeFilter.FILTER_REJECT;
            if (!REF_TEST_RE.test(node.nodeValue)) return NodeFilter.FILTER_REJECT;
            return NodeFilter.FILTER_ACCEPT;
          },
        });

        const nodes = [];
        while (walker.nextNode()) nodes.push(walker.currentNode);

        nodes.forEach(node => {
          const text = node.nodeValue;
          const frag = document.createDocumentFragment();
          let last = 0, changed = false;
          REF_EXEC_RE.lastIndex = 0;
          let m;

          while ((m = REF_EXEC_RE.exec(text)) !== null) {
            const token = m[0];
            let refReply = null;

            if (token.startsWith('@')) {
              refReply = findPreviousReplyByName(token.slice(1), reply.index);
            } else if (token.startsWith('#')) {
              const floor = parseInt(token.slice(1), 10);
              const found = floorMap.get(floor) ?? null;
              refReply = (found && found.floorNum < reply.floorNum) ? found : null;
            }

            frag.appendChild(document.createTextNode(text.slice(last, m.index)));
            if (refReply) {
              const span = document.createElement('span');
              span.className = 'v2-ref-link'; span.textContent = token;
              bindPreview(span, refReply);
              frag.appendChild(span);
              changed = true;
            } else {
              frag.appendChild(document.createTextNode(token));
            }
            last = m.index + token.length;
          }

          if (changed && node.parentNode) {
            frag.appendChild(document.createTextNode(text.slice(last)));
            node.parentNode.replaceChild(frag, node);
          }
        });
      }
    }

    function getTotalPages() {
      const candidates = [1];
      const max = Number.parseInt(document.querySelector('.page_input')?.getAttribute('max') || '', 10);
      if (Number.isSafeInteger(max)) candidates.push(max);
      document.querySelectorAll('a.page_normal, .page_current').forEach(el => {
        const fromText = Number.parseInt(el.textContent || '', 10);
        if (Number.isSafeInteger(fromText)) candidates.push(fromText);
        try {
          const fromUrl = Number.parseInt(new URL(el.href, location.href).searchParams.get('p') || '', 10);
          if (Number.isSafeInteger(fromUrl)) candidates.push(fromUrl);
        } catch (_) {}
      });
      return Math.max(...candidates);
    }

    function pageUrl(page) {
      const url = new URL(location.href);
      url.searchParams.set('p', String(page));
      url.hash = '';
      return url.href;
    }

    async function fetchReplyPage(page) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), CONFIG.threadTree.pageFetchTimeoutMs);
      try {
        const res = await fetch(pageUrl(page), {
          credentials: 'include',
          cache: 'no-store',
          signal: controller.signal,
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const doc = parseReplyDoc(await res.text());
        const replies = extractRepliesFromDoc(doc);
        if (!replies.length) throw new Error('页面中没有回复');
        return replies;
      } finally {
        clearTimeout(timer);
      }
    }

    async function fetchPages(pages, onProgress) {
      if (!pages.length) return [];
      const results = new Array(pages.length);
      let cursor = 0;
      let completed = 0;
      const worker = async () => {
        while (cursor < pages.length) {
          const index = cursor++;
          const page = pages[index];
          try {
            results[index] = { page, replies: await fetchReplyPage(page) };
          } catch (error) {
            results[index] = { page, replies: null, error };
          } finally {
            completed++;
            onProgress?.(completed, pages.length);
          }
        }
      };
      const workerCount = Math.min(CONFIG.threadTree.pageFetchConcurrency, pages.length);
      await Promise.all(Array.from({ length: workerCount }, () => worker()));
      return results;
    }

    // 个别页失败多半是并发触发的限流，静默重试一次再打扰用户。
    // 全军覆没则更可能是断网/掉登录，直接交给横幅让用户决定，避免再空等一轮超时。
    async function fetchPagesWithRetry(pages, onProgress) {
      const results = await fetchPages(pages, onProgress);
      const failedIndexes = results
        .map((result, index) => (result.replies ? -1 : index))
        .filter(index => index >= 0);
      if (!failedIndexes.length || failedIndexes.length === results.length) return results;

      await sleep(600);
      const retried = await fetchPages(failedIndexes.map(index => results[index].page));
      failedIndexes.forEach((resultIndex, i) => {
        if (retried[i]?.replies) results[resultIndex] = retried[i];
      });
      return results;
    }

    function normalizeReplies(replies) {
      const byId = new Map();
      for (const reply of replies) {
        if (!byId.has(reply.id)) byId.set(reply.id, reply);
      }
      const normalized = [...byId.values()].sort((a, b) => a.floorNum - b.floorNum);
      normalized.forEach((reply, index) => { reply.index = index; });
      return normalized;
    }

    // ── 主流程 ──
    async function init() {
      if (!isTopicPage()) return;
      initReplyFloorReference();
      const topicId = location.pathname.match(/\/t\/(\d+)/)?.[1];
      if (!topicId) return;

      const replyBox = Array.from(document.querySelectorAll('.box')).find(b => b.querySelector('div[id^="r_"]'));
      if (!replyBox) {
        // 帖子此刻还没有回复也要落一条进度：不然下次进来 stored 仍是 null、
        // 被当成首次访问，期间攒下的新回复一条都不会被标记。
        // （从首页点进刚发出来的新帖，就是这条路径。）
        const emptyState = createReadState(topicId);
        if (emptyState.firstVisit) commitReadState(emptyState, []);
        log('楼层树：没找到回复容器（.box 内无 div[id^="r_"]），已跳过');
        return;
      }

      const loadingBar = document.createElement('div');
      loadingBar.id = 'v2ex-loading-bar'; loadingBar.textContent = '加载中…';
      replyBox.parentNode.insertBefore(loadingBar, replyBox);

      const totalPages = getTotalPages();
      let allReplies = extractRepliesFromDoc(document);
      const requestedPage = Number.parseInt(new URLSearchParams(location.search).get('p') || '1', 10);
      const currentPage = Number.isSafeInteger(requestedPage) && requestedPage >= 1 && requestedPage <= totalPages
        ? requestedPage
        : 1;
      const pages = Array.from({ length: totalPages }, (_, i) => i + 1).filter(page => page !== currentPage);
      const pageResults = await fetchPagesWithRetry(pages, (completed, total) => {
        loadingBar.textContent = `加载回复页 ${completed} / ${total}…`;
      });

      const failedPages = pageResults.filter(result => !result.replies).map(result => result.page);
      for (const result of pageResults) {
        if (result.replies) allReplies.push(...result.replies);
        else log(`Reply page ${result.page} failed:`, result.error);
      }

      allReplies = normalizeReplies(allReplies);
      document.querySelectorAll('.page_input, .page_current, .page_normal').forEach(el => el.remove());

      // let 以便 doRetry 内可重新赋值
      let maps = buildLookupMaps(allReplies);
      const readState = createReadState(topicId);
      let newCount = markUnread(readState, allReplies);
      renderTree(allReplies, maps, replyBox, topicId);
      UserTags.decorate(replyBox);

      loadingBar.remove();
      log(`楼层树：${allReplies.length} 条回复 / 共 ${totalPages} 页（失败 ${failedPages.length} 页），`
        + `分支 ${replyBox.querySelectorAll('.reply-branch-toggle').length} 组，未读 ${newCount} 条`);
      document.querySelectorAll('a[name="last_page"]').forEach(e => e.remove());
      updateNewCountBar(replyBox, newCount);
      commitReadState(readState, allReplies);

      let hoverTimer = null;
      const scheduleHoverPreview = () => {
        clearTimeout(hoverTimer);
        // 250ms > B64 观察器的 150ms 防抖窗口：等它把本批 DOM 改完再挂预览，
        // 否则悬停预览可能落在尚未解码的原始文本上。
        hoverTimer = setTimeout(() => initHoverPreview(allReplies, maps), 250);
      };

      // ── 失败页重试（支持递归多次重试）──
      if (failedPages.length > 0) {
        const banner = document.createElement('div');
        banner.id = 'v2ex-retry-banner';
        replyBox.parentNode.insertBefore(banner, replyBox);

        const attachRetry = pagesToRetry => {
          const text = document.createElement('span');
          text.textContent = `⚠️ 第 ${pagesToRetry.join('、')} 页加载失败`;
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.textContent = '重试';
          banner.replaceChildren(text, btn);
          btn.addEventListener('click', async () => {
            btn.textContent = '重试中…'; btn.disabled = true;

            const results = await fetchPages(pagesToRetry, (completed, total) => {
              btn.textContent = `重试中 ${completed}/${total}…`;
            });
            const stillFailed = [];
            const newReplies = [];
            for (const result of results) {
              if (result.replies) newReplies.push(...result.replies);
              else {
                stillFailed.push(result.page);
                log(`Reply page ${result.page} retry failed:`, result.error);
              }
            }

            if (newReplies.length > 0) {
              allReplies = normalizeReplies([...allReplies, ...newReplies]);
              maps = buildLookupMaps(allReplies);
              newCount = markUnread(readState, allReplies);
              renderTree(allReplies, maps, replyBox, topicId);
              UserTags.decorate(replyBox);
              updateNewCountBar(replyBox, newCount);
              // 补回来的页可能填上了缺口，让连续前缀继续往前走；
              // 哪怕还有别的页没救回来，这一段进度也该存下
              commitReadState(readState, allReplies);
              scheduleHoverPreview();
            }

            if (stillFailed.length > 0) {
              attachRetry(stillFailed); // 仍有失败页 → 重新挂载按钮
            } else {
              banner.remove();
            }
          }, { once: true });
        };
        attachRetry([...failedPages]);
      }

      // 等待 B64 的防抖扫描完成本轮 DOM 处理（见 scheduleHoverPreview 的延时说明）。
      scheduleHoverPreview();
    }

    function boot() {
      init().catch(err => {
        document.getElementById('v2ex-loading-bar')?.remove();
        log('ThreadTree error:', err);
      });
    }
    return { boot, revealAncestors };
  })();

  // =========================
  // 6) 功能D：高赞回复阅览室（含图片 Lightbox）
  // =========================
  const HotRoom = (() => {

    // ── Lightbox ──
    function openLightbox(src) {
      if (!src) return;
      let lb = document.getElementById('v2ex-lightbox');
      if (!lb) {
        lb = document.createElement('div');
        lb.id = 'v2ex-lightbox';
        const img = document.createElement('img');
        img.alt = '';
        lb.appendChild(img);
        document.body.appendChild(lb);
        lb.addEventListener('click', () => lb.classList.remove('active'));
        document.addEventListener('keydown', e => {
          if (e.key === 'Escape' && lb.classList.contains('active')) lb.classList.remove('active');
        });
      }
      lb.querySelector('img').src = src;
      requestAnimationFrame(() => lb.classList.add('active'));
    }

    function extractComments() {
      const comments = [];
      document.querySelectorAll('.cell[id^="r_"]').forEach(cell => {
        try {
          let likes = 0;
          for (const span of cell.querySelectorAll('.small.fade')) {
            const text = span.textContent || '';
            const m1 = text.match(/(?:♥|❤️)\s*(\d+)/);
            if (m1) { likes = parseInt(m1[1], 10); break; }
            if (span.querySelector('img[alt="❤️"]') && text.trim().length > 0) {
              likes = parseInt(text.trim(), 10) || 0; break;
            }
          }
          if (likes > 0) {
            const content = cell.querySelector('.reply_content');
            const author = cell.querySelector('strong > a');
            comments.push({
              id: cell.id, likes,
              avatar:      cell.querySelector('img.avatar')?.src || '',
              username:    author?.textContent?.trim() || 'Unknown',
              userUrl:     author?.href || '#',
              time:        cell.querySelector('.ago')?.textContent?.trim() || '',
              contentNode: content?.cloneNode(true) || null,
              floor:       cell.querySelector('.no')?.textContent?.trim() || '#',
            });
          }
        } catch (_) {}
      });
      return comments.sort((a, b) => b.likes - a.likes);
    }

    function buildUI(comments) {
      const existing = document.getElementById('hot-overlay');
      existing?._cleanup?.();
      existing?.remove();
      const overlay   = document.createElement('div');
      overlay.id      = 'hot-overlay';
      const container = document.createElement('div');
      container.className = 'hot-container';

      if (!comments.length) {
        const empty = document.createElement('div');
        empty.style.cssText = 'text-align:center;padding:40px;color:#ccc;font-size:13px;';
        empty.textContent = '暂无高赞回复';
        container.appendChild(empty);
      } else {
        comments.forEach((c, index) => {
          const rankClass = index === 0 ? 'rank-1' : index === 1 ? 'rank-2' : index === 2 ? 'rank-3' : 'rank-normal';
          const card = document.createElement('div');
          card.className = `hot-card ${rankClass}`;

          const header = document.createElement('div');
          header.className = 'card-header-row';

          if (c.avatar) {
            const avatar = document.createElement('img');
            avatar.className = 'user-avatar'; avatar.src = c.avatar; avatar.alt = '';
            header.appendChild(avatar);
          }

          const user = document.createElement('a');
          user.className = 'user-name'; user.href = c.userUrl;
          user.target = '_blank'; user.rel = 'noreferrer noopener';
          user.textContent = c.username;
          header.appendChild(user);

          const floor = document.createElement('div');
          floor.className = 'floor-tag'; floor.title = '跳转'; floor.textContent = c.floor;
          floor.addEventListener('click', () => {
            closeOverlay(overlay);
            setTimeout(() => {
              const el = document.getElementById(c.id);
              if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }, 250);
          });
          header.appendChild(floor);

          const time = document.createElement('span');
          time.className = 'time-tag'; time.textContent = c.time;
          header.appendChild(time);

          const likes = document.createElement('div');
          likes.className = 'likes-pill'; likes.textContent = `♥ ${c.likes}`;
          header.appendChild(likes);

          const content = document.createElement('div');
          content.className = 'card-content';
          if (c.contentNode) content.append(...c.contentNode.childNodes);

          // ── Lightbox：为卡片内图片挂载点击处理 ──
          content.querySelectorAll('img').forEach(img => {
            img.addEventListener('click', e => {
              e.stopPropagation();
              openLightbox(img.src);
            });
          });

          card.appendChild(header);
          card.appendChild(content);
          container.appendChild(card);
        });
      }

      overlay.appendChild(container);
      document.body.appendChild(overlay);
      // 浮层挂在 body 上，不在 UserTags 的观察范围内，需要显式装饰一次
      UserTags.decorate(overlay);
      overlay.addEventListener('click', e => { if (e.target === overlay) closeOverlay(overlay); });
      const onKey = e => {
        if (e.key !== 'Escape' || document.getElementById('v2ex-lightbox')?.classList.contains('active')) return;
        closeOverlay(overlay);
      };
      document.addEventListener('keydown', onKey);
      overlay._cleanup = () => document.removeEventListener('keydown', onKey);
      return overlay;
    }

    function closeOverlay(overlay) {
      if (!overlay) return;
      overlay.classList.remove('active');
      setTimeout(() => {
        if (!overlay.classList.contains('active')) { overlay._cleanup?.(); overlay.remove(); }
      }, 200);
    }

    function extractPageUsers() {
      const users = new Map();
      const anchors = document.querySelectorAll([
        '#Main .header small.gray > a[href*="/member/"]',
        '#Main .cell[id^="r_"] strong > a[href*="/member/"]',
      ].join(','));
      for (const anchor of anchors) {
        try {
          const match = /^\/member\/([^/?#]+)/.exec(new URL(anchor.href, location.origin).pathname);
          if (!match) continue;
          const name = decodeURIComponent(match[1]).trim();
          const key = name.toLowerCase();
          if (name && !users.has(key)) users.set(key, name);
        } catch (_) {}
      }
      return [...users.values()];
    }

    function toggleBulkPanel(actionBar) {
      const existing = document.getElementById('v2t-bulk-panel');
      if (existing) { existing.remove(); return; }

      const users = extractPageUsers();
      const panel = document.createElement('div');
      panel.id = 'v2t-bulk-panel';
      panel.className = 'cell v2t-bulk-panel';

      const count = document.createElement('span');
      count.className = 'v2t-bulk-count';
      count.textContent = `${users.length} 位用户`;
      const input = document.createElement('input');
      input.type = 'text';
      input.maxLength = CONFIG.tags.maxTagLength;
      input.placeholder = '标签内容';
      input.setAttribute('aria-label', '批量添加的标签内容');
      const colorPicker = UserTags.createColorPicker();
      const apply = document.createElement('button');
      apply.type = 'button';
      apply.className = 'v2t-btn primary';
      apply.textContent = '添加';
      const cancel = document.createElement('button');
      cancel.type = 'button';
      cancel.className = 'v2t-btn';
      cancel.textContent = '取消';
      cancel.addEventListener('click', () => panel.remove());

      const commit = () => {
        const tag = input.value.replace(/\s+/g, ' ').trim();
        if (!tag) { UserTags.toast('请先输入标签'); input.focus(); return; }
        const latestUsers = extractPageUsers();
        const stats = UserTags.bulkAdd(latestUsers, tag, colorPicker.dataset.color);
        const details = [
          `已添加 ${stats.added}`,
          stats.already ? `重复 ${stats.already}` : '',
          stats.full ? `已满 ${stats.full}` : '',
        ].filter(Boolean).join(' · ');
        UserTags.toast(`${tag}：${details}`);
        if (stats.added) {
          input.value = '';
          input.focus();
        }
      };
      apply.addEventListener('click', commit);
      input.addEventListener('keydown', event => {
        if (event.key === 'Enter') { event.preventDefault(); commit(); }
        else if (event.key === 'Escape') panel.remove();
      });

      panel.append(count, input, colorPicker, apply, cancel);
      actionBar.insertAdjacentElement('afterend', panel);
      input.focus();
    }

    function openHotRoom() {
      const overlay = buildUI(extractComments());
      requestAnimationFrame(() => overlay.classList.add('active'));
    }

    function boot() {
      if (!isTopicPage()) return;
      setTimeout(() => {
        const topicBox = document.querySelector('#Main > .box');
        const actionBar = topicBox?.querySelector('.topic_buttons');
        const thankSlot = actionBar?.querySelector('#topic_thank');
        const thank = thankSlot?.querySelector('a')
          || [...(actionBar?.querySelectorAll('a') || [])].find(anchor => anchor.textContent.trim() === '感谢');
        if (!actionBar || document.getElementById('v2ex-bulk-btn')) return;

        const bulk = document.createElement('a');
        bulk.id = 'v2ex-bulk-btn';
        bulk.className = thank?.className || 'tb';
        bulk.href = '#;';
        bulk.textContent = '加标签';
        bulk.title = '给当前主题中的全部用户添加同一个标签';
        bulk.addEventListener('click', event => {
          event.preventDefault();
          event.stopPropagation();
          toggleBulkPanel(actionBar);
        });

        const hot = document.createElement('a');
        hot.id = 'v2ex-hot-btn';
        hot.className = thank?.className || 'tb';
        hot.href = '#;';
        hot.textContent = '高赞';
        hot.title = '查看高赞回复';
        hot.addEventListener('click', event => {
          event.preventDefault();
          event.stopPropagation();
          openHotRoom();
        });

        const nodes = [document.createTextNode('\u00a0 \u00a0'), bulk,
          document.createTextNode('\u00a0 \u00a0'), hot];
        if (thankSlot) thankSlot.after(...nodes);
        else actionBar.append(...nodes);
      }, 500);
    }

    return { boot };
  })();

  // =========================
  // 7) 功能E：j/k 键盘导航（按需刷新，无常驻扫描）
  // =========================
  const NavKeys = (() => {
    const SCROLL_OFFSET_RATIO = CONFIG.nav.scrollOffsetRatio;
    let newReplies = [], curIndex = -1, hudTimer = null, activeReply = null;
    let listDirty = true;

    // HUD 每次按键都重建 innerHTML 的话，等于每次都重新解析一遍 HTML；
    // 结构建一次留着，之后只改箭头和计数两处文本。
    let hud = null;
    let hudArrow = null;
    let hudIndex = null;
    let hudTotal = null;
    function buildHud() {
      hud = document.createElement('div');
      hud.id = 'v2ex-nav-hud';
      hudArrow = document.createElement('span');
      hudArrow.className = 'hud-arrow';
      const label = document.createElement('span');
      label.className = 'hud-label';
      label.textContent = 'NEW';
      const sep = document.createElement('span');
      sep.className = 'hud-sep';
      sep.textContent = ' / ';
      hudIndex = document.createTextNode('');
      hudTotal = document.createTextNode('');
      const count = document.createElement('span');
      count.className = 'hud-count';
      count.append(hudIndex, sep, hudTotal);
      const hint = document.createElement('span');
      hint.className = 'hud-hint';
      hint.textContent = 'j↓ k↑';
      hud.append(hudArrow, label, count, hint);
      document.body.appendChild(hud);
    }
    function showHud(index, total, direction) {
      if (!hud?.isConnected) buildHud();
      hudArrow.textContent = direction === 'next' ? '↓' : '↑';
      hudIndex.nodeValue = String(index + 1);
      hudTotal.nodeValue = String(total);
      hud.classList.add('visible');
      clearTimeout(hudTimer);
      hudTimer = setTimeout(() => hud.classList.remove('visible'), 2200);
    }
    function scrollToReply(el) {
      const targetTop = el.getBoundingClientRect().top + window.scrollY - window.innerHeight * SCROLL_OFFSET_RATIO;
      window.scrollTo({ top: Math.max(0, targetTop), behavior: 'smooth' });
    }
    function setActive(el) {
      if (activeReply) (activeReply.closest('.reply-wrapper') || activeReply).classList.remove('reply-nav-active');
      activeReply = el || null;
      if (el) (el.closest('.reply-wrapper') || el).classList.add('reply-nav-active');
    }
    function refreshList() {
      if (!listDirty) return;
      listDirty = false;
      newReplies = Array.from(document.querySelectorAll('.reply-new'));
      const activeIndex = activeReply ? newReplies.indexOf(activeReply) : -1;
      curIndex = activeIndex >= 0 ? activeIndex : -1;
    }
    function navigate(direction) {
      refreshList();
      if (!newReplies.length) return;
      curIndex = direction === 'next'
        ? Math.min(curIndex + 1, newReplies.length - 1)
        : (curIndex < 0 ? newReplies.length - 1 : Math.max(curIndex - 1, 0));
      const target = newReplies[curIndex];
      setActive(target);
      // 目标可能藏在折叠的子树里，先展开再滚动，否则会滚到一片空白
      ThreadTree.revealAncestors(target);
      scrollToReply(target);
      showHud(curIndex, newReplies.length, direction);
    }
    function onKeyDown(e) {
      const tag = document.activeElement?.tagName?.toLowerCase();
      if (tag === 'input' || tag === 'textarea' || tag === 'select' || document.activeElement?.isContentEditable) return;
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      // 有浮层时把按键让给浮层
      if (document.getElementById('hot-overlay')?.classList.contains('active')) return;
      if (document.getElementById('v2t-manager')?.classList.contains('active')) return;
      if (document.getElementById('v2ex-lightbox')?.classList.contains('active')) return;
      if (document.getElementById('v2t-editor')?.classList.contains('visible')) return;
      if (e.key === 'j') { e.preventDefault(); navigate('next'); }
      else if (e.key === 'k') { e.preventDefault(); navigate('prev'); }
    }
    function boot() {
      if (!isTopicPage()) return;
      document.addEventListener('v2ex:replies-updated', () => { listDirty = true; });
      document.addEventListener('keydown', onKeyDown);
    }
    return { boot };
  })();

  // =========================
  // 8) 功能F：Imgur 图片代理
  // =========================
  const ImgurProxy = (() => {
    const { storeKey, proxyEnabled } = CONFIG.imgur;
    const originalImages = new WeakMap();
    const proxiedImages = new Set();
    const originalLinks = new WeakMap();
    const proxiedLinks = new Set();
    let enabled = proxyEnabled;
    let observer = null;
    const isEnabled = () => enabled;
    const refreshMenu = createToggleMenu('Imgur 图片代理', isEnabled, () => setEnabled(!enabled));

    function parseImgurUrl(value) {
      if (!value) return null;
      try {
        const url = new URL(value.startsWith('//') ? `https:${value}` : value, location.href);
        const host = url.hostname.toLowerCase();
        return host === 'imgur.com' || host.endsWith('.imgur.com') ? url : null;
      } catch (_) { return null; }
    }

    function proxyUrl(url) {
      return `https://external-content.duckduckgo.com/iu/?u=${encodeURIComponent(url.href)}&f=1&nofb=1`;
    }

    function isDirectImage(url) {
      return url.hostname.toLowerCase() === 'i.imgur.com' || /\.(?:avif|gif|jpe?g|png|webp)$/i.test(url.pathname);
    }

    function processLink(link) {
      if (link?.tagName !== 'A') return;
      const previous = originalLinks.get(link);
      if (previous?.proxy === link.getAttribute('href')) return;
      if (previous) { originalLinks.delete(link); proxiedLinks.delete(link); }
      const href = link.getAttribute('href');
      const url = parseImgurUrl(href);
      if (!url || !isDirectImage(url)) return;
      const proxy = proxyUrl(url);
      originalLinks.set(link, { href, proxy });
      proxiedLinks.add(link);
      link.setAttribute('href', proxy);
    }

    function processImage(img) {
      if (!enabled) return;
      const src = img.getAttribute('src');
      const previous = originalImages.get(img);
      if (previous?.proxy === src) return;
      if (previous) {
        originalImages.delete(img);
        proxiedImages.delete(img);
        delete img.dataset.proxied;
      }
      const imgurUrl = parseImgurUrl(src);
      if (!imgurUrl) return;
      const proxy = proxyUrl(imgurUrl);
      originalImages.set(img, { src, proxy });
      proxiedImages.add(img);
      img.dataset.proxied = '1';
      img.setAttribute('src', proxy);
      processLink(img.parentElement);
    }

    function restoreAll() {
      for (const img of proxiedImages) {
        const original = originalImages.get(img);
        if (original && img.getAttribute('src') === original.proxy) img.setAttribute('src', original.src);
        originalImages.delete(img);
        delete img.dataset.proxied;
      }
      proxiedImages.clear();
      for (const link of proxiedLinks) {
        const original = originalLinks.get(link);
        if (original && link.getAttribute('href') === original.proxy) link.setAttribute('href', original.href);
        originalLinks.delete(link);
      }
      proxiedLinks.clear();
    }

    function applyEnabled(next) {
      if (enabled === next) return;
      enabled = next;
      if (!isTopicPage()) return;
      if (enabled) {
        scanAll();
        startObserving();
      } else {
        observer?.disconnect();
        observer = null;
        restoreAll();
      }
    }

    function setEnabled(value) {
      const next = Boolean(value);
      if (!GM.set(storeKey, next)) return false;
      applyEnabled(next);
      refreshMenu();
      return true;
    }

    function processNode(node) {
      if (!enabled || node.nodeType !== Node.ELEMENT_NODE) return;
      if (node.matches('img')) processImage(node);
      node.querySelectorAll('img').forEach(processImage);
    }

    function scanAll() { document.querySelectorAll('img[src*="imgur.com"]').forEach(processImage); }
    function startObserving() {
      if (observer) return;
      // Imgur 图只出现在话题/回复正文里：初始扫描保持全页兜底，
      // 增量观察则收窄到 #Main，关闭代理时完全停止观察。
      const root = document.querySelector('#Main') || document.body;
      const enqueueImages = createSubtreeBatch(processNode, 0);
      observer = new MutationObserver(mutations => {
        for (const mutation of mutations) {
          if (mutation.type === 'attributes') enqueueImages(mutation.target);
          else for (const node of mutation.addedNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) enqueueImages(node);
          }
        }
      });
      observer.observe(root, { childList: true, subtree: true, attributes: true, attributeFilter: ['src'] });
    }
    function boot() {
      enabled = GM.get(storeKey, proxyEnabled) !== false;
      GM.onChange(storeKey, next => {
        applyEnabled((next === undefined ? GM.get(storeKey, proxyEnabled) : next) !== false);
        refreshMenu();
      });
      refreshMenu();
      if (!isTopicPage()) return;
      if (enabled) { scanAll(); startObserving(); }
    }
    return { boot, isEnabled, setEnabled };
  })();

  // =========================
  // 9) 功能G：用户标签（本地存储 / 导入导出 / 合并）
  // =========================
  const UserTags = (() => {
    const { storeKey, maxTagLength, maxTagsPerUser, tombstoneTtlMs, exportVersion } = CONFIG.tags;

    // 色点与标签文字色分离：候选色可以更明快，标签正文仍使用满足小字号
    // 可读性的深色 ink。保留全部旧 key 与存储结构，已有标签无需迁移。
    const COLORS = [
      { key: 'violet', swatch: '#9b6cf2', ink: '#6d3fc0', label: '柔紫' },
      { key: 'indigo', swatch: '#657ce8', ink: '#4658b5', label: '靛蓝' },
      { key: 'teal',   swatch: '#2da79b', ink: '#1f756f', label: '湖青' },
      { key: 'green',  swatch: '#71ad55', ink: '#4c783a', label: '草绿' },
      { key: 'amber',  swatch: '#d69a3a', ink: '#95601b', label: '琥珀' },
      { key: 'red',    swatch: '#ea735f', ink: '#ab493d', label: '珊瑚' },
      { key: 'pink',   swatch: '#dd668b', ink: '#a94467', label: '莓粉' },
      { key: 'slate',  swatch: '#8792a3', ink: '#5f6876', label: '雾灰' },
    ];
    const COLOR_MAP = new Map(COLORS.map(color => [color.key, color]));
    const DEFAULT_COLOR = 'violet';

    // 固定色位很重要：若每次把当前颜色从候选数组里删掉，剩余颜色会整体换位，
    // 用户会觉得颜色在“乱跑”。这里按视觉色相固定为一条短弧，当前色只加选中环。
    const COLOR_ORBIT_KEYS = ['slate', 'teal', 'indigo', 'violet', 'pink', 'red', 'amber', 'green'];
    const COLOR_ORBIT_RADIUS = 74;
    const COLOR_ORBIT_SPREAD = Math.PI * 156 / 180;
    const COLOR_ORBIT_BIAS_X = -16;
    const COLOR_OPTION_RADIUS = 15;
    const COLOR_ORBIT_EDGE = 8;

    let colorOrbit = null;
    let activeColorPicker = null;
    let colorPlaceFrame = 0;

    const colorItem = key => COLOR_MAP.get(key) || COLORS[0];

    function scheduleColorOrbitPlace() {
      if (colorPlaceFrame || !activeColorPicker) return;
      colorPlaceFrame = requestAnimationFrame(() => {
        colorPlaceFrame = 0;
        placeColorOrbit();
      });
    }

    function trackColorOrbit(enable) {
      const action = enable ? 'addEventListener' : 'removeEventListener';
      window[action]('resize', scheduleColorOrbitPlace);
      window[action]('scroll', scheduleColorOrbitPlace, true);
    }

    function closeColorPickers() {
      const picker = activeColorPicker;
      if (!picker) return;
      activeColorPicker = null;
      picker.classList.remove('open');
      picker.querySelector('.v2t-color-current')?.setAttribute('aria-expanded', 'false');
      colorOrbit?.classList.remove('open');
      colorOrbit?.setAttribute('aria-hidden', 'true');
      colorOrbit?.querySelectorAll('.v2t-color-option').forEach(option => { option.tabIndex = -1; });
      trackColorOrbit(false);
      if (colorPlaceFrame) cancelAnimationFrame(colorPlaceFrame);
      colorPlaceFrame = 0;
    }

    function refreshColorOrbit() {
      if (!colorOrbit || !activeColorPicker) return;
      const selected = colorItem(activeColorPicker.dataset.color);
      colorOrbit.querySelectorAll('.v2t-color-option').forEach(option => {
        const isSelected = option.dataset.color === selected.key;
        option.setAttribute('aria-selected', String(isSelected));
        option.tabIndex = isSelected ? 0 : -1;
      });
    }

    function placeColorOrbit() {
      if (!activeColorPicker?.isConnected || !colorOrbit?.isConnected) {
        closeColorPickers();
        return;
      }

      const anchor = activeColorPicker.querySelector('.v2t-color-current');
      const rect = anchor.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      const viewportW = document.documentElement.clientWidth;
      const viewportH = document.documentElement.clientHeight;
      const topSpace = centerY - COLOR_ORBIT_EDGE;
      const bottomSpace = viewportH - centerY - COLOR_ORBIT_EDGE;
      const requiredSpace = COLOR_ORBIT_RADIUS + COLOR_OPTION_RADIUS + 3;
      const opensDown = topSpace < requiredSpace && bottomSpace > topSpace;
      const available = opensDown ? bottomSpace : topSpace;
      const radius = Math.max(58, Math.min(COLOR_ORBIT_RADIUS, available - COLOR_OPTION_RADIUS - 2));
      const startAngle = -Math.PI / 2 - COLOR_ORBIT_SPREAD / 2;
      const options = [...colorOrbit.querySelectorAll('.v2t-color-option')];

      const points = options.map((_, index) => {
        const angle = startAngle + COLOR_ORBIT_SPREAD * index / Math.max(1, options.length - 1);
        return {
          x: Math.cos(angle) * radius,
          y: Math.sin(angle) * radius * (opensDown ? -1 : 1),
        };
      });

      // 默认稍向左偏，避开右侧删除按钮；接近屏幕边缘时再整体平移，弧形不变形。
      let shiftX = COLOR_ORBIT_BIAS_X;
      const minX = Math.min(...points.map(point => point.x)) - COLOR_OPTION_RADIUS;
      const maxX = Math.max(...points.map(point => point.x)) + COLOR_OPTION_RADIUS;
      if (centerX + minX + shiftX < COLOR_ORBIT_EDGE) {
        shiftX += COLOR_ORBIT_EDGE - (centerX + minX + shiftX);
      }
      if (centerX + maxX + shiftX > viewportW - COLOR_ORBIT_EDGE) {
        shiftX -= centerX + maxX + shiftX - (viewportW - COLOR_ORBIT_EDGE);
      }

      colorOrbit.style.left = `${Math.round(centerX)}px`;
      colorOrbit.style.top = `${Math.round(centerY)}px`;
      colorOrbit.dataset.direction = opensDown ? 'down' : 'up';
      points.forEach((point, index) => {
        options[index].style.setProperty('--v2t-x', `${Math.round(point.x + shiftX)}px`);
        options[index].style.setProperty('--v2t-y', `${Math.round(point.y)}px`);
      });
    }

    function ensureColorOrbit() {
      if (colorOrbit?.isConnected) return colorOrbit;

      colorOrbit = document.createElement('div');
      colorOrbit.className = 'v2t-color-orbit';
      colorOrbit.setAttribute('role', 'listbox');
      colorOrbit.setAttribute('aria-label', '标签颜色');
      colorOrbit.setAttribute('aria-hidden', 'true');

      const orbitColors = COLOR_ORBIT_KEYS.map(colorItem);
      orbitColors.forEach((item, index) => {
        const option = document.createElement('button');
        option.type = 'button';
        option.className = 'v2t-color-option';
        option.dataset.color = item.key;
        option.style.setProperty('--v2t-swatch', item.swatch);
        // 从弧顶向两端对称展开，最大延迟不足 25ms，不形成从左到右的“贪吃蛇”。
        option.style.setProperty('--v2t-seq', Math.abs(index - (orbitColors.length - 1) / 2));
        option.setAttribute('role', 'option');
        option.setAttribute('aria-label', item.label);
        option.title = item.label;
        option.tabIndex = -1;
        option.addEventListener('click', event => {
          event.preventDefault();
          event.stopPropagation();
          if (!activeColorPicker) return;
          const returnTarget = activeColorPicker.querySelector('.v2t-color-current');
          activeColorPicker.dataset.color = item.key;
          activeColorPicker.style.setProperty('--v2t-swatch', item.swatch);
          returnTarget.setAttribute('aria-label', `当前颜色：${item.label}，点击更改`);
          returnTarget.title = item.label;
          closeColorPickers();
          returnTarget?.focus();
        });
        colorOrbit.appendChild(option);
      });

      colorOrbit.addEventListener('keydown', event => {
        if (event.key === 'Escape') {
          event.preventDefault();
          const returnTarget = activeColorPicker?.querySelector('.v2t-color-current');
          closeColorPickers();
          returnTarget?.focus();
          return;
        }

        const options = [...colorOrbit.querySelectorAll('.v2t-color-option')];
        const currentIndex = Math.max(0, options.indexOf(document.activeElement));
        let nextIndex = null;
        if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
          nextIndex = (currentIndex + 1) % options.length;
        } else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
          nextIndex = (currentIndex - 1 + options.length) % options.length;
        } else if (event.key === 'Home') {
          nextIndex = 0;
        } else if (event.key === 'End') {
          nextIndex = options.length - 1;
        } else if (event.key === 'Tab') {
          closeColorPickers();
          return;
        }
        if (nextIndex === null) return;
        event.preventDefault();
        options[nextIndex].focus();
      });

      document.body.appendChild(colorOrbit);
      return colorOrbit;
    }

    function openColorPicker(wrapper, focusSelected = false) {
      if (activeColorPicker === wrapper) {
        if (focusSelected) {
          refreshColorOrbit();
          colorOrbit?.querySelector('[aria-selected="true"]')?.focus();
        } else {
          closeColorPickers();
        }
        return;
      }

      closeColorPickers();
      ensureColorOrbit();
      activeColorPicker = wrapper;
      wrapper.classList.add('open');
      wrapper.querySelector('.v2t-color-current')?.setAttribute('aria-expanded', 'true');
      refreshColorOrbit();
      placeColorOrbit();
      colorOrbit.setAttribute('aria-hidden', 'false');
      // 先落坐标、下一帧再展开，确保每颗颜色都真正从中心出发。
      requestAnimationFrame(() => {
        if (activeColorPicker !== wrapper) return;
        colorOrbit.classList.add('open');
        placeColorOrbit();
        if (focusSelected) colorOrbit.querySelector('[aria-selected="true"]')?.focus();
      });
      trackColorOrbit(true);
    }

    function createColorPicker(initialColor = DEFAULT_COLOR) {
      const wrapper = document.createElement('span');
      wrapper.className = 'v2t-color-picker';
      wrapper.dataset.color = COLOR_MAP.has(initialColor) ? initialColor : DEFAULT_COLOR;

      const current = document.createElement('button');
      current.type = 'button';
      current.className = 'v2t-color-current';
      current.setAttribute('aria-haspopup', 'listbox');
      current.setAttribute('aria-expanded', 'false');

      const syncCurrent = () => {
        const selected = colorItem(wrapper.dataset.color);
        wrapper.style.setProperty('--v2t-swatch', selected.swatch);
        current.setAttribute('aria-label', `当前颜色：${selected.label}，点击更改`);
        current.title = selected.label;
      };

      current.addEventListener('click', event => {
        event.preventDefault();
        event.stopPropagation();
        openColorPicker(wrapper);
      });
      current.addEventListener('keydown', event => {
        if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') return;
        event.preventDefault();
        openColorPicker(wrapper, true);
      });

      syncCurrent();
      wrapper.appendChild(current);
      return wrapper;
    }

    // 会员链接出现的位置。.topic_info 那条覆盖所有主题列表页——首页、节点页、
    // /recent、/my/topics、个人主页——里面的作者和"最后回复来自"两个用户名；
    // 它只出现在列表项里，所以不会误伤主题页。限定 strong > a 是为了跳过
    // 同一行里那个只包着头像的 <a href="/member/x">，否则会往头像后面塞胶囊。
    const AUTHOR_SELECTOR = [
      'div.cell[id^="r_"] strong > a[href*="/member/"]',   // 回复楼层
      '#Main .header small.gray > a[href*="/member/"]',    // 主题头部作者
      '.topic_info strong > a[href*="/member/"]',          // 主题列表：作者 / 最后回复
      '.hot-card a.user-name',                             // 高赞阅览室卡片
    ].join(',');

    // ── 存储层 ──
    // 结构：{ v:2, tags: { <小写用户名>: {name, tags:[{tag,color}], updatedAt} }, deleted: { <小写用户名>: ts } }
    // deleted 是墓碑，保证"删除"在跨浏览器合并时也能正确传播（否则旧数据会把删掉的标签复活）。
    let store = null;

    const emptyStore = () => ({ v: exportVersion, tags: {}, deleted: {} });
    const keyOf = name => String(name ?? '').trim().toLowerCase();

    function sanitizeTag(raw) {
      if (!raw || typeof raw !== 'object') return null;
      const tag = typeof raw.tag === 'string' ? raw.tag.replace(/\s+/g, ' ').trim().slice(0, maxTagLength) : '';
      if (!tag) return null;
      return { tag, color: COLOR_MAP.has(raw.color) ? raw.color : DEFAULT_COLOR };
    }

    function sanitizeEntry(raw, fallbackName) {
      if (!raw || typeof raw !== 'object') return null;
      const name = typeof raw.name === 'string' && raw.name.trim() ? raw.name.trim() : String(fallbackName ?? '').trim();
      const source = Array.isArray(raw.tags) ? raw.tags : [];
      const tags = [];
      const seen = new Set();
      for (const item of source) {
        const clean = sanitizeTag(item);
        const key = clean?.tag.toLocaleLowerCase();
        if (!clean || seen.has(key)) continue;
        seen.add(key);
        tags.push(clean);
        if (tags.length >= maxTagsPerUser) break;
      }
      if (!tags.length) return null;
      const updatedAt = Number.isFinite(Number(raw.updatedAt)) && Number(raw.updatedAt) > 0 ? Number(raw.updatedAt) : 0;
      return {
        name: name || String(fallbackName || tags[0].tag),
        tags,
        updatedAt,
      };
    }

    function normalizeStore(raw) {
      const next = emptyStore();
      if (!raw || typeof raw !== 'object') return next;
      for (const [k, v] of Object.entries(raw.tags || {})) {
        const key = keyOf(k);
        const entry = sanitizeEntry(v, k);
        if (key && entry) next.tags[key] = entry;
      }
      for (const [k, v] of Object.entries(raw.deleted || {})) {
        const key = keyOf(k);
        const ts = Number(v);
        if (key && Number.isFinite(ts) && ts > 0) next.deleted[key] = ts;
      }
      return next;
    }

    function pruneTombstones(target, now = Date.now()) {
      for (const [k, ts] of Object.entries(target.deleted)) {
        if (now - ts > tombstoneTtlMs) delete target.deleted[k];
      }
      return target;
    }

    function load() {
      if (!store) store = normalizeStore(GM.get(storeKey, null));
      return store;
    }

    function persist(next) {
      pruneTombstones(next);
      store = next;
      GM.set(storeKey, next);
      repaintAll();
      Manager.refresh();
    }

    const get = name => load().tags[keyOf(name)] || null;

    function setTags(name, tags) {
      const key = keyOf(name);
      if (!key) return false;
      const entry = sanitizeEntry({ name, tags, updatedAt: Date.now() }, name);
      if (!entry) return removeTags(name);
      const next = { v: exportVersion, tags: { ...load().tags }, deleted: { ...load().deleted } };
      next.tags[key] = entry;
      delete next.deleted[key];
      persist(next);
      return true;
    }

    function removeTags(name) {
      const key = keyOf(name);
      const current = load();
      if (!key || !current.tags[key]) return false;
      const next = { v: exportVersion, tags: { ...current.tags }, deleted: { ...current.deleted } };
      delete next.tags[key];
      next.deleted[key] = Date.now();
      persist(next);
      return true;
    }

    function bulkAdd(names, tag, color) {
      const cleanTag = sanitizeTag({ tag, color });
      if (!cleanTag) return { total: 0, added: 0, already: 0, full: 0 };
      const unique = new Map();
      for (const name of names) {
        const key = keyOf(name);
        if (key && !unique.has(key)) unique.set(key, String(name).trim());
      }

      const current = load();
      const next = { v: exportVersion, tags: { ...current.tags }, deleted: { ...current.deleted } };
      const stats = { total: unique.size, added: 0, already: 0, full: 0 };
      const now = Date.now();
      const tagKey = cleanTag.tag.toLocaleLowerCase();

      for (const [key, name] of unique) {
        const existing = next.tags[key];
        if (existing?.tags.some(item => item.tag.toLocaleLowerCase() === tagKey)) {
          stats.already++;
          continue;
        }
        if (existing?.tags.length >= maxTagsPerUser) {
          stats.full++;
          continue;
        }
        next.tags[key] = {
          name: existing?.name || name,
          tags: [...(existing?.tags || []), { ...cleanTag }],
          updatedAt: now,
        };
        delete next.deleted[key];
        stats.added++;
      }
      if (stats.added) persist(next);
      return stats;
    }

    function entries() {
      return Object.entries(load().tags)
        .map(([key, entry]) => ({ key, ...entry }))
        .sort((a, b) => b.updatedAt - a.updatedAt || a.key.localeCompare(b.key));
    }

    // 最近使用过的标签文本，按使用频次 + 新旧排序，用作编辑气泡里的快捷输入
    function suggestions(limit = 8) {
      const counter = new Map();
      for (const entry of Object.values(load().tags)) {
        for (const tag of entry.tags) {
          const item = counter.get(tag.tag) || { tag: tag.tag, color: tag.color, count: 0, updatedAt: 0 };
          item.count++;
          item.updatedAt = Math.max(item.updatedAt, entry.updatedAt);
          counter.set(tag.tag, item);
        }
      }
      return [...counter.values()]
        .sort((a, b) => b.count - a.count || b.updatedAt - a.updatedAt)
        .slice(0, limit);
    }

    // ── 导入 / 导出 / 合并 ──
    function exportPayload() {
      const current = load();
      return {
        app: 'v2ex-tweaks',
        kind: 'user-tags',
        version: exportVersion,
        exportedAt: Date.now(),
        count: Object.keys(current.tags).length,
        tagCount: Object.values(current.tags).reduce((sum, entry) => sum + entry.tags.length, 0),
        tags: current.tags,
        deleted: current.deleted,
      };
    }

    // 只接受本版本导出的 v2 完整包，避免旧格式的歧义进入多标签数据。
    function parseImport(text) {
      let data;
      try { data = JSON.parse(text); }
      catch (_) { throw new Error('不是合法的 JSON 文件'); }
      if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('文件内容不是标签数据');

      if (data.app !== 'v2ex-tweaks' || data.kind !== 'user-tags' || data.version !== exportVersion) {
        throw new Error(`只支持 V2EX Tweaks v${exportVersion} 导出的标签文件`);
      }
      if (!data.tags || typeof data.tags !== 'object' || Array.isArray(data.tags)) throw new Error('文件缺少 tags 字段');
      const rawTags = data.tags;
      const rawDeleted = (data.deleted && typeof data.deleted === 'object') ? data.deleted : {};

      const tags = {};
      const deleted = {};
      let invalid = 0;
      for (const [k, v] of Object.entries(rawTags)) {
        const key = keyOf(k);
        const entry = sanitizeEntry(v, k);
        if (!key || !entry) { invalid++; continue; }
        if (!tags[key] || entry.updatedAt > tags[key].updatedAt) tags[key] = entry;
      }
      for (const [k, v] of Object.entries(rawDeleted)) {
        const key = keyOf(k);
        const ts = Number(v);
        if (key && Number.isFinite(ts) && ts > 0) deleted[key] = ts;
      }
      if (!Object.keys(tags).length && !Object.keys(deleted).length) throw new Error('文件里没有可导入的标签');
      return { tags, deleted, invalid };
    }

    // strategy: smart（按更新时间取新，尊重删除墓碑）/ add（只补充本地没有的）/ replace（用文件完全覆盖）
    function computeMerge(incoming, strategy) {
      const base = load();
      const next = strategy === 'replace'
        ? emptyStore()
        : { v: exportVersion, tags: { ...base.tags }, deleted: { ...base.deleted } };

      for (const [key, entry] of Object.entries(incoming.tags)) {
        const local = next.tags[key];
        if (strategy === 'add') {
          if (!local) { next.tags[key] = entry; delete next.deleted[key]; }
          continue;
        }
        if (strategy === 'smart' && (next.deleted[key] || 0) > entry.updatedAt) continue;
        if (!local || entry.updatedAt > local.updatedAt) {
          next.tags[key] = entry;
          delete next.deleted[key];
        }
      }

      if (strategy !== 'add') {
        for (const [key, ts] of Object.entries(incoming.deleted)) {
          const local = next.tags[key];
          if (local && ts > local.updatedAt) delete next.tags[key];
          if (!next.tags[key]) next.deleted[key] = Math.max(next.deleted[key] || 0, ts);
        }
      }

      pruneTombstones(next);

      const stats = { added: 0, updated: 0, removed: 0, unchanged: 0, invalid: incoming.invalid };
      for (const [key, entry] of Object.entries(next.tags)) {
        const local = base.tags[key];
        if (!local) stats.added++;
        else if (JSON.stringify(local.tags) !== JSON.stringify(entry.tags) || local.name !== entry.name) stats.updated++;
        else stats.unchanged++;
      }
      for (const key of Object.keys(base.tags)) if (!next.tags[key]) stats.removed++;
      return { stats, next };
    }

    function download(filename, text) {
      const url = URL.createObjectURL(new Blob([text], { type: 'application/json;charset=utf-8' }));
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
    }

    function exportTags() {
      const payload = exportPayload();
      if (!payload.count) { toast('还没有标签可导出'); return; }
      download(`v2ex-user-tags-${ymd()}.json`, JSON.stringify(payload, null, 2));
      toast(`已导出 ${payload.count} 个用户、${payload.tagCount} 个标签`);
    }

    // ── Toast ──
    let toastTimer = 0;
    function toast(message) {
      let el = document.getElementById('v2t-toast');
      if (!el) {
        el = document.createElement('div');
        el.id = 'v2t-toast';
        document.body.appendChild(el);
      }
      el.textContent = message;
      requestAnimationFrame(() => el.classList.add('visible'));
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => el.classList.remove('visible'), 2200);
    }

    // ── 胶囊渲染 ──
    // 8 色的 CSS 变量在启动时只计算一次。swatch 负责色点/淡底，ink 负责浅色
    // 模式下的小字号正文；这样色板不必为了文字对比度而整体变暗、变脏。
    const CHIP_CSS = new Map(COLORS.map(({ key, swatch, ink }) => [key, [
      `--v2t-chip-bg:${hexToRgba(swatch, 0.13)}`,
      `--v2t-chip-fg:${ink}`,
      `--v2t-chip-dot:${swatch}`,
      `--v2t-chip-bd:${hexToRgba(swatch, 0.30)}`,
      `--v2t-chip-bg-n:${hexToRgba(swatch, 0.22)}`,
      `--v2t-chip-fg-n:${lightenHex(swatch, 0.12)}`,
      `--v2t-chip-bd-n:${hexToRgba(swatch, 0.43)}`,
    ].join(';')]));

    function userFromLink(anchor) {
      try {
        const path = new URL(anchor.getAttribute('href') || '', location.origin).pathname;
        const m = /^\/member\/([^/?#]+)/.exec(path);
        return m ? decodeURIComponent(m[1]) : '';
      } catch (_) { return ''; }
    }

    function paintSlot(slot) {
      const user = slot.dataset.user;
      const entry = get(user);
      if (entry) {
        const fragment = document.createDocumentFragment();
        for (const item of entry.tags) {
          const chip = document.createElement('span');
          chip.className = 'v2t-chip';
          chip.textContent = item.tag;
          // 标签在楼层头部可能被省略号截断，完整文案放进 title 兜底
          chip.title = `${item.tag} · ${entry.name || user}\n点击管理该用户的全部标签`;
          chip.setAttribute('role', 'button');
          chip.tabIndex = 0;
          chip.style.cssText = CHIP_CSS.get(item.color) || CHIP_CSS.get(DEFAULT_COLOR);
          fragment.appendChild(chip);
        }
        slot.replaceChildren(fragment);
        return;
      }
      const add = document.createElement('span');
      add.className = 'v2t-add';
      add.textContent = '+';
      add.title = `给 ${user} 添加标签`;
      add.setAttribute('role', 'button');
      add.setAttribute('aria-label', `给 ${user} 添加标签`);
      add.tabIndex = 0;
      slot.replaceChildren(add);
    }

    function attachSlot(anchor) {
      if (anchor.dataset.v2tBound === '1') return;
      const user = userFromLink(anchor);
      if (!user) return;
      anchor.dataset.v2tBound = '1';
      const slot = document.createElement('span');
      slot.className = 'v2t-slot';
      slot.dataset.user = user;
      anchor.insertAdjacentElement('afterend', slot);
      paintSlot(slot);
    }

    function decorate(root = document) {
      if (root.nodeType === Node.ELEMENT_NODE && root.matches?.(AUTHOR_SELECTOR)) attachSlot(root);
      root.querySelectorAll?.(AUTHOR_SELECTOR).forEach(attachSlot);
    }

    function repaintAll() {
      document.querySelectorAll('.v2t-slot').forEach(paintSlot);
    }

    // ── 编辑气泡 ──
    const Editor = (() => {
      let el = null;
      let currentUser = '';
      let anchorEl = null;

      function place() {
        if (!el || !anchorEl?.isConnected) return;
        const rect = anchorEl.getBoundingClientRect();
        const width = el.offsetWidth || 356;
        const height = el.offsetHeight || 220;
        const left = Math.max(8, Math.min(rect.left, window.innerWidth - width - 8));
        const top = (window.innerHeight - rect.bottom > height + 12)
          ? rect.bottom + 8
          : Math.max(8, rect.top - height - 8);
        el.style.left = `${left}px`;
        el.style.top = `${top}px`;
      }

      function close() {
        if (!el) return;
        closeColorPickers();
        el.classList.remove('visible');
        el.style.pointerEvents = 'none';
        currentUser = '';
        anchorEl = null;
        window.removeEventListener('scroll', place, true);
        window.removeEventListener('resize', place);
      }

      function isOpen() { return !!currentUser; }

      function build() {
        el = document.createElement('div');
        el.id = 'v2t-editor';
        document.body.appendChild(el);
        // 气泡内部的点击不能冒泡到"点击外部关闭"的全局监听
        el.addEventListener('mousedown', e => e.stopPropagation());
        return el;
      }

      function open(user, anchor) {
        if (!el) build();
        if (currentUser && keyOf(currentUser) === keyOf(user)) { close(); return; }
        currentUser = user;
        anchorEl = anchor;
        const existing = get(user);

        el.replaceChildren();

        const head = document.createElement('div');
        head.className = 'v2t-ed-head';
        const avatar = anchor.closest('.cell, .hot-card, .header')?.querySelector('img.avatar, img.user-avatar');
        if (avatar?.src) {
          const img = document.createElement('img');
          img.src = avatar.src;
          img.alt = '';
          head.appendChild(img);
        }
        const nameEl = document.createElement('b');
        nameEl.textContent = user;
        head.append(nameEl, document.createTextNode(existing ? `· ${existing.tags.length} 个标签` : '· 新建标签'));

        const tagList = document.createElement('div');
        tagList.className = 'v2t-tag-list';
        const addRowBtn = document.createElement('button');
        addRowBtn.type = 'button';
        addRowBtn.className = 'v2t-add-row';
        addRowBtn.textContent = '＋ 添加一个标签';

        let commit = () => {};
        const syncAddButton = () => {
          const full = tagList.children.length >= maxTagsPerUser;
          addRowBtn.disabled = full;
          addRowBtn.textContent = full ? `最多 ${maxTagsPerUser} 个标签` : '＋ 添加一个标签';
          place();
        };

        function addRow(value = '', color = DEFAULT_COLOR, shouldFocus = false) {
          if (tagList.children.length >= maxTagsPerUser) return null;
          const row = document.createElement('div');
          row.className = 'v2t-tag-row';

          const input = document.createElement('input');
          input.type = 'text';
          input.maxLength = maxTagLength;
          input.placeholder = '标签内容';
          input.value = value;
          input.setAttribute('aria-label', `${user} 的标签`);
          input.addEventListener('keydown', e => {
            if (e.key === 'Enter') { e.preventDefault(); commit(); }
            else if (e.key === 'Escape') { e.preventDefault(); close(); }
          });

          const colorPicker = createColorPicker(color);

          const remove = document.createElement('button');
          remove.type = 'button';
          remove.className = 'v2t-tag-remove';
          remove.textContent = '×';
          remove.title = '移除这一项';
          remove.setAttribute('aria-label', '移除这一项');
          remove.addEventListener('click', () => {
            row.remove();
            syncAddButton();
          });

          row.append(input, colorPicker, remove);
          tagList.appendChild(row);
          syncAddButton();
          if (shouldFocus) input.focus();
          return row;
        }

        for (const item of existing?.tags || [{ tag: '', color: DEFAULT_COLOR }]) {
          addRow(item.tag, item.color);
        }
        addRowBtn.addEventListener('click', () => addRow('', DEFAULT_COLOR, true));
        el.append(head, tagList, addRowBtn);

        const recent = suggestions();
        if (recent.length) {
          const list = document.createElement('div');
          list.className = 'v2t-recent';
          for (const item of recent) {
            const chip = document.createElement('span');
            chip.className = 'v2t-recent-item';
            chip.textContent = item.tag;
            chip.title = `已用于 ${item.count} 人`;
            chip.style.setProperty('--v2t-recent-color', colorItem(item.color).swatch);
            chip.addEventListener('click', () => {
              const duplicate = [...tagList.querySelectorAll('input')]
                .find(input => input.value.trim().toLocaleLowerCase() === item.tag.toLocaleLowerCase());
              if (duplicate) { duplicate.focus(); return; }
              addRow(item.tag, item.color, true);
            });
            list.appendChild(chip);
          }
          el.appendChild(list);
        }

        const actions = document.createElement('div');
        actions.className = 'v2t-ed-actions';
        if (existing) {
          const del = document.createElement('button');
          del.type = 'button';
          del.className = 'v2t-btn danger';
          del.textContent = '删除全部';
          del.addEventListener('click', () => {
            removeTags(user);
            toast(`已删除 ${user} 的全部标签`);
            close();
          });
          actions.appendChild(del);
        }
        const spacer = document.createElement('span');
        spacer.className = 'v2t-spacer';
        const cancel = document.createElement('button');
        cancel.type = 'button';
        cancel.className = 'v2t-btn';
        cancel.textContent = '取消';
        cancel.addEventListener('click', close);
        const save = document.createElement('button');
        save.type = 'button';
        save.className = 'v2t-btn primary';
        save.textContent = '保存';

        commit = () => {
          const values = [];
          const seen = new Set();
          for (const row of tagList.children) {
            const input = row.querySelector('input');
            const value = input.value.replace(/\s+/g, ' ').trim();
            if (!value) continue;
            const key = value.toLocaleLowerCase();
            if (seen.has(key)) {
              toast(`标签“${value}”重复了`);
              input.focus();
              return;
            }
            seen.add(key);
            values.push({ tag: value, color: row.querySelector('.v2t-color-picker').dataset.color });
          }
          if (!values.length) {
            if (existing) { removeTags(user); toast(`已删除 ${user} 的全部标签`); }
            close();
            return;
          }
          setTags(user, values);
          toast(`已保存 ${user} 的 ${values.length} 个标签`);
          close();
        };
        save.addEventListener('click', commit);

        actions.append(spacer, cancel, save);
        el.appendChild(actions);

        el.style.pointerEvents = 'auto';
        place();
        requestAnimationFrame(() => {
          el.classList.add('visible');
          place();
          const firstInput = tagList.querySelector('input');
          firstInput?.focus();
          if (existing) firstInput?.select();
        });
        window.addEventListener('scroll', place, true);
        window.addEventListener('resize', place);
      }

      return { open, close, isOpen };
    })();

    // ── 管理面板 ──
    const Manager = (() => {
      let overlay = null;
      let listEl = null;
      let countEl = null;
      let mergeEl = null;
      let searchEl = null;
      let closeBtn = null;
      let embeddedCleanup = null;
      let pending = null; // 待确认的导入数据
      let strategy = 'smart';

      function isOpen() { return !!overlay?.classList.contains('active'); }

      function editInline(item, row) {
        Editor.close();
        row.replaceChildren();

        const editor = document.createElement('div');
        editor.className = 'v2t-inline-editor';
        const head = document.createElement('div');
        head.className = 'v2t-inline-editor-head';
        const user = document.createElement('b');
        user.textContent = item.name || item.key;
        head.append(user, document.createTextNode('的标签'));

        const tagList = document.createElement('div');
        tagList.className = 'v2t-inline-tag-list';
        const addBtn = document.createElement('button');
        addBtn.type = 'button';
        addBtn.className = 'v2t-inline-add';
        addBtn.textContent = '＋ 添加一个标签';

        const syncAdd = () => {
          addBtn.disabled = tagList.children.length >= maxTagsPerUser;
          addBtn.textContent = addBtn.disabled ? `最多 ${maxTagsPerUser} 个标签` : '＋ 添加一个标签';
        };

        function addRow(value = '', color = DEFAULT_COLOR, focus = false) {
          if (tagList.children.length >= maxTagsPerUser) return;
          const tagRow = document.createElement('div');
          tagRow.className = 'v2t-inline-tag-row';
          const input = document.createElement('input');
          input.type = 'text';
          input.maxLength = maxTagLength;
          input.placeholder = '标签内容';
          input.value = value;
          const colorPicker = createColorPicker(color);
          const remove = document.createElement('button');
          remove.type = 'button';
          remove.className = 'v2t-inline-remove';
          remove.textContent = '×';
          remove.title = '移除这一项';
          remove.addEventListener('click', () => { tagRow.remove(); syncAdd(); });
          tagRow.append(input, colorPicker, remove);
          tagList.appendChild(tagRow);
          syncAdd();
          if (focus) input.focus();
        }

        for (const tag of item.tags) addRow(tag.tag, tag.color);
        addBtn.addEventListener('click', () => addRow('', DEFAULT_COLOR, true));

        const actions = document.createElement('div');
        actions.className = 'v2t-inline-actions';
        const cancel = document.createElement('button');
        cancel.type = 'button';
        cancel.className = 'v2t-btn';
        cancel.textContent = '取消';
        cancel.addEventListener('click', renderList);
        const save = document.createElement('button');
        save.type = 'button';
        save.className = 'v2t-btn primary';
        save.textContent = '保存';
        save.addEventListener('click', () => {
          const tags = [];
          const seen = new Set();
          for (const tagRow of tagList.children) {
            const input = tagRow.querySelector('input');
            const tag = input.value.replace(/\s+/g, ' ').trim();
            if (!tag) continue;
            const key = tag.toLocaleLowerCase();
            if (seen.has(key)) { toast(`标签“${tag}”重复了`); input.focus(); return; }
            seen.add(key);
            tags.push({ tag, color: tagRow.querySelector('.v2t-color-picker').dataset.color });
          }
          setTags(item.name || item.key, tags);
          toast(tags.length ? `已保存 ${tags.length} 个标签` : `已删除 ${item.name || item.key} 的全部标签`);
        });
        actions.append(cancel, save);
        editor.append(head, tagList, addBtn, actions);
        row.appendChild(editor);
        tagList.querySelector('input')?.focus();
      }

      function renderList() {
        if (!listEl) return;
        const keyword = (searchEl?.value || '').trim().toLowerCase();
        const all = entries();
        const rows = keyword
          ? all.filter(item => item.key.includes(keyword)
            || item.name.toLowerCase().includes(keyword)
            || item.tags.some(tag => tag.tag.toLowerCase().includes(keyword)))
          : all;

        const tagTotal = all.reduce((sum, item) => sum + item.tags.length, 0);
        countEl.textContent = keyword ? `${rows.length} / ${all.length} 个用户` : `${all.length} 个用户 · ${tagTotal} 个标签`;
        listEl.replaceChildren();

        if (!rows.length) {
          const empty = document.createElement('div');
          empty.className = 'v2t-empty';
          empty.textContent = all.length ? '没有匹配的标签' : '还没有标签，在主题页把鼠标移到用户名旁点 + 即可添加';
          listEl.appendChild(empty);
          return;
        }

        const fragment = document.createDocumentFragment();
        for (const item of rows) {
          const row = document.createElement('div');
          row.className = 'v2t-row';

          const user = document.createElement('a');
          user.className = 'v2t-user';
          user.href = `/member/${encodeURIComponent(item.name || item.key)}`;
          user.target = '_blank';
          user.rel = 'noreferrer noopener';
          user.textContent = item.name || item.key;

          const slot = document.createElement('span');
          slot.className = 'v2t-slot';
          slot.dataset.user = item.name || item.key;
          paintSlot(slot);
          slot.addEventListener('click', event => {
            if (!event.target.closest('.v2t-chip')) return;
            event.preventDefault();
            event.stopPropagation();
            editInline(item, row);
          });

          const time = document.createElement('span');
          time.className = 'v2t-time';
          time.textContent = item.updatedAt ? new Date(item.updatedAt).toLocaleDateString() : '—';

          const edit = document.createElement('span');
          edit.className = 'v2t-row-act';
          edit.textContent = '编辑';
          edit.setAttribute('role', 'button');
          edit.addEventListener('click', () => editInline(item, row));

          const del = document.createElement('span');
          del.className = 'v2t-row-act danger';
          del.textContent = '删除';
          del.setAttribute('role', 'button');
          del.addEventListener('click', () => { removeTags(item.key); });

          row.append(user, slot, time, edit, del);
          fragment.appendChild(row);
        }
        listEl.appendChild(fragment);
      }

      function renderMerge() {
        if (!mergeEl) return;
        if (!pending) {
          mergeEl.hidden = true;
          mergeEl.replaceChildren();
          return;
        }
        const { stats } = computeMerge(pending, strategy);
        mergeEl.hidden = false;
        mergeEl.replaceChildren();

        const title = document.createElement('div');
        const incomingTagCount = Object.values(pending.tags).reduce((sum, entry) => sum + entry.tags.length, 0);
        title.innerHTML = `准备导入 <b>${Object.keys(pending.tags).length}</b> 个用户、<b>${incomingTagCount}</b> 个标签`
          + (pending.invalid ? `（已忽略 <b>${pending.invalid}</b> 条无效记录）` : '');

        const opts = document.createElement('div');
        opts.className = 'v2t-merge-opts';
        const choices = [
          ['smart', '智能合并（保留较新，推荐）'],
          ['add', '仅新增（不动本地已有）'],
          ['replace', '覆盖本地（清空后导入）'],
        ];
        for (const [value, label] of choices) {
          const wrap = document.createElement('label');
          const radio = document.createElement('input');
          radio.type = 'radio';
          radio.name = 'v2t-merge-strategy';
          radio.value = value;
          radio.checked = strategy === value;
          radio.addEventListener('change', () => { strategy = value; renderMerge(); });
          wrap.append(radio, document.createTextNode(label));
          opts.appendChild(wrap);
        }

        const summary = document.createElement('div');
        summary.innerHTML = `结果：新增 <b>${stats.added}</b> · 更新 <b>${stats.updated}</b> · 删除 <b>${stats.removed}</b> · 不变 <b>${stats.unchanged}</b>`;

        const actions = document.createElement('div');
        actions.className = 'v2t-ed-actions';
        const spacer = document.createElement('span');
        spacer.className = 'v2t-spacer';
        const cancel = document.createElement('button');
        cancel.type = 'button';
        cancel.className = 'v2t-btn';
        cancel.textContent = '取消';
        cancel.addEventListener('click', () => { pending = null; renderMerge(); });
        const apply = document.createElement('button');
        apply.type = 'button';
        apply.className = 'v2t-btn primary';
        apply.textContent = '应用';
        apply.addEventListener('click', () => {
          const { stats: applied, next } = computeMerge(pending, strategy);
          pending = null;
          persist(next);
          toast(`导入完成：新增 ${applied.added} · 更新 ${applied.updated} · 删除 ${applied.removed}`);
        });
        actions.append(spacer, cancel, apply);

        mergeEl.append(title, opts, summary, actions);
      }

      function pickFile() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'application/json,.json';
        input.style.display = 'none';
        document.body.appendChild(input);
        input.addEventListener('change', async () => {
          const file = input.files?.[0];
          input.remove();
          if (!file) return;
          try {
            pending = parseImport(await file.text());
            strategy = 'smart';
            renderMerge();
          } catch (err) {
            pending = null;
            renderMerge();
            toast(`导入失败：${err.message}`);
          }
        }, { once: true });
        input.click();
      }

      function build() {
        overlay = document.createElement('div');
        overlay.id = 'v2t-manager';

        const panel = document.createElement('div');
        panel.className = 'v2t-panel';

        const head = document.createElement('div');
        head.className = 'v2t-panel-head';
        const title = document.createElement('span');
        title.className = 'v2t-title';
        title.textContent = '用户标签';
        countEl = document.createElement('span');
        countEl.className = 'v2t-count';
        searchEl = document.createElement('input');
        searchEl.type = 'text';
        searchEl.className = 'v2t-search';
        searchEl.placeholder = '搜索用户或标签…';
        searchEl.addEventListener('input', debounce(renderList, 120));
        head.append(title, countEl, searchEl);

        listEl = document.createElement('div');
        listEl.className = 'v2t-list';

        mergeEl = document.createElement('div');
        mergeEl.className = 'v2t-merge';
        mergeEl.hidden = true;

        const foot = document.createElement('div');
        foot.className = 'v2t-panel-foot';
        const exportBtn = document.createElement('button');
        exportBtn.type = 'button';
        exportBtn.className = 'v2t-btn';
        exportBtn.textContent = '导出';
        exportBtn.addEventListener('click', exportTags);
        const importBtn = document.createElement('button');
        importBtn.type = 'button';
        importBtn.className = 'v2t-btn';
        importBtn.textContent = '导入';
        importBtn.addEventListener('click', pickFile);
        const clearBtn = document.createElement('button');
        clearBtn.type = 'button';
        clearBtn.className = 'v2t-btn danger';
        clearBtn.textContent = '清空';
        clearBtn.addEventListener('click', () => {
          const current = load();
          const total = Object.keys(current.tags).length;
          if (!total) { toast('没有可清空的标签'); return; }
          const tagTotal = Object.values(current.tags).reduce((sum, entry) => sum + entry.tags.length, 0);
          if (!window.confirm(`确定删除 ${total} 个用户的全部 ${tagTotal} 个标签？此操作不可撤销。`)) return;
          const next = { v: exportVersion, tags: {}, deleted: { ...current.deleted } };
          const now = Date.now();
          for (const key of Object.keys(current.tags)) next.deleted[key] = now;
          persist(next);
          toast('已清空全部标签');
        });
        const spacer = document.createElement('span');
        spacer.className = 'v2t-spacer';
        closeBtn = document.createElement('button');
        closeBtn.type = 'button';
        closeBtn.className = 'v2t-btn';
        closeBtn.textContent = '关闭';
        closeBtn.addEventListener('click', close);
        foot.append(exportBtn, importBtn, clearBtn, spacer, closeBtn);

        panel.append(head, listEl, mergeEl, foot);
        overlay.appendChild(panel);
        document.body.appendChild(overlay);
        overlay.addEventListener('click', e => {
          if (!overlay.classList.contains('embedded') && e.target === overlay) close();
        });
      }

      function onKey(e) {
        if (e.key === 'Escape' && isOpen() && !Editor.isOpen()) close();
      }

      function open(options = {}) {
        if (!overlay) build();
        if (embeddedCleanup) {
          embeddedCleanup();
          embeddedCleanup = null;
        }
        if (options.host) {
          overlay.classList.add('embedded');
          options.host.insertBefore(overlay, options.before || null);
          embeddedCleanup = options.onClose || null;
          closeBtn.textContent = '返回设置';
        } else {
          overlay.classList.remove('embedded');
          document.body.appendChild(overlay);
          closeBtn.textContent = '关闭';
        }
        pending = null;
        searchEl.value = '';
        renderMerge();
        renderList();
        overlay.classList.add('active');
        document.addEventListener('keydown', onKey);
        searchEl.focus();
      }

      function importTags() {
        open();
        pickFile();
      }

      function close() {
        if (!overlay) return;
        Editor.close();
        const wasEmbedded = overlay.classList.contains('embedded');
        overlay.classList.remove('active', 'embedded');
        if (wasEmbedded) document.body.appendChild(overlay);
        document.removeEventListener('keydown', onKey);
        if (embeddedCleanup) {
          const cleanup = embeddedCleanup;
          embeddedCleanup = null;
          cleanup();
        }
      }

      function refresh() {
        if (isOpen()) { renderList(); renderMerge(); }
      }

      return { open, close, refresh, isOpen, importTags };
    })();

    // ── 装载 ──
    function mountSettingsEntry() {
      if (!/^\/settings(?:\/|$)/.test(location.pathname)) return;
      const nav = [...document.querySelectorAll('#Main .box > .cell')]
        .find(cell => cell.querySelector(':scope > a[href="/settings/privacy"]'));
      if (!nav || nav.querySelector('#v2t-settings-entry')) return;
      const box = nav.parentElement;
      const nativeCurrent = nav.querySelector(':scope > .tab_current');
      const navIndex = [...box.children].indexOf(nav);
      const nativeSections = [...box.children].slice(navIndex + 1);
      if (!nativeSections.length) return;

      const entry = document.createElement('a');
      entry.id = 'v2t-settings-entry';
      entry.className = 'tab';
      entry.href = '#v2t-user-tags';
      entry.textContent = '用户标签';
      entry.title = '管理、导入或导出用户标签';
      entry.addEventListener('click', event => {
        event.preventDefault();
        if (entry.classList.contains('tab_current')) return;
        const previousHidden = nativeSections.map(section => section.hidden);
        nativeSections.forEach(section => { section.hidden = true; });
        if (nativeCurrent) nativeCurrent.className = 'tab';
        entry.className = 'tab_current';
        Manager.open({
          host: box,
          before: nativeSections[0],
          onClose: () => {
            nativeSections.forEach((section, index) => { section.hidden = previousHidden[index]; });
            entry.className = 'tab';
            if (nativeCurrent) nativeCurrent.className = 'tab_current';
          },
        });
      });
      nav.appendChild(entry);
    }

    function boot() {
      decorate(document);
      mountSettingsEntry();
      ScriptMenu.add('导入用户标签…', () => Manager.importTags());
      ScriptMenu.add('导出用户标签', exportTags);
      document.addEventListener('click', event => {
        if (!event.target.closest?.('.v2t-color-picker, .v2t-color-orbit')) closeColorPickers();
      });

      // 统一委托：胶囊 / + 按钮 / 点击空白关闭气泡
      document.addEventListener('click', e => {
        const trigger = e.target.closest?.('.v2t-chip, .v2t-add');
        if (!trigger) return;
        const slot = trigger.closest('.v2t-slot');
        if (!slot?.dataset.user) return;
        e.preventDefault();
        e.stopPropagation();
        Editor.open(slot.dataset.user, trigger);
      });
      document.addEventListener('keydown', e => {
        if (e.key !== 'Enter' && e.key !== ' ') return;
        const trigger = e.target.closest?.('.v2t-chip, .v2t-add');
        if (!trigger) return;
        e.preventDefault();
        trigger.click();
      });
      document.addEventListener('mousedown', e => {
        if (Editor.isOpen() && !e.target.closest?.('.v2t-chip, .v2t-add, #v2t-editor, .v2t-color-orbit')) Editor.close();
      });

      const enqueueDecorate = createSubtreeBatch(decorate);
      const root = document.getElementById('Main') || document.body;
      new MutationObserver(records => {
        for (const record of records) {
          for (const node of record.addedNodes) {
            // 自己插入的槽位和槽位里的胶囊都不必回扫，
            // 否则每装饰/重绘一个用户名就要多排一轮 decorate
            if (node.nodeType !== Node.ELEMENT_NODE) continue;
            if (node.classList.contains('v2t-slot')) continue;
            if (node.parentElement?.classList.contains('v2t-slot')) continue;
            enqueueDecorate(node);
          }
        }
      }).observe(root, { childList: true, subtree: true });

      // 其它标签页改动标签后同步刷新
      GM.onChange(storeKey, next => {
        store = next === undefined ? null : normalizeStore(next);
        repaintAll();
        Manager.refresh();
      });

    }

    return {
      boot,
      decorate,
      bulkAdd,
      createColorPicker,
      toast,
    };
  })();

  // =========================
  // 10) 可选在新标签页打开帖子和用户主页
  // =========================
  const NewTabLinks = (() => {
    const V2EX_HOSTS = new Set(['v2ex.com', 'www.v2ex.com', 'edge.v2ex.com']);
    const TOPIC_PATH = /^\/t\/\d+(?:\/|$)/;
    const MEMBER_PATH = /^\/member\/[^/]+\/?$/;
    const { storeKey, openTopicsAndMembersInNewTab } = CONFIG.links;
    let enabled = openTopicsAndMembersInNewTab;

    function isEnabled() { return enabled; }
    const refreshMenu = createToggleMenu('帖子和用户主页新标签页', isEnabled, () => setEnabled(!enabled));

    function setEnabled(value) {
      const next = Boolean(value);
      if (!GM.set(storeKey, next)) return false;
      enabled = next;
      refreshMenu();
      return true;
    }

    function isEligible(anchor) {
      if (!anchor || anchor.hasAttribute('download') || (anchor.target && anchor.target !== '_self')) return false;
      const href = anchor.getAttribute('href');
      if (!href || href.startsWith('#')) return false;
      let url;
      try { url = new URL(href, location.href); } catch (_) { return false; }
      if (!V2EX_HOSTS.has(url.hostname) || !['http:', 'https:'].includes(url.protocol)) return false;
      if (!TOPIC_PATH.test(url.pathname) && !MEMBER_PATH.test(url.pathname)) return false;
      // 楼层定位、当前主题翻页等仍在当前标签页完成（含切换 V2EX 域名的同一主题链接）。
      const linkedTopic = url.pathname.match(/^\/t\/(\d+)/)?.[1];
      const currentTopic = location.pathname.match(/^\/t\/(\d+)/)?.[1];
      if (linkedTopic && linkedTopic === currentTopic) return false;
      if (url.origin === location.origin && url.pathname === location.pathname && url.search === location.search) return false;
      return true;
    }

    function boot() {
      enabled = GM.get(storeKey, openTopicsAndMembersInNewTab) !== false;
      GM.onChange(storeKey, next => {
        enabled = (next === undefined ? GM.get(storeKey, openTopicsAndMembersInNewTab) : next) !== false;
        refreshMenu();
      });
      refreshMenu();
      // 在默认导航发生前设置 target，保留浏览器原生的新标签页和容器行为。
      // 委托监听也覆盖树形回复和无限加载后才出现的链接。
      document.addEventListener('click', event => {
        if (!enabled || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
        const anchor = event.target.closest?.('a[href]');
        if (!isEligible(anchor)) return;
        const originalTarget = anchor.getAttribute('target');
        const originalRel = anchor.getAttribute('rel');
        const hadNoopener = anchor.relList.contains('noopener');
        anchor.target = '_blank';
        anchor.relList.add('noopener');
        // 默认导航已开始后还原属性，否则关闭开关后点过的链接仍会留在新标签页。
        setTimeout(() => {
          if (anchor.getAttribute('target') === '_blank') {
            if (originalTarget === null) anchor.removeAttribute('target');
            else anchor.setAttribute('target', originalTarget);
          }
          if (!hadNoopener) anchor.relList.remove('noopener');
          if (originalRel === null && !anchor.getAttribute('rel')) anchor.removeAttribute('rel');
        }, 0);
      }, true);
    }

    return { boot, isEnabled, setEnabled };
  })();

  // =========================
  // 11) 启动
  // =========================
  Daily.boot();
  NewTabLinks.boot();
  ImgurProxy.boot();
  UserTags.boot();
  if (isTopicPage()) {
    ThreadTree.boot();
    B64.boot();
    HotRoom.boot();
    NavKeys.boot();
  }
})();

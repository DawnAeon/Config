// ==UserScript==
// @name         AI Chat WideScreen
// @namespace    http://tampermonkey.net/
// @version      2.7
// @description  Make the ChatGPT conversation window wider.使ChatGPT的聊天对话框更宽
// @author       Xiong Yu
// @match        https://chat.openai.com/*
// @match        https://chatgpt.com/*
// @grant        none
// @homepageURL  https://greasyfork.org/zh-CN/scripts/473238
// @downloadURL https://update.greasyfork.org/scripts/473238/AI%20Chat%20WideScreen.user.js
// @updateURL https://update.greasyfork.org/scripts/473238/AI%20Chat%20WideScreen.meta.js
// ==/UserScript==

(function() {
    'use strict';

    function updateStyle(element) {
        element.style.setProperty('max-width', '95%', 'important');
    }

    const nodes = [
        '[class*="transcriptContent-"]'
    ];

    const observer = new MutationObserver(mutationsList => {
        mutationsList.forEach(mutation => {
            if (mutation.addedNodes.length > 0) {
                mutation.addedNodes.forEach(addedNode => {
                    if (addedNode.nodeType === Node.ELEMENT_NODE) {
                        if (nodes.some(selector => addedNode.matches(selector))) {
                            updateStyle(addedNode);
                        } else {
                            nodes.forEach(selector => {
                                addedNode.querySelectorAll(selector).forEach(updateStyle);
                            });
                        }
                    }
                });
            }
        });
    });

    observer.observe(document, { childList: true, subtree: true });
})();
// ==UserScript==
// @name         Auto TOC Generator
// @version      1.3.0
// @description  Automatically generate an interactive hierarchical Table of Contents (TOC) for any webpage, supporting drag, collapse, highlight, etc.
// @author       You
// @match        *://*/*
// @grant        none
// @run-at       document-idle
// @license      MIT
// ==/UserScript==

(function () {
  'use strict';

  // ============================================================
  // Configuration (modify as needed)
  // ============================================================
  const CONFIG = {
    // Exclude selectors list (matched headings won't appear in TOC)
    excludeSelectors: [
      'nav h1', 'nav h2', 'nav h3', 'nav h4', 'nav h5', 'nav h6',
      'header h1', 'header h2', 'header h3',
      'footer h1', 'footer h2', 'footer h3',
      '.sidebar h1', '.sidebar h2', '.sidebar h3',
      '[role="navigation"] h1', '[role="navigation"] h2',
      '.toc-exclude h1', '.toc-exclude h2', '.toc-exclude h3',
    ],
    // Panel default position
    defaultPosition: { top: 80, right: 20 },
    // Panel default width
    panelWidth: 280,
    // Panel max height
    panelMaxHeight: 500,
    // Debounce delay (ms)
    debounceDelay: 300,
    // localStorage key
    storageKey: 'auto-toc-state',
    // Whether to show level numbers
    showNumbers: true,
    // Panel background opacity (0 - 1)
    panelOpacity: 0.92,
  };

  // ============================================================
  // State management
  // ============================================================
  let state = {
    collapsed: false,
    position: { ...CONFIG.defaultPosition },
  };

  function loadState() {
    try {
      const saved = localStorage.getItem(CONFIG.storageKey);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') {
          state = { ...state, ...parsed };
        }
      }
    } catch (e) {
      // ignore
    }
  }

  function saveState() {
    try {
      localStorage.setItem(CONFIG.storageKey, JSON.stringify({
        collapsed: state.collapsed,
        position: state.position,
      }));
    } catch (e) {
      // ignore
    }
  }

  // ============================================================
  // Utility functions
  // ============================================================

  function debounce(fn, delay) {
    let timer = null;
    return function (...args) {
      clearTimeout(timer);
      timer = setTimeout(() => fn.apply(this, args), delay);
    };
  }

  /** Check if element is visible */
  function isVisible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    if (style.display === 'none') return false;
    if (style.visibility === 'hidden') return false;
    if (parseFloat(style.opacity) < 0.01) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return false;
    return true;
  }

  /** Check if heading should be excluded */
  function isExcluded(heading) {
    for (const selector of CONFIG.excludeSelectors) {
      try {
        const parts = selector.trim().split(/\s+/).filter(Boolean);
        if (parts.length === 0) continue;

        const tagPart = parts[parts.length - 1].toLowerCase();
        const parentSelector = parts.slice(0, -1).join(' ');

        // Check if the heading itself matches the selector (when no parent specified)
        if (!parentSelector && heading.matches(selector)) {
          return true;
        }

        // Check if heading is inside the specified parent and tag matches
        if (parentSelector &&
            heading.tagName.toLowerCase() === tagPart &&
            heading.closest(parentSelector)) {
          return true;
        }
      } catch (e) {
        // Skip invalid selector
      }
    }
    return false;
  }

  /** Generate unique ID for heading */
  function ensureId(el) {
    if (!el.id) {
      el.id = 'auto-toc-' + Math.random().toString(36).substr(2, 9);
    }
    return el.id;
  }

  // ============================================================
  // Collect headings
  // ============================================================
  function collectHeadings() {
    const allHeadings = document.querySelectorAll('h1, h2, h3, h4, h5, h6');
    const result = [];

    allHeadings.forEach((h) => {
      if (!isVisible(h)) return;
      if (!h.textContent.trim()) return;
      if (isExcluded(h)) return;
      if (h.getRootNode() !== document) return; // skip headings inside Shadow DOM

      result.push({
        element: h,
        level: parseInt(h.tagName.charAt(1), 10),
        text: h.textContent.trim().substring(0, 80),
        id: ensureId(h),
      });
    });

    return result;
  }

  // ============================================================
  // Generate level numbers
  // ============================================================
  function generateNumbers(headings) {
    const counters = [0, 0, 0, 0, 0, 0];
    let minLevel = 6;

    headings.forEach((h) => {
      if (h.level < minLevel) minLevel = h.level;
    });

    return headings.map((h) => {
      const idx = h.level - 1;
      counters[idx]++;
      for (let i = idx + 1; i < 6; i++) {
        counters[i] = 0;
      }
      const parts = [];
      for (let i = minLevel - 1; i <= idx; i++) {
        parts.push(counters[i]);
      }
      return parts.join('.');
    });
  }

  // ============================================================
  // Create Shadow DOM container
  // ============================================================
  let hostEl = null;
  let shadowRoot = null;
  let panelEl = null;
  let listEl = null;

  function createUI() {
    hostEl = document.createElement('div');
    hostEl.id = 'auto-toc-host';
    hostEl.style.cssText = 'all: initial; position: fixed; z-index: 2147483647;';
    document.documentElement.appendChild(hostEl);

    shadowRoot = hostEl.attachShadow({ mode: 'closed' });

    const style = document.createElement('style');
    style.textContent = `
      :host {
        all: initial;
      }
      * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
      }

      .toc-panel {
        position: fixed;
        width: ${CONFIG.panelWidth}px;
        max-height: ${CONFIG.panelMaxHeight}px;
        background: rgba(255, 255, 255, ${CONFIG.panelOpacity});
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
        border: 1px solid rgba(0, 0, 0, 0.08);
        border-radius: 10px;
        box-shadow: 0 4px 24px rgba(0, 0, 0, 0.12);
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        font-size: 13px;
        color: #333;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        transition: opacity 0.2s, transform 0.2s;
        z-index: 2147483647;
      }
      .toc-panel.collapsed .toc-body {
        display: none;
      }

      .toc-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px 14px;
        border-bottom: 1px solid rgba(0,0,0,0.06);
        cursor: move;
        user-select: none;
        background: rgba(245, 247, 250, 0.9);
        flex-shrink: 0;
      }
      .toc-header-title {
        font-weight: 600;
        font-size: 13px;
        color: #444;
      }
      .toc-header-actions {
        display: flex;
        gap: 6px;
        align-items: center;
      }
      .toc-btn {
        width: 24px;
        height: 24px;
        border: none;
        background: transparent;
        border-radius: 4px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 14px;
        color: #666;
        transition: background 0.15s;
      }
      .toc-btn:hover {
        background: rgba(0,0,0,0.08);
      }

      .toc-body {
        overflow-y: auto;
        overflow-x: hidden;
        padding: 8px 0;
        flex: 1;
      }
      .toc-body::-webkit-scrollbar {
        width: 5px;
      }
      .toc-body::-webkit-scrollbar-thumb {
        background: rgba(0,0,0,0.15);
        border-radius: 3px;
      }

      .toc-item {
        display: block;
        padding: 5px 14px;
        text-decoration: none;
        color: #555;
        cursor: pointer;
        transition: background 0.15s, color 0.15s;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        border-left: 3px solid transparent;
        line-height: 1.5;
      }
      .toc-item:hover {
        background: rgba(74, 144, 217, 0.08);
        color: #4a90d9;
      }
      .toc-item.active {
        background: rgba(74, 144, 217, 0.12);
        color: #4a90d9;
        border-left-color: #4a90d9;
        font-weight: 500;
      }
      .toc-item .toc-number {
        color: #999;
        margin-right: 6px;
        font-size: 11px;
        font-weight: 400;
      }
      .toc-item.active .toc-number {
        color: #4a90d9;
      }

      .toc-item[data-level="1"] { padding-left: 14px; }
      .toc-item[data-level="2"] { padding-left: 26px; }
      .toc-item[data-level="3"] { padding-left: 38px; }
      .toc-item[data-level="4"] { padding-left: 50px; }
      .toc-item[data-level="5"] { padding-left: 62px; }
      .toc-item[data-level="6"] { padding-left: 74px; }

      .toc-empty {
        padding: 20px 14px;
        text-align: center;
        color: #999;
        font-size: 12px;
      }

      @media (prefers-color-scheme: dark) {
        .toc-panel {
          background: rgba(30, 30, 30, ${CONFIG.panelOpacity});
          border-color: rgba(255,255,255,0.1);
          color: #ddd;
        }
        .toc-header {
          background: rgba(40, 40, 40, 0.9);
          border-bottom-color: rgba(255,255,255,0.08);
        }
        .toc-header-title { color: #ccc; }
        .toc-item { color: #bbb; }
        .toc-item:hover { background: rgba(74,144,217,0.15); color: #6db3f2; }
        .toc-item.active { background: rgba(74,144,217,0.2); color: #6db3f2; border-left-color: #6db3f2; }
        .toc-btn { color: #aaa; }
        .toc-btn:hover { background: rgba(255,255,255,0.1); }
      }
    `;
    shadowRoot.appendChild(style);

    panelEl = document.createElement('div');
    panelEl.className = 'toc-panel';
    panelEl.innerHTML = `
      <div class="toc-header">
        <span class="toc-header-title">📑 TOC</span>
        <div class="toc-header-actions">
          <button class="toc-btn toc-collapse-btn" title="Collapse/Expand">−</button>
        </div>
      </div>
      <div class="toc-body"></div>
    `;
    shadowRoot.appendChild(panelEl);

    listEl = panelEl.querySelector('.toc-body');
    bindEvents();
    applyState();
  }

  // ============================================================
  // Apply state to UI
  // ============================================================
  function applyState() {
    if (!panelEl) return;

    const pos = state.position || CONFIG.defaultPosition;
    panelEl.style.top = (pos.top ?? 80) + 'px';

    if (pos.right !== undefined && pos.right !== null) {
      panelEl.style.right = pos.right + 'px';
      panelEl.style.left = 'auto';
    } else {
      panelEl.style.left = (pos.left ?? 20) + 'px';
      panelEl.style.right = 'auto';
    }

    const btn = panelEl.querySelector('.toc-collapse-btn');
    if (btn) {
      panelEl.classList.toggle('collapsed', state.collapsed);
      btn.textContent = state.collapsed ? '+' : '−';
    }
  }

  // ============================================================
  // Render TOC
  // ============================================================
  function renderTOC() {
    if (!listEl) return;

    const headings = collectHeadings();
    if (headings.length === 0) {
      listEl.innerHTML = '<div class="toc-empty">No headings detected</div>';
      return;
    }

    const numbers = CONFIG.showNumbers ? generateNumbers(headings) : null;
    const minLevel = Math.min(...headings.map(h => h.level));
    const fragment = document.createDocumentFragment();

    headings.forEach((h, i) => {
      const item = document.createElement('a');
      item.className = 'toc-item';
      item.setAttribute('data-level', h.level - minLevel + 1);
      item.setAttribute('data-target-id', h.id);
      item.title = h.text;

      let html = '';
      if (numbers) {
        html += `<span class="toc-number">${numbers[i]}</span>`;
      }
      html += escapeHtml(h.text);
      item.innerHTML = html;

      item.addEventListener('click', (e) => {
        e.preventDefault();
        const target = document.getElementById(h.id);
        if (target) {
          target.scrollIntoView({ behavior: 'smooth', block: 'start' });
          try {
            history.replaceState(null, '', '#' + h.id);
          } catch (err) { /* ignore */ }
        }
      });

      fragment.appendChild(item);
    });

    listEl.innerHTML = '';
    listEl.appendChild(fragment);
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  // ============================================================
  // Scroll highlight
  // ============================================================
  let activeItemId = null;
  let ticking = false;

  function onScroll() {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(() => {
      updateActiveItem();
      ticking = false;
    });
  }

  function updateActiveItem() {
    if (!listEl) return;
    const items = listEl.querySelectorAll('.toc-item');
    if (items.length === 0) return;

    const viewportHeight = window.innerHeight;
    let currentId = null;

    for (let i = items.length - 1; i >= 0; i--) {
      const targetId = items[i].getAttribute('data-target-id');
      const target = document.getElementById(targetId);
      if (!target) continue;

      const rect = target.getBoundingClientRect();
      if (rect.top <= viewportHeight * 0.3) {
        currentId = targetId;
        break;
      }
    }

    if (!currentId && items.length > 0) {
      currentId = items[0].getAttribute('data-target-id');
    }

    if (currentId !== activeItemId) {
      activeItemId = currentId;
      items.forEach((item) => {
        const id = item.getAttribute('data-target-id');
        if (id === currentId) {
          item.classList.add('active');
          // Ensure active item is visible without smooth animation
          item.scrollIntoView({ block: 'nearest' });
        } else {
          item.classList.remove('active');
        }
      });
    }
  }

  // ============================================================
  // Drag functionality (Pointer Events)
  // ============================================================
  function initDrag() {
    const header = panelEl.querySelector('.toc-header');
    if (!header) return;

    let isDragging = false;
    let startX, startY, startLeft, startTop;

    header.addEventListener('pointerdown', (e) => {
      // Ignore clicks on buttons
      if (e.target.closest('.toc-btn')) return;

      isDragging = true;
      const rect = panelEl.getBoundingClientRect();
      startX = e.clientX;
      startY = e.clientY;
      startLeft = rect.left;
      startTop = rect.top;

      header.setPointerCapture(e.pointerId);
      e.preventDefault();
    });

    header.addEventListener('pointermove', (e) => {
      if (!isDragging) return;

      const dx = e.clientX - startX;
      const dy = e.clientY - startY;

      panelEl.style.left = (startLeft + dx) + 'px';
      panelEl.style.top = (startTop + dy) + 'px';
      panelEl.style.right = 'auto';
    });

    header.addEventListener('pointerup', (e) => {
      if (!isDragging) return;
      isDragging = false;

      header.releasePointerCapture(e.pointerId);

      const rect = panelEl.getBoundingClientRect();
      if (rect.left + rect.width / 2 > window.innerWidth / 2) {
        state.position = { top: rect.top, right: window.innerWidth - rect.right };
      } else {
        state.position = { top: rect.top, left: rect.left };
      }
      saveState();
    });

    header.addEventListener('pointercancel', () => {
      isDragging = false;
    });
  }

  // ============================================================
  // Event binding
  // ============================================================
  function bindEvents() {
    // Collapse/Expand button
    panelEl.querySelector('.toc-collapse-btn').addEventListener('click', () => {
      state.collapsed = !state.collapsed;
      applyState();
      saveState();
    });

    window.addEventListener('scroll', onScroll, { passive: true });
    initDrag();
  }

  // ============================================================
  // MutationObserver to watch page changes
  // ============================================================
  function initObserver() {
    const debouncedRender = debounce(() => {
      renderTOC();
      updateActiveItem();
    }, CONFIG.debounceDelay);

    const observer = new MutationObserver((mutations) => {
      let shouldUpdate = false;
      for (const mutation of mutations) {
        if (mutation.type === 'childList') {
          for (const node of mutation.addedNodes) {
            if (node.nodeType === 1) {
              if (/^H[1-6]$/.test(node.tagName) || node.querySelector?.('h1,h2,h3,h4,h5,h6')) {
                shouldUpdate = true;
                break;
              }
            }
          }
          if (!shouldUpdate) {
            for (const node of mutation.removedNodes) {
              if (node.nodeType === 1) {
                if (/^H[1-6]$/.test(node.tagName) || node.querySelector?.('h1,h2,h3,h4,h5,h6')) {
                  shouldUpdate = true;
                  break;
                }
              }
            }
          }
        } else if (mutation.type === 'characterData') {
          // Text inside headings may have changed
          const parent = mutation.target.parentElement;
          if (parent && /^H[1-6]$/.test(parent.tagName)) {
            shouldUpdate = true;
          }
        }
        if (shouldUpdate) break;
      }

      if (shouldUpdate) {
        debouncedRender();
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true,
    });

    // Fallback periodic check (lightweight)
    let lastCount = 0;
    setInterval(() => {
      const count = document.querySelectorAll('h1,h2,h3,h4,h5,h6').length;
      if (count !== lastCount) {
        lastCount = count;
        debouncedRender();
      }
    }, 3000);
  }

  // ============================================================
  // Initialization
  // ============================================================
  function init() {
    if (!document.body) {
      const waitBody = setInterval(() => {
        if (document.body) {
          clearInterval(waitBody);
          init();
        }
      }, 100);
      return;
    }

    loadState();
    createUI();
    renderTOC();
    initObserver();

    // Initial highlight after layout stabilizes
    setTimeout(updateActiveItem, 500);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
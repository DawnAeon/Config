// ==UserScript==
// @name         ChatGPT + Gemini + Claude + Jules Width
// @namespace    https://github.com/sahaj33-op
// @version      2.1.0
// @description  Adjustable chat and composer widths for ChatGPT, Gemini, Claude, and Jules. DOM-targeted CSS, independent chat/composer widths, per-site settings, and a userscript menu.
// @author       Sahaj33
// @license      MIT
// @homepageURL  https://github.com/sizwinz
// @supportURL   https://github.com/sizwinz
// @match        https://chatgpt.com/*
// @match        https://chat.openai.com/*
// @match        https://gemini.google.com/*
// @match        https://claude.ai/*
// @match        https://jules.google.com/*
// @run-at       document-start
// @noframes
// @grant        GM.getValue
// @grant        GM.setValue
// @grant        GM.registerMenuCommand
// @downloadURL https://update.greasyfork.org/scripts/579468/ChatGPT%20%2B%20Gemini%20%2B%20Claude%20%2B%20Jules%20Width.user.js
// @updateURL https://update.greasyfork.org/scripts/579468/ChatGPT%20%2B%20Gemini%20%2B%20Claude%20%2B%20Jules%20Width.meta.js
// ==/UserScript==

(() => {
    'use strict';

    const SITE_BY_HOST = Object.freeze({
        'chatgpt.com': 'chatgpt',
        'chat.openai.com': 'chatgpt',
        'gemini.google.com': 'gemini',
        'claude.ai': 'claude',
        'jules.google.com': 'jules',
    });

    const site = SITE_BY_HOST[location.hostname];
    if (!site) return;

    const STYLE_ID = 'ai-chat-width-enhanced-style';
    const STORAGE_KEY = `ai-chat-width:v2:${site}`;
    const MIN_WIDTH = 800;
    const MAX_WIDTH = 3600;
    const DESKTOP_BREAKPOINT = 900;

    const DEFAULTS = Object.freeze({
        enabled: true,
        chatWidth: 1800,
        composerWidth: 1800,
        widenComposer: true,
    });

    const root = document.documentElement;
    let settings = { ...DEFAULTS };
    let styleElement;

    // Use values from the script manager rather than a page's localStorage.
    // Keep the settings scoped to each supported website.
    async function loadSettings() {
        try {
            const saved = await GM.getValue(STORAGE_KEY, null);
            if (!saved || typeof saved !== 'object' || Array.isArray(saved)) return;

            settings = {
                enabled: typeof saved.enabled === 'boolean' ? saved.enabled : DEFAULTS.enabled,
                chatWidth: validWidth(saved.chatWidth) ?? DEFAULTS.chatWidth,
                composerWidth: validWidth(saved.composerWidth) ?? DEFAULTS.composerWidth,
                widenComposer: typeof saved.widenComposer === 'boolean'
                    ? saved.widenComposer
                    : DEFAULTS.widenComposer,
            };
        } catch (error) {
            console.warn('[AI Chat Width] Could not load settings:', error);
        }
    }

    function validWidth(value) {
        return Number.isInteger(value) && value >= MIN_WIDTH && value <= MAX_WIDTH
            ? value
            : null;
    }

    async function saveSettings() {
        try {
            await GM.setValue(STORAGE_KEY, settings);
        } catch (error) {
            console.warn('[AI Chat Width] Could not save settings:', error);
        }
    }

    async function updateSettings(patch) {
        settings = { ...settings, ...patch };
        applySettings();
        await saveSettings();
    }

    function buildCss() {
        const active = `html[data-aiw-site="${site}"][data-aiw-enabled="true"]`;
        const composer = `${active}[data-aiw-composer="true"]`;

        // Every primary selector is grounded in the October 2026 DOM captures.
        // Keep native sidebar, artifact/code-panel, dialog, and bubble sizing.
        // CSS automatically follows new SPA elements without DOM observation.
        const siteRules = {
            chatgpt: `
                /* Modern thread layout: the content width is declared locally
                   on the transcript, so setting a variable on :root is not enough. */
                ${active} main .thread-scroll-container
                    [class*="transcriptContent-"][class*="[--thread-content-max-width:"] {
                    --thread-content-max-width: var(--aiw-chat-max) !important;
                }
                /* Alternative stable landmark if the transcript class hash changes. */
                ${active} main .thread-scroll-container
                    > [class*="[container-name:thread-content]"]
                    > [class*="[--thread-body-max-width:"] {
                    --thread-content-max-width: var(--aiw-chat-max) !important;
                }
                /* Composer has its own width-bearing footer, separate from chat. */
                ${composer} main [data-thread-scroll-footer]
                    > [class*="[--thread-body-max-width:"] {
                    --thread-content-max-width: var(--aiw-composer-max) !important;
                }
                /* Fallback for older ChatGPT composer/thread DOM variants. */
                ${active} main [data-message-author-role] {
                    max-width: var(--aiw-chat-max) !important;
                }
                ${composer} main form:has([data-composer-surface]) {
                    width: 100% !important;
                    max-width: var(--aiw-composer-max) !important;
                    margin-inline: auto !important;
                }
            `,
            gemini: `
                /* Stay inside the actual chat history, not the sidebar or
                   Gemini's image/canvas/other non-chat surfaces. */
                ${active} chat-window-content #chat-history
                    infinite-scroller.chat-history {
                    width: 100% !important;
                    max-width: none !important;
                    box-sizing: border-box !important;
                }
                ${active} chat-window-content #chat-history
                    .conversation-container {
                    width: 100% !important;
                    max-width: min(100%, var(--aiw-chat-max)) !important;
                    margin-inline: auto !important;
                    box-sizing: border-box !important;
                }
                ${active} chat-window-content #chat-history .conversation-container
                    :is(.response-container, .response-container-content,
                        .model-response-text, .query-content) {
                    max-width: 100% !important;
                    box-sizing: border-box !important;
                }
                /* Width belongs to the input-area wrapper, not the textarea. */
                ${composer} chat-window input-container > .input-area-container {
                    width: min(100%, var(--aiw-composer-max)) !important;
                    max-width: var(--aiw-composer-max) !important;
                    margin-inline: auto !important;
                    box-sizing: border-box !important;
                }
                ${composer} chat-window input-container
                    :is(input-area-v2, .input-area, fieldset.input-area-fieldset) {
                    width: 100% !important;
                    max-width: 100% !important;
                    box-sizing: border-box !important;
                }
            `,
            claude: `
                /* The captured Claude DOM uses transcript-width and the
                   stable chat-column / transcript-list test IDs. */
                ${active} [data-testid="chat-column"] {
                    width: 100% !important;
                    max-width: calc(max(var(--aiw-chat-max),
                        var(--aiw-claude-composer-cap)) + 2.5rem) !important;
                    box-sizing: border-box !important;
                }
                ${active} [data-testid="chat-column"] > [data-testid="transcript-list"] {
                    max-width: var(--aiw-chat-max) !important;
                    margin-inline: auto !important;
                    box-sizing: border-box !important;
                }
                /* Keep the composer centered, including when it's switched off:
                   otherwise widening the parent would widen it indirectly. */
                ${active} [data-testid="chat-column"]
                    > :has([data-testid="chat-input"]) {
                    width: 100% !important;
                    max-width: var(--aiw-claude-composer-cap) !important;
                    margin-inline: auto !important;
                    box-sizing: border-box !important;
                }
                /* Standalone home-screen composer, when Claude uses one. */
                ${composer} #static-composer:not([data-composer-arm="marlin"])
                    #static-composer-box {
                    max-width: var(--aiw-composer-max) !important;
                    box-sizing: border-box !important;
                }
            `,
            jules: `
                /* Only the chat column; never resize the adjacent resizable
                   code panel or its draggable split-view parent. */
                ${active} .chat-container > swebot-chat.chat {
                    width: 100% !important;
                    max-width: max(var(--aiw-chat-max),
                        var(--aiw-composer-effective)) !important;
                    box-sizing: border-box !important;
                }
                ${active} swebot-chat.chat > .chat-content {
                    width: 100% !important;
                    max-width: var(--aiw-chat-max) !important;
                    margin-inline: auto !important;
                    box-sizing: border-box !important;
                }
                ${active} swebot-chat.chat .chat-content > .chat-history {
                    width: 100% !important;
                    max-width: 100% !important;
                    box-sizing: border-box !important;
                }
                ${active} swebot-chat.chat .chat-history :is(
                    swebot-agent-chat-bubble, swebot-user-chat-bubble,
                    swebot-mcp-tool-output, swebot-plan,
                    swebot-markdown-viewer.message, .message-container
                ) {
                    max-width: 100% !important;
                    box-sizing: border-box !important;
                }
                /* Preserve natural user-bubble widths. */
                ${composer} swebot-chat.chat > .bottom-bar-container {
                    width: 100% !important;
                    max-width: var(--aiw-composer-max) !important;
                    margin-inline: auto !important;
                    box-sizing: border-box !important;
                }
                ${composer} swebot-chat.chat .bottom-bar-container
                    > .input-box-container,
                ${composer} swebot-chat.chat .bottom-bar-container
                    swebot-input-box,
                ${composer} swebot-chat.chat .bottom-bar-container
                    :is(.input-box-form, .input-box-form > .input-box-container) {
                    width: 100% !important;
                    max-width: 100% !important;
                    box-sizing: border-box !important;
                }
            `,
        };

        return `
            /* The sites' native responsive layouts are left alone. */
            @media screen and (min-width: ${DESKTOP_BREAKPOINT}px) {
                ${active} {
                    --aiw-chat-max: ${settings.chatWidth}px;
                    --aiw-composer-max: ${settings.composerWidth}px;
                    --aiw-composer-effective: ${settings.widenComposer ? `${settings.composerWidth}px` : '0px'};
                    --aiw-claude-composer-cap: ${settings.widenComposer ? `${settings.composerWidth}px` : '50.5rem'};
                }
                ${siteRules[site]}
            }
        `;
    }

    function applySettings() {
        if (!root) return;

        root.dataset.aiwSite = site;
        root.dataset.aiwEnabled = String(settings.enabled);
        root.dataset.aiwComposer = String(settings.widenComposer);

        if (!styleElement || !styleElement.isConnected) {
            styleElement = document.getElementById(STYLE_ID) || document.createElement('style');
            styleElement.id = STYLE_ID;
            (document.head || root).appendChild(styleElement);
        }
        styleElement.textContent = buildCss();
    }

    function askWidth(label, current) {
        const response = window.prompt(
            `${label} for ${site} (${MIN_WIDTH}–${MAX_WIDTH} px):`,
            String(current),
        );
        if (response === null) return null;

        const value = Number(response.trim());
        if (!/^\d+$/.test(response.trim()) || validWidth(value) === null) {
            window.alert(`Enter a whole number between ${MIN_WIDTH} and ${MAX_WIDTH}.`);
            return null;
        }
        return value;
    }

    function registerMenu() {
        if (typeof GM === 'undefined' || typeof GM.registerMenuCommand !== 'function') return;

        const menu = (label, action) => {
            GM.registerMenuCommand(`AI Width · ${label}`, () => {
                Promise.resolve(action()).catch(error => {
                    console.error('[AI Chat Width] Menu action failed:', error);
                });
            });
        };

        menu('Enable / disable on this site', () =>
            updateSettings({ enabled: !settings.enabled }));

        menu('Set chat width (px)', () => {
            const value = askWidth('Chat width', settings.chatWidth);
            return value === null ? undefined : updateSettings({ chatWidth: value });
        });

        menu('Set composer width (px)', () => {
            const value = askWidth('Composer width', settings.composerWidth);
            return value === null ? undefined : updateSettings({ composerWidth: value });
        });

        menu('Enable / disable composer widening', () =>
            updateSettings({ widenComposer: !settings.widenComposer }));

        menu('Reset settings for this site', () => updateSettings({ ...DEFAULTS }));
    }

    async function start() {
        await loadSettings();
        applySettings();
        registerMenu();
    }

    if (root) {
        void start();
    } else {
        document.addEventListener('DOMContentLoaded', () => { void start(); }, { once: true });
    }
})();

// ==UserScript==
// @name                【分享版】自动签到
// @namespace           https://greasyfork.org/users/1615179
// @icon                data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMiIgaGVpZ2h0PSIzMiI+PGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iMTYiIGZpbGw9IiMyMkM1NUUiLz48L3N2Zz4=
// @version             0.2.0
// @description         自动完成网站的签到与打卡。
// @description:en      Automatically performs daily check-ins and tasks for websites.
// @author              苏预
// @match               https://www.jyeoo.com/*
// @match               https://www.52pojie.cn/*
// @match               https://www.1000qm.vip/*
// @match               https://www.smzdm.com/
// @match               https://vip.lzzcc.cn/
// @match               https://www.wenshushu.cn/*
// @include             https://ikuuu.*/*
// @run-at              document-end
// @grant               GM.getValue
// @grant               GM.setValue
// @grant               GM.deleteValue
// @grant               unsafeWindow
// @require             https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js
// @homepage            https://greasyfork.org/scripts/583682
// @license             MIT
// @downloadURL https://update.greasyfork.org/scripts/583682/%E3%80%90%E5%88%86%E4%BA%AB%E7%89%88%E3%80%91%E8%87%AA%E5%8A%A8%E7%AD%BE%E5%88%B0.user.js
// @updateURL https://update.greasyfork.org/scripts/583682/%E3%80%90%E5%88%86%E4%BA%AB%E7%89%88%E3%80%91%E8%87%AA%E5%8A%A8%E7%AD%BE%E5%88%B0.meta.js
// ==/UserScript==
// @name:en             Auto Check In


// 具体功能: 支持对以下网站进行自动签到：
// 　　　　  【分享版】菁优网，吾爱破解，什么值得买，阡陌居，大海资源库，文叔叔，iKuuu
// 　　　　  【自用版】
// 更新时间: 2026-09-26
// 更新内容: v0.1.0 调整版本号，准备发布。
// 　　　　  v0.2.0 完成分享版。使用路由数组分离自用与共用网站。
// 　　　　  
// 待 完 成: 大量网站的LoginCheck还没做。
// 　　　　　可以利用时间戳判断签到是否完成，完成后跳转某个页面。


(async function () {
    "use strict";

    // 公共路由表
    const GREEN_ROUTES = [
        {
            name: "阡陌居",
            match: ["www.1000qm.vip"],
            action: async () => {
                if (await shouldVisitOnce("阡陌居威望")) { toURL("/home.php?mod=task&do=apply&id=1"); return; }
                if (await shouldVisitOnce("阡陌居")) { toURL("/plugin.php?id=dsu_paulsign:sign"); return; }
                if (!isURL("dsu_paulsign")) return;
                CheckIn1();
            }
        },
        {
            name: "菁优网",
            match: ["www.jyeoo.com"],
            action: async () => {
                if (isURL("loginform")) return;
                LoginCheck(false,"登录",false,"/account/loginform?t=&u=%2f&r=38");
                if (!isURL("profile")) return;
                defaultCheckIn("#sign","#FDCB91",52);
            }
        },
        {
            name: "什么值得买",
            match: ["www.smzdm.com"],
            action: async () => {
                LoginCheck(false,"发现更多精彩",true,".J_login_trigger",3);
                defaultCheckIn(".J_punch","签到领奖",11,3);
            }
        },
        {
            name: "吾爱破解",
            match: ["www.52pojie.cn"],
            action: async () => {
                if (isURL("login")) return;
                LoginCheck(true,"a[href='member.php?mod=52register']",false,"/member.php?mod=logging&action=login");
                if (isURL("search.php") || isURL("home.php") || isURL("member.php")) return;
                defaultCheckIn(".qq_bind","qds.png",21);
            }
        },
        {
            name: "文叔叔",
            match: ["www.wenshushu.cn"],
            action: async () => {
                defaultCheckIn(".icon-cont_clock.icon-cont","icon-cont_complete",42);
            }
        },
        {
            name: "大海资源库",
            match: ["vip.lzzcc.cn"],
            action: async () => {
                LoginCheck(true,".signin-loader",true,".signin-loader");
                defaultCheckIn("a.img-badge.jb-yellow.initiate-checkin","已签到",92,8);
            }
        },
        {
            name: "iKuuu",
            match: [".ikuuu."],
            action: async () => {
                if (!isURL("user")) return;
                defaultCheckIn(".btn-primary","每日签到",11,3);
            }
        }
    ];

    // 自用路由表
    const PRIVATE_ROUTES = [
    ];

    const CURRENT_ROUTES = [...GREEN_ROUTES, ...PRIVATE_ROUTES];

    for (const route of CURRENT_ROUTES) {
        // 如果当前 URL 匹配路由表中的任一域名
        if (route.match.some(domain => isURL(domain))) {
            console.log(`[自动签到] 命中规则: ${route.name}`);
            try {
                await route.action();
            } catch (e) {
                console.error(`[自动签到] ${route.name} 执行出错:`, e);
            }
            return; // 匹配并执行完毕后，立即退出主函数
        }
    }
})();


// ==================== 辅助函数 ====================
/**
 * 通用登录检查与执行函数。
 * 在指定延迟后，检查用户是否已登录。如果未登录，则执行点击登录按钮或跳转到登录页面的操作。
 * 函数的核心逻辑是：通过检查“未登录状态的标志”（如“登录”按钮或“请登录”文本）是否存在，来判断是否需要执行登录操作。
 *
 * @param {boolean} [CheckMode=true] - 检测模式。`true` 为元素检测（querySelector），`false` 为文本检测（window.find）。**默认为 `true`**。
 * @param {string} CheckElement - 用于判断“未登录”状态的标志。根据 `CheckMode`，它可以是一个 CSS 选择器或一段文本。如果此标志存在，则判定为未登录。
 * @param {boolean} [LoginMode=true] - 登录操作的模式。`true` 为点击元素（click），`false` 为跳转页面（window.location.href）。**默认为 `true`**。
 * @param {string} LoginElement - 登录操作的目标。根据 `LoginMode`，它可以是一个 CSS 选择器或一个 URL 字符串。
 * @param {number} [DelayTime=2] - 执行检查前的延迟时间，单位为秒。**默认为 `2`**。
 *
 * @example
 * // 示例1 (吾爱破解): 检测到“注册”链接存在时，跳转到登录页。
 * LoginCheck(true, "a[href='member.php?mod=52register']", false, "/member.php?mod=logging&action=login");
 *
 * @example
 * // 示例2 (什么值得买): 检测到页面文本 "发现更多精彩" 存在时，点击登录按钮。
 * LoginCheck(false, "发现更多精彩", true, ".J_login_trigger", 3);
 */
function LoginCheck(CheckMode = true,CheckElement = null,LoginMode = true,LoginElement = null,DelayTime = 2) {
    window.setTimeout(function(){
        if (CheckMode && !document.querySelector(CheckElement)) {
            console.log("已登录。");
            return;
        }
        if (!CheckMode && !window.find(CheckElement)) {
            console.log("已登录。");
            return;
        }
        if (LoginMode) {
            document.querySelector(LoginElement).click();
        } else {
            window.location.href = LoginElement;
        }
    },DelayTime*1000);
}

/**
 * 默认签到函数
 * @param {string} CheckInButton - 签到按钮的元素选择器，默认为 null
 * @param {string} CheckContent - 需要匹配的内容，默认为 null
 * @param {number} CheckMode - 文本的检测方式，默认为 11
 * @param {number} DelayTime - 脚本延迟时间，单位秒，默认为 2.5
 * @param {boolean} DateLimit - 是否启用日期限制，默认不启用（启用时，当天不会再次点击）
 * @param {boolean} MinuteLimit - 是否启用间隔限制，默认不启用（启用时，在规定时间间隔内不会再次点击）
 * @param {number} LimitTime - 启用间隔限制时，规定的间隔时长，单位分钟，默认为 30
 * @description
 * 1. 根据 CheckInButton 查找签到按钮元素，如果未找到则退出。
 * 2. 根据 CheckMode 判定检测模式，检测内容为 CheckContent ：
 *    - 11: 元素文本检测模式，匹配时执行签到。12: 不匹配时执行签到。（多个文本请用|分隔）
 *    - 21: 元素图片检测模式，匹配时执行签到。22: 不匹配时执行签到。
 *    - 31: 元素链接检测模式，匹配时执行签到。32: 不匹配时执行签到。
 *    - 41: 元素类检测模式，匹配时执行签到。42: 不匹配时执行签到。（注意类不要加.前缀）
 *    - 51: 元素背景颜色检测模式，匹配时执行签到。52: 不匹配时执行签到。
 *    - 91: 页面检测模式，匹配时执行签到。92: 不匹配时执行签到。（不建议使用）
 *    - 0: 无检测模式，仅根据 CheckInButton 是否存在判断。（不建议使用；使用时，建议配合日期限制）
 * 3. 如果启用了日期限制或间隔限制，检查是否满足条件。
 * 4. 根据检测结果执行签到操作，并记录时间戳。
 * @example
 * defaultCheckIn(".checkin", "已签到|已打卡", 12, 3, false, true, 1320);
 */
function defaultCheckIn(CheckInButton = null,CheckContent = null,CheckMode = 11,DelayTime = 2.5,DateLimit = false,MinuteLimit = false,LimitTime = 30) {
    window.setTimeout(async function(){
        const element = document.querySelector(CheckInButton);
        //(未找到签到按钮元素时)
        if (element == null) {
            console.log("签到按钮元素未找到！");
            return;
        }
        //(未设置匹配文本时)进入无检测模式；(否则)分割匹配文本
        if (CheckContent == null) {
            CheckMode = 0;
        } else {
            var CheckContentArray = CheckContent.split("|");
            var isSigned = true;
        }
        //(元素背景颜色检测模式时)获取当前签到按钮的背景颜色
        if (CheckMode === 51 || CheckMode === 52) {
            var backgroundColor = window.getComputedStyle(element).getPropertyValue("background-color");
            backgroundColor = rgbToHex(backgroundColor);
        }
        //(距离上次签到时间太短时)
        if (!await checkClickTime(DateLimit, MinuteLimit, LimitTime)) {
            console.log("当天已经签到，无需再次操作。");
            return;
        }

        switch (CheckMode) {
            case 0:
                await elementClick(element, DateLimit, MinuteLimit);
                return;
            case 11:
                for (let i = 0; i < CheckContentArray.length; i++) {
                    if (element.textContent.includes(CheckContentArray[i])) {
                        await elementClick(element, DateLimit, MinuteLimit);
                        isSigned = false;
                        break;
                    }
                }
                if (isSigned) {
                    console.log("已经签到过了。");
                }
                return;
            case 12:
                isSigned = false;
                for (let i = 0; i < CheckContentArray.length; i++) {
                    if (element.textContent.includes(CheckContentArray[i])) {
                        console.log("已经签到过了。");
                        isSigned = true;
                        break;
                    }
                }
                if (!isSigned) {
                    await elementClick(element, DateLimit, MinuteLimit);
                }
                return;
            case 21:
                if (element.src.includes(CheckContent)) {
                    await elementClick(element, DateLimit, MinuteLimit);
                } else {
                    console.log("已经签到过了。");
                }
                return;
            case 22:
                if (!element.src.includes(CheckContent)) {
                    await elementClick(element, DateLimit, MinuteLimit);
                } else {
                    console.log("已经签到过了。");
                }
                return;
            case 31:
                if (element.href.includes(CheckContent)) {
                    await elementClick(element, DateLimit, MinuteLimit);
                } else {
                    console.log("已经签到过了。");
                }
                return;
            case 32:
                if (!element.href.includes(CheckContent)) {
                    await elementClick(element, DateLimit, MinuteLimit);
                } else {
                    console.log("已经签到过了。");
                }
                return;
            case 41:
                if (element.classList.contains(CheckContent)) {
                    await elementClick(element, DateLimit, MinuteLimit);
                } else {
                    console.log("已经签到过了。");
                }
                return;
            case 42:
                if (!element.classList.contains(CheckContent)) {
                    await elementClick(element, DateLimit, MinuteLimit);
                } else {
                    console.log("已经签到过了。");
                }
                return;
            case 51:
                if (backgroundColor == CheckContent) {
                    await elementClick(element, DateLimit, MinuteLimit);
                } else {
                    console.log("已经签到过了。");
                }
                return;
            case 52:
                if (backgroundColor != CheckContent) {
                    await elementClick(element, DateLimit, MinuteLimit);
                } else {
                    console.log("已经签到过了。");
                }
                return;
            case 91:
                if (window.find(CheckContent)) {
                    await elementClick(element, DateLimit, MinuteLimit);
                } else {
                    console.log("已经签到过了。");
                }
                return;
            case 92:
                if (!window.find(CheckContent)) {
                    await elementClick(element, DateLimit, MinuteLimit);
                } else {
                    console.log("已经签到过了。");
                }
                return;
            default:
                console.log("CheckMode参数错误！");
        }
    }, DelayTime * 1000);
}

/**
 * 补充签到函数1
 * @param {string} EmojiImg - 表情图片元素的选择器，默认为 "#kx"
 * @param {string} todaysay - 签到输入框元素的选择器，默认为 "#todaysay"（传递值为 null 时，将忽略输入框）
 * @param {string} CheckInButton - 签到按钮元素的选择器，默认为 "#qiandao"
 * @param {string} CheckContent - 页面中需要匹配的签到文本，默认为 "签到领奖!"
 * @param {number} DelayTime - 脚本延迟时间，单位秒，默认为 2.5
 * @param {boolean} DateLimit - 是否启用日期限制，默认为 false ，不启用（启用时，当天不会再次点击）
 * @param {boolean} MinuteLimit - 是否启用间隔限制，默认为 false ，不启用（启用时，在规定时间间隔内不会再次点击）
 * @param {number} LimitTime - 启用间隔限制时，规定的间隔时长，单位分钟，默认为 30
 * @description
 * 1. 查找签到按钮、输入框和表情图片元素。
 * 2. 检查是否满足日期或间隔限制，如果不满足则退出。
 * 3. 如果未找到签到按钮：
 *    - 如果页面中包含匹配的签到文本，跳转到签到页面。
 *    - 否则，认为当天已签到。
 * 4. 如果未找到表情图片元素，提示脚本配置错误。
 * 5. 如果找到表情图片元素，点击选中。
 * 6. 如果找到签到输入框元素，设置输入框内容。
 * 7. 提交签到表单。
 * @example
 * CheckIn1("#fd", null, undefined, "签到领奖!", 3, false, true, 30);
 */
function CheckIn1(EmojiImg = "#kx", todaysay = "#todaysay", CheckInButton = "#qiandao", CheckContent = "签到领奖!", DelayTime = 2.5, DateLimit = false, MinuteLimit = false, LimitTime = 30) {
    window.setTimeout(async function () {
        const button = document.querySelector(CheckInButton);
        const content = document.body.innerText.includes(CheckContent);
        let say = null;
        // 距离上次签到时间太短
        if (!await checkClickTime(DateLimit, MinuteLimit, LimitTime)) {
            console.log("当天已经签到，无需再次操作。");
            return;
        }
        // 检查签到按钮元素
        if (button == null) {
            if (content) {
                toURL("plugin.php?id=dsu_paulsign:sign");
            } else {
                console.log("今天已经签到过了。");
            }
            return;
        }
        // 检查签到图片元素，并选图像
        const img = document.querySelector(EmojiImg);
        if (img == null) {
            console.warn("签到图片元素未找到，请核对脚本。");
            return;
        } else {
            img.click();
            ///img.checked = true;
        }
        // 检查签到对话元素，并键入签到语句
        if (todaysay != null) {
            say = document.querySelector(todaysay);
            if (say == null) {
                console.warn("签到对话元素未找到，请核对脚本。");
                return;
            } else {
                say.value = "每天签到水一发～～～";
            }
        }
        // 提交签到表单
        await elementClick(button, DateLimit, MinuteLimit, true);
    }, DelayTime * 1000);
}

/**
 * 检查上次点击时间
 * @param {boolean} DateLimit - 是否启用日期限制，默认不启用（启用时，当天不会再次点击）
 * @param {boolean} MinuteLimit - 是否启用间隔限制，默认不启用（启用时，在规定时间间隔内不会再次点击）
 * @param {number} LimitTime - 启用间隔限制时，规定的间隔时长，单位分钟，默认为 30
 * @returns {boolean} 返回 true 表示无限制，可以继续操作；返回 false 表示有限制，不能继续操作
 */
async function checkClickTime(DateLimit = false, MinuteLimit = false, LimitTime = 30) {
    const lastTimestamp = await GM.getValue("clickTimestamp");
    if (lastTimestamp) {
        const lastTime = new Date(Number(lastTimestamp));
        const currentTime = new Date();
        // 启用日期限制
        if (DateLimit) {
            if (
                currentTime.getMonth() === lastTime.getMonth() &&
                currentTime.getDate() === lastTime.getDate()
            ) {
                console.log("当天已经签到，无需再次操作。");
                return false;
            }
        }
        // 启用间隔限制
        if (MinuteLimit) {
            const interval = (currentTime.getTime() - lastTime.getTime()) / 1000 / 60;
            if (interval < LimitTime) {
                console.log(`${parseInt(interval)}分钟前已经点击过了，无需再次操作。`);
                return false;
            }
        }
        // 无限制时，清除时间戳
        await GM.deleteValue("clickTimestamp");
    }
    return true;
}

/**
 * 点击操作和时间戳记录
 * @param {HTMLElement} element - 需要操作的元素（如按钮或表单）
 * @param {boolean} DateLimit - 是否启用日期限制，默认为 false
 * @param {boolean} MinuteLimit - 是否启用间隔限制，默认为 false
 * @param {boolean} SubmitMode - 是否以提交表单的方式操作，默认为 false
 * @description
 * 1. 如果 SubmitMode 为 true，调用元素的 submit 方法（适用于表单提交）。
 * 2. 如果 SubmitMode 为 false，调用元素的 click 方法（适用于按钮点击）。
 * 3. 如果启用了日期限制或间隔限制，记录当前时间戳到 localStorage。
 * 4. 在控制台输出签到成功的日志信息。
 */
async function elementClick(element, DateLimit = false, MinuteLimit = false, SubmitMode = false) {
    if (SubmitMode) {
        element.submit();
    } else {
        element.click();
    }
    if (DateLimit || MinuteLimit) {
        await GM.setValue("clickTimestamp", new Date().getTime());
    }
    console.log("签到成功，哎嘿嘿~");
    return true;
}

/** 将RGB格式颜色转换为十六进制 */
function rgbToHex(rgb) {
    const [r, g, b] = rgb.match(/\d+/g).map(Number);
    return "#" + [r, g, b].map(x => x.toString(16).padStart(2, "0")).join("").toUpperCase();
}

// 传递的url和当前url是否包含
function isURL(x) {
    return window.location.href.indexOf(x) != -1;
}

// 跳转到传递的地址
function toURL(x) {
    window.location.href=x;
}

/**
 * 检查今天是否应该访问一次某个页面
 * @param {string} name - 用于存储的唯一名称
 * @returns {Promise<boolean>} - 返回 true 表示需要访问，false 表示今天已访问过。
 */
async function shouldVisitOnce(name) {
    const t = new Date();
    const time = [t.getFullYear(), t.getMonth() + 1, t.getDate()].join("/");
    const itemName = "qd_" + name;
    const lastStoredTime = await GM.getValue(itemName);
    if (lastStoredTime !== time) {
        await GM.setValue(itemName, time);
        return true;
    }
    return false;
}

// 取消前后空格
function trim(s){
    return s.replace(/(^\s*)|(\s*$)/g, "");
}
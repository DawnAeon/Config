// ==UserScript==
// @name         Tube Cleaner
// @namespace    com.skula.wblock
// @version      0.1.56
// @description  Gives YouTube Safari-native controls, chapters, subtitles, SponsorBlock, picture-in-picture, background playback, quality selection, and audio-only mode.
// @description:de  Bietet YouTube native Safari-Steuerelemente, Kapitel, Untertitel, SponsorBlock, Bild-in-Bild, Hintergrundwiedergabe, Qualitätsauswahl und einen Nur-Audio-Modus.
// @description:es  Añade a YouTube controles nativos de Safari, capítulos, subtítulos, SponsorBlock, imagen en imagen, reproducción en segundo plano, selección de calidad y modo de solo audio.
// @description:fr  Ajoute à YouTube les commandes natives de Safari, les chapitres, les sous-titres, SponsorBlock, l’image dans l’image, la lecture en arrière-plan, le choix de qualité et le mode audio seul.
// @description:it  Aggiunge a YouTube controlli nativi di Safari, capitoli, sottotitoli, SponsorBlock, picture-in-picture, riproduzione in background, selezione qualità e modalità solo audio.
// @description:pt-BR  Adiciona ao YouTube controles nativos do Safari, capítulos, legendas, SponsorBlock, picture-in-picture, reprodução em segundo plano, seleção de qualidade e modo somente áudio.
// @description:ja  YouTubeにSafariネイティブのコントロール、チャプター、字幕、SponsorBlock、ピクチャ・イン・ピクチャ、バックグラウンド再生、画質選択、音声のみモードを追加します。
// @description:ko  YouTube에 Safari 네이티브 컨트롤, 챕터, 자막, SponsorBlock, PIP, 백그라운드 재생, 화질 선택 및 오디오 전용 모드를 추가합니다.
// @description:ru  Добавляет YouTube нативные элементы управления Safari, главы, субтитры, SponsorBlock, картинку-в-картинке, фоновое воспроизведение, выбор качества и аудиорежим.
// @description:zh-Hans  为 YouTube 添加 Safari 原生控件、章节、字幕、SponsorBlock、画中画、后台播放、画质选择和纯音频模式。
// @author       wBlock
// @match        https://www.youtube.com/*
// @match        https://youtube.com/*
// @match        https://m.youtube.com/*
// @match        https://music.youtube.com/*
// @match        https://www.youtube-nocookie.com/*
// @match        https://youtube-nocookie.com/*
// @run-at       document-start
// @inject-into  page
// @grant        GM_getValue
// @grant        GM_setValue
// @downloadURL  https://raw.githubusercontent.com/0xCUB3/wBlock-userscripts/main/packages/tube-cleaner/dist/tube-cleaner.user.js
// @updateURL    https://raw.githubusercontent.com/0xCUB3/wBlock-userscripts/main/packages/tube-cleaner/dist/tube-cleaner.meta.js
// ==/UserScript==

(function () {
    'use strict';

    // Embed iframes are a poster and YouTube's own play button in a box the
    // host page sizes. Nativeizing them hides that chrome and leaves a blank
    // frame, so leave youtube.com/embed and youtube-nocookie alone.
    try {
        var embedHost = location.hostname || '';
        var embedPath = location.pathname || '';
        var isNocookie = /(^|\.)youtube-nocookie\.com$/i.test(embedHost);
        var isEmbedPath = /^\/(?:embed|live_embed)(?:\/|$)/.test(embedPath) ||
            /^\/shorts\/[^/]+\/embed(?:\/|$)/.test(embedPath);
        if (isNocookie || isEmbedPath) { return; }
    } catch (e) { /* continue on a regular watch page */ }

    // ------------------------------------------------------------------
    // Tube Cleaner v4.5.0
    //
    // Vinegar Extract approach: instead of trying to extract stream URLs
    // from the player response (which 403 due to SABR), we let YouTube's
    // player create and initialize the <video> element with its SABR/MSE
    // pipeline, then we repurpose that <video> element into a native
    // Safari player.
    //
    // How it works:
    //   1. Wait for YouTube's player to create a <video> element
    //   2. Detach it from YouTube's player container
    //   3. Insert it into a minimal native wrapper
    //   4. Enable Safari's native controls
    //   5. Hide YouTube's player chrome via CSS
    //   6. Ad blocking is handled by wBlock's content blocker
    //
    // This preserves full quality (SABR adaptive bitrate) while giving
    // the user a native Safari video experience.
    // ------------------------------------------------------------------

    var LOG_PREFIX = '[Tube Cleaner]';
    var STORAGE_AUDIO = 'wblock.tubeCleaner.audioOnly';
    var STORAGE_QUALITY = 'wblock.tubeCleaner.quality';
    var STORAGE_TOOLBAR_HIDDEN = 'wblock.tubeCleaner.hideToolbar';
    var STORAGE_SUBTITLES = 'wblock.tubeCleaner.subtitles';
    var STORAGE_POSITION = 'wblock.tubeCleaner.position.';
    var ATTR_CLEANED = 'data-wblock-tc-cleaned';

    var debug = !!window.__wblockTubeCleanerDebug;

    function log() {
        if (!debug) return;
        try { console.log.apply(console, [LOG_PREFIX].concat([].slice.call(arguments))); }
        catch (e) { /* ignore */ }
    }

    function warn() {
        try { console.warn.apply(console, [LOG_PREFIX].concat([].slice.call(arguments))); }
        catch (e) { /* ignore */ }
    }

    // ------------------------------------------------------------------
    // iOS / iPadOS detection
    // ------------------------------------------------------------------

    // iPadOS requesting the desktop site reports "MacIntel" with touch support.
    // Real Macs report zero maxTouchPoints in Safari. Do not inspect
    // documentElement here: production injection can run before <html> exists.
    var IS_IOS = /iPad|iPhone|iPod/.test(navigator.userAgent) ||
        (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    var IS_IPHONE = /iPhone|iPod/.test(navigator.userAgent);
    var SAFARI_MAJOR = Number((/Version\/(\d+)/.exec(navigator.userAgent) || [])[1]) || 0;
    var IS_YOUTUBE_MUSIC = location.hostname === 'music.youtube.com';
    // ------------------------------------------------------------------
    // Auto PiP
    // ------------------------------------------------------------------

    var AUTO_PIP_KEY = 'wblock.tubeCleaner.autoPiP';
    var autoPiPEnabled = true;
    var pipActive = false;

    function getAutoPiP() {
        try {
            var stored = localStorage.getItem(AUTO_PIP_KEY);
            return stored === null ? true : stored === '1';
        } catch (e) { return true; }
    }

    function setAutoPiP(v) {
        storageSet(AUTO_PIP_KEY, v ? '1' : '0');
        autoPiPEnabled = v;
    }

    try { autoPiPEnabled = getAutoPiP(); } catch (e) { /* ignore */ }

    function supportsWebkitPiP(video) {
        try {
            return !!(video && typeof video.webkitSupportsPresentationMode === 'function' &&
                video.webkitSupportsPresentationMode('picture-in-picture'));
        } catch (e) { return false; }
    }

    function isPiPActive(video) {
        return document.pictureInPictureElement === video ||
            (video && video.webkitPresentationMode === 'picture-in-picture');
    }

    function enterPiP(video) {
        if (!video || !autoPiPEnabled) return;
        if (isPiPActive(video)) return;
        if (video.paused || video.ended) return;
        try {
            if (supportsWebkitPiP(video) && typeof video.webkitSetPresentationMode === 'function') {
                // Track only PiP entered by Tube Cleaner. PiP entered manually
                // from Safari's controls must remain under the user's control.
                pipActive = true;
                video.webkitSetPresentationMode('picture-in-picture');
                log('PiP entered');
            } else if (typeof video.requestPictureInPicture === 'function') {
                pipActive = true;
                var request = video.requestPictureInPicture();
                if (request && request.catch) {
                    request.catch(function (e) {
                        pipActive = false;
                        log('PiP request rejected', e);
                    });
                }
                log('PiP entered via API');
            }
        } catch (e) {
            pipActive = false;
            warn('enterPiP failed', e);
        }
    }

    function exitPiP(video) {
        if (!video || !pipActive) return;
        if (!isPiPActive(video)) {
            pipActive = false;
            return;
        }
        try {
            if (supportsWebkitPiP(video) && typeof video.webkitSetPresentationMode === 'function') {
                video.webkitSetPresentationMode('inline');
                pipActive = false;
                log('PiP exited');
            } else if (document.pictureInPictureElement && typeof document.exitPictureInPicture === 'function') {
                var request = document.exitPictureInPicture();
                if (request && request.catch) {
                    request.catch(function (e) { log('PiP exit rejected', e); });
                }
                pipActive = false;
            }
        } catch (e) { warn('exitPiP failed', e); }
    }

    function setupAutoPiP(video) {
        if (!video || video._wblockAutoPiPHooked) return;
        video._wblockAutoPiPHooked = true;

        // Tab switch: enter PiP when tab hides, exit when visible.
        // Note: enableBackgroundPlayback() overrides document.hidden to always
        // return false, so we use _realHidden which tracks the true state.
        function onVisibilityChange() {
            if (!autoPiPEnabled) return;
            if (_realHidden) {
                if (!video.paused && !video.ended) {
                    enterPiP(video);
                }
            } else if (document.hasFocus() && isPiPActive(video)) {
                exitPiP(video);
            }
        }

        // Losing keyboard focus does not mean the video is obscured on macOS:
        // another visible window may simply be active beside Safari. Enter PiP
        // only for actual page hiding or when the video scrolls out of view.
        function onFocus() {
            if (!autoPiPEnabled) return;
            if (_realHidden) return;
            if (document.hasFocus() && isPiPActive(video)) {
                exitPiP(video);
            }
        }
        function onBlur() {
            // iPhone can suspend a video before its hidden event is delivered.
            // Enter while the page still owns an active playback gesture.
            if (IS_IPHONE && !video.paused && !video.ended) enterPiP(video);
        }

        var removeVisibilityObserver = observeRealVisibility(onVisibilityChange);
        window.addEventListener('focus', onFocus);
        window.addEventListener('blur', onBlur);

        // Scroll out of view: use IntersectionObserver.
        // On mobile YouTube the watch player is normally position:fixed (sticky).
        // Tube Cleaner overrides it to position:absolute so it scrolls with the
        // page. Without this guard the observer would enter PiP every time the
        // user scrolls past the video to read comments.
        var stickyContainer = document.getElementById('player-container-id');
        var skipScrollPiP = !!(stickyContainer && stickyContainer.classList.contains('sticky-player'));
        var scrollObserver = null;
        if (!skipScrollPiP) {
            scrollObserver = new IntersectionObserver(function (entries) {
                if (!autoPiPEnabled) return;
                entries.forEach(function (entry) {
                    if (!entry.isIntersecting && !video.paused && !video.ended) {
                        enterPiP(video);
                    } else if (entry.isIntersecting && isPiPActive(video)) {
                        exitPiP(video);
                    }
                });
            }, { threshold: 0.1 });
            scrollObserver.observe(video);
        }

        // Listen for presentation mode changes
        function onPresentationModeChange() {
            if (video.webkitPresentationMode !== 'picture-in-picture') {
                pipActive = false;
            }
            log('presentation mode changed:', video.webkitPresentationMode);
        }
        function onLeavePictureInPicture() { pipActive = false; }
        video.addEventListener('webkitpresentationmodechanged', onPresentationModeChange);
        video.addEventListener('leavepictureinpicture', onLeavePictureInPicture);

        // Release all of the above when this video is superseded, so listeners
        // and observers do not accumulate across SPA navigations.
        registerCleanup(function () {
            removeVisibilityObserver();
            window.removeEventListener('focus', onFocus);
            window.removeEventListener('blur', onBlur);
            try { if (scrollObserver) scrollObserver.disconnect(); } catch (e) { /* ignore */ }
            video.removeEventListener('webkitpresentationmodechanged', onPresentationModeChange);
            video.removeEventListener('leavepictureinpicture', onLeavePictureInPicture);
        });
    }

    // ------------------------------------------------------------------
    // Preferences
    // ------------------------------------------------------------------

    function isAudioOnly() {
        try { return localStorage.getItem(STORAGE_AUDIO) === '1'; } catch (e) { return false; }
    }

    function setAudioOnly(v) {
        storageSet(STORAGE_AUDIO, v ? '1' : '0');
    }

    function getPreferredQuality() {
        try { return localStorage.getItem(STORAGE_QUALITY) || 'auto'; } catch (e) { return 'auto'; }
    }

    // Safari's per-origin storage quota is shared with everything YouTube and
    // the wBlock warm-start cache keep on youtube.com. When it is full,
    // setItem throws and a silently swallowed write looks like a preference
    // that "did not save". Tube Cleaner's own resume positions are the only
    // thing it can make room with, so a failed write prunes the oldest of
    // them and tries once more.
    var POSITION_KEEP_ON_PRUNE = 40;

    function prunePlaybackPositions(keep) {
        var entries = [];
        try {
            for (var i = 0; i < localStorage.length; i++) {
                var key = localStorage.key(i);
                if (!key || key.indexOf(STORAGE_POSITION) !== 0) continue;
                var updatedAt = 0;
                try { updatedAt = Number(JSON.parse(localStorage.getItem(key) || 'null').updatedAt) || 0; } catch (e) { /* stale */ }
                entries.push({ key: key, updatedAt: updatedAt });
            }
        } catch (e) { return 0; }
        if (entries.length <= keep) return 0;
        entries.sort(function (a, b) { return b.updatedAt - a.updatedAt; });
        var removed = 0;
        for (var j = keep; j < entries.length; j++) {
            try { localStorage.removeItem(entries[j].key); removed++; } catch (e) { /* ignore */ }
        }
        return removed;
    }

    function storageSet(key, value) {
        try { localStorage.setItem(key, value); return true; } catch (e) { /* quota or disabled */ }
        if (!prunePlaybackPositions(POSITION_KEEP_ON_PRUNE)) return false;
        try { localStorage.setItem(key, value); return true; } catch (e) { return false; }
    }

    function storageRemove(key) {
        try { localStorage.removeItem(key); } catch (e) { /* ignore */ }
    }

    function setPreferredQuality(q) {
        storageSet(STORAGE_QUALITY, q);
    }

    function getSubtitlePreference() {
        try {
            var raw = localStorage.getItem(STORAGE_SUBTITLES);
            if (!raw) return null;
            var value = JSON.parse(raw);
            if (!value || typeof value !== 'object') return null;
            if (value.enabled === false) return { enabled: false };
            if (value.enabled === true) return {
                enabled: true,
                language: typeof value.language === 'string' ? value.language : '',
                label: typeof value.label === 'string' ? value.label : ''
            };
        } catch (e) { /* ignore corrupt preference */ }
        return null;
    }

    function setSubtitlePreference(value) {
        if (!value) { storageRemove(STORAGE_SUBTITLES); return; }
        storageSet(STORAGE_SUBTITLES, JSON.stringify(value));
    }

    // Device-level preference to keep the wBlock toolbar (quality / SB)
    // off the video entirely. Double-tap or double-click the video reveals it
    // temporarily; the checkbox lives in the SponsorBlock settings panel.
    // The in-memory mirror keeps the choice honoured for this page even when
    // the origin's storage refuses the write.
    var toolbarHiddenMirror = null;

    function isToolbarHidden() {
        if (toolbarHiddenMirror !== null) return toolbarHiddenMirror;
        try { return localStorage.getItem(STORAGE_TOOLBAR_HIDDEN) === '1'; } catch (e) { return false; }
    }

    function setToolbarHidden(hidden) {
        toolbarHiddenMirror = !!hidden;
        if (hidden) storageSet(STORAGE_TOOLBAR_HIDDEN, '1');
        else storageRemove(STORAGE_TOOLBAR_HIDDEN);
        document.dispatchEvent(new CustomEvent('wblock-tc-toolbar-pref'));
    }

    // ------------------------------------------------------------------
    // CSS injected into the page
    // ------------------------------------------------------------------

    var STYLE_ID = 'wblock-tc-style';

    var CSS = [
        // Hide YouTube's player chrome entirely. The native <video>
        // element gets its own controls from Safari.
        '#movie_player .ytp-chrome-top,',
        '#movie_player .ytp-chrome-bottom,',
        '#movie_player .ytp-gradient-top,',
        '#movie_player .ytp-gradient-bottom,',
        '#movie_player .ytp-title,',
        '#movie_player .ytp-pip-button,',
        '#movie_player .ytp-chrome-controls,',
        '#movie_player .ytp-right-controls,',
        '#movie_player .ytp-left-controls,',
        '#movie_player .ytp-play-button,',
        '#movie_player .ytp-volume-area,',
        '#movie_player .ytp-time-display,',
        '#movie_player .ytp-progress-bar,',
        '#movie_player .ytp-progress-bar-container,',
        '#movie_player .ytp-settings-button,',
        '#movie_player .ytp-settings-menu,',
        '#movie_player .ytp-panel,',
        '#movie_player .ytp-panel-menu,',
        '#movie_player .ytp-quality-menu,',
        '#movie_player .ytp-fullscreen-button,',
        '#movie_player .ytp-remote-button,',
        '#movie_player .ytp-size-button,',
        '#movie_player .ytp-subtitles-button,',
        // YouTube's DOM caption overlay. Safari renders the installed VTT
        // tracks itself, so this would only double the text once YouTube's
        // C shortcut or its remembered caption preference turns it on.
        '#movie_player .ytp-caption-window-container,',
        '#movie_player .caption-window,',
        '#movie_player .ytp-autonav-endscreen-button,',
        '#movie_player .ytp-share-button,',
        '#movie_player .ytp-watch-later-button,',
        '#movie_player .ytp-menuitem,',
        // Storyboard scrubbing preview
        '.ytp-storyboard-framepreview,',
        '.ytp-tooltip,',
        // Ad overlays
        '.ytp-ad-module,',
        '.video-ads,',
        '#player-ads,',
        '.ytp-ad-overlay-container,',
        '.ytp-ad-overlay-slot,',
        '.ytp-ad-image-overlay,',
        '.ytp-ad-overlay-image,',
        '.ytp-ad-badge,',
        // Annotations, cards, end screen
        '.ytp-ce-element,',
        '.ytp-cards-teaser,',
        '.iv-branding,',
        '.ytp-ce-covering-overlay,',
        '.ytp-ce-cover,',
        // Pause overlay
        '.ytp-pause-overlay,',
        // Autoplay countdown
        '.ytp-autonav-endscreen-countdown-overlay,',
        '.ytp-autonav-toggle-button-container,',
        // Info panel
        '.ytp-video-info-panel,',
        // Channel watermark
        '.ytp-watermark,',
        // Related videos overlay
        '.ytp-related-overlay,',
        // Large play button in center
        '.ytp-large-play-button,',
        // Unplayable text
        '.ytp-error,',
        // Spoiler overlay
        '.ytp-spoiler-overlay',
        '{ display: none !important; }',

        // Make the video container fully transparent so only the
        // native <video> element shows through.
        '#movie_player .html5-video-player,',
        '#movie_player',
        '{ background: transparent !important; }',

        // Remove padding/margins that YouTube adds for its controls.
        '#movie_player .html5-video-container',
        '{ position: static !important; }',

        // YouTube sizes and offsets the media element itself when the source is
        // narrower than 16:9. Once width/height are overridden below, retaining
        // that old left/top offset pushes square and vertical videos to one side.
        // Give Safari the whole player box and let object-fit center the picture.
        '#movie_player video',
        '{ position: absolute !important; inset: 0 !important; width: 100% !important; height: 100% !important; object-fit: contain !important; object-position: center center !important; }',

        // Hide the YouTube player container's custom cursor.
        '#movie_player',
        '{ cursor: default !important; }',

        // Hide the "Youtube" link in the player.
        '.ytp-youtube-button,',
        '.ytp-title-link',
        '{ display: none !important; }',

        // Ensure the player container doesn't clip our toolbar.
        '#movie_player',
        '{ overflow: visible !important; }',

        // Toolbar is hidden by default, appears on hover near bottom.
        // '.wblock-tc-toolbar',
        // '{ opacity: 1 !important; display: flex !important; }',

        // Ensure the native controls bar is visible on the video.
        // YouTube's player often sets the video to be a child of
        // elements with overflow:hidden or pointer-events:none.
        '.wblock-tc-native video',
        '{ display: block !important; pointer-events: auto !important; }',

        // YouTube leaves several transparent gesture/feedback layers above the
        // media element. They must not steal taps from Safari's native controls.
        '.wblock-tc-native .ytp-cued-thumbnail-overlay,',
        '.wblock-tc-native .ytp-paid-content-overlay,',
        '.wblock-tc-native .ytp-bezel,',
        '.wblock-tc-native .ytp-spinner,',
        '.wblock-tc-native .ytp-doubletap-ui-legacy,',
        '.wblock-tc-native .ytp-touch-response,',
        '.wblock-tc-native .ytp-player-content,',
        '.wblock-tc-native .html5-video-container',
        '{ pointer-events: none !important; }',

        // YouTube adds new transparent layers without keeping the class names
        // above stable. Keep every unknown descendant behind Safari's controls,
        // then restore the Tube Cleaner surfaces that must remain interactive.
        '.wblock-tc-native *',
        '{ pointer-events: none !important; }',
        '.wblock-tc-native video,',
        '.wblock-tc-native .ytp-unmute,',
        // The toolbar box itself stays transparent to the pointer: its empty
        // corners overlap Safari's volume slider, which closes on mouseleave.
        '.wblock-tc-toolbar *,',
        '.wblock-tc-native .wblock-tc-sponsor-notice,',
        '.wblock-tc-native .wblock-tc-sponsor-notice *',
        '{ pointer-events: auto !important; }',
        // A faded-out toolbar must not swallow taps.
        '.wblock-tc-toolbar.wblock-tc-toolbar-hidden,',
        '.wblock-tc-toolbar.wblock-tc-toolbar-hidden *,',
        '.wblock-tc-native .wblock-tc-toolbar.wblock-tc-toolbar-hidden,',
        '.wblock-tc-native .wblock-tc-toolbar.wblock-tc-toolbar-hidden *',
        '{ pointer-events: none !important; }',

        // Mobile YouTube renders its new controls outside #movie_player in a
        // sibling custom-element tree. It appears after "Tap to unmute" and
        // otherwise sits above Safari's native media controls.
        '#player-control-container,',
        'ytm-custom-control,',
        'ytm-watch-player-controls',
        '{ display: none !important; pointer-events: none !important; }',

        // Mobile YouTube pins the watch player below its fixed header by adding
        // sticky-player and position:fixed to this body-level container. Keep it
        // at the same document position, but let it leave the viewport normally
        // when the user scrolls down the watch page.
        '#player-container-id.player-container',
        '{ position: absolute !important; }',

        // The related-videos filter chip bar ("All / Related / For you ...") is
        // sticky with top: calc(96px + 56.25vw), calibrated for the stock layout
        // where the player is position:fixed at the top of the viewport. Once the
        // player scrolls away (position:absolute above), that offset leaves the
        // bar floating mid-screen over the related content. Pin it to the header
        // so it sticks at the top of the viewport when scrolling past the player.
        'ytm-related-chip-cloud-renderer',
        '{ top: 48px !important; }',

        // Do not style Safari's private ::-webkit-media-controls tree. iOS and
        // macOS use different internal layouts, and forcing display/flex on the
        // iOS shadow controls breaks both video painting and touch hit-testing.

        // Make sure the video container allows native controls to
        // render by removing overflow hidden.
        '#movie_player .html5-video-container',
        '{ overflow: visible !important; }',

        // Let the native controls bar extend below the video.
        '.wblock-tc-native',
        '{ overflow: visible !important; }',

        // The active desktop-Shorts player is not guaranteed to use the
        // movie_player id. Repeat the critical cleanup rules against the class
        // applied by Tube Cleaner so alternate YouTube player instances receive
        // the same native layout.
        '.wblock-tc-native .ytp-chrome-top,',
        '.wblock-tc-native .ytp-chrome-bottom,',
        '.wblock-tc-native .ytp-gradient-top,',
        '.wblock-tc-native .ytp-gradient-bottom,',
        '.wblock-tc-native .ytp-title,',
        '.wblock-tc-native .ytp-large-play-button,',
        '.wblock-tc-native .ytp-ad-module,',
        '.wblock-tc-native .video-ads,',
        '.wblock-tc-native .ytp-ad-overlay-container,',
        '.wblock-tc-native .ytp-ce-element,',
        '.wblock-tc-native .ytp-cards-teaser,',
        '.wblock-tc-native .ytp-pause-overlay,',
        '.wblock-tc-native .ytp-autonav-endscreen-countdown-overlay,',
        '.wblock-tc-native .ytp-watermark,',
        '.wblock-tc-native .ytp-related-overlay,',
        '.wblock-tc-native .ytp-inline-preview-ui,',
        '.wblock-tc-native .ytp-inline-preview-scrim,',
        // setQuality() drives YouTube's hidden menu for SABR reliability. Hide
        // its entire shell—not just menu items—so the panel cannot flash while
        // our quality picker changes the setting programmatically.
        '.wblock-tc-native .ytp-settings-menu,',
        '.wblock-tc-native .ytp-panel,',
        '.wblock-tc-native .ytp-panel-menu,',
        '.wblock-tc-native .ytp-quality-menu,',
        '.wblock-tc-native .ytp-error',
        '{ display: none !important; }',

        '.wblock-tc-native .html5-video-container',
        '{ position: static !important; overflow: visible !important; }',

        '.wblock-tc-native video',
        '{ position: absolute !important; inset: 0 !important; width: 100% !important; height: 100% !important; object-fit: contain !important; object-position: center center !important; }',

        // On a regular watch page, square and portrait videos can use more of a
        // narrow viewport by growing the reserved player frame toward their
        // natural ratio. The height is calculated in JavaScript and capped to
        // keep very tall videos from taking over a desktop page.
        '.wblock-tc-aspect-host',
        '{ box-sizing: border-box !important; height: var(--wblock-tc-player-height) !important; min-height: var(--wblock-tc-player-height) !important; max-height: none !important; aspect-ratio: auto !important; padding-top: 0 !important; padding-bottom: 0 !important; }',

        // Some YouTube layouts keep the player in an absolutely positioned,
        // fixed-ratio wrapper. In those layouts, growing #movie_player does not
        // move the watch content below it, so add the unreserved height there.
        '.wblock-tc-content-offset',
        '{ margin-top: var(--wblock-tc-content-margin) !important; }',

        // Prevent iOS double-tap zoom on toolbar buttons.
        '.wblock-tc-toolbar button, .wblock-tc-toolbar div',
        '{ touch-action: manipulation !important; }',

        // Safari paints native <button> chrome light gray on hover. Keep the
        // quality ladder on the dark menu instead of the system control look.
        '.wblock-tc-quality-menu,',
        '.wblock-tc-quality-menu button',
        '{ color-scheme: dark; -webkit-appearance: none; appearance: none; }',
        '.wblock-tc-quality-menu button',
        '{ background: transparent !important; }',
        '.wblock-tc-quality-menu button:hover',
        '{ background: rgba(255,255,255,0.15) !important; }',
        '.wblock-tc-quality-menu button:focus',
        '{ outline: none; }',

        // YouTube reuses #movie_player for its floating miniplayer. Keep its
        // close button and compact transport visible even while the watch
        // player is nativeized. transformPlayer() releases the native mode
        // when this class appears; these rules cover the paint transition.
        '#movie_player.ytp-small-mode .ytp-chrome-top,',
        '#movie_player.ytp-small-mode .ytp-chrome-bottom,',
        '#movie_player.ytp-small-mode .ytp-gradient-top,',
        '#movie_player.ytp-small-mode .ytp-gradient-bottom,',
        '#movie_player.ytp-small-mode .ytp-chrome-controls,',
        '#movie_player.ytp-small-mode .ytp-miniplayer-close-button,',
        '#movie_player.ytp-miniplayer .ytp-chrome-top,',
        '#movie_player.ytp-miniplayer .ytp-chrome-bottom,',
        '#movie_player.ytp-miniplayer .ytp-gradient-top,',
        '#movie_player.ytp-miniplayer .ytp-gradient-bottom,',
        '#movie_player.ytp-miniplayer .ytp-chrome-controls,',
        '#movie_player.ytp-miniplayer .ytp-miniplayer-close-button',
        '{ display: revert !important; pointer-events: auto !important; }',
    ].join(' ');

    // On mobile YouTube, html5-video-container is the positioned box that
    // anchors the media within the reserved player frame. Making it static
    // lets the native video escape into the watch-page flow, leaving an empty
    // player-sized gap above it. Keep the container's geometry on iOS while
    // still allowing the native controls to receive taps.
    if (IS_IOS) {
        CSS += ' #movie_player.wblock-tc-native .html5-video-container,' +
            ' .wblock-tc-native .html5-video-container' +
            ' { position:absolute !important;inset:0 !important;width:100% !important;height:100% !important; }';
    }

    var AUDIO_ONLY_CSS = [
        '.wblock-tc-native video,',
        '.wblock-tc-native .html5-video-container',
        '{ visibility: hidden !important; }'
    ].join(' ');

    // Opt-in (#884): hide Shorts shelves, feed tiles, and navigation entries.
    // A separate sheet so /shorts pages, which suspend the player sheet, still
    // keep Shorts out of the sidebar and tab bar. Tag and attribute hooks were
    // taken from live desktop and mobile YouTube; none depend on the UI language
    // except the "Shorts" titles, which YouTube does not translate.
    var HIDE_SHORTS_CSS = [
        'ytd-reel-shelf-renderer', 'ytm-reel-shelf-renderer', 'ytd-rich-shelf-renderer[is-shorts]',
        'grid-shelf-view-model:has(ytm-shorts-lockup-view-model)',
        'ytd-rich-section-renderer:has(ytd-rich-shelf-renderer[is-shorts])',
        'ytd-rich-item-renderer:has(ytm-shorts-lockup-view-model)',
        'ytm-shorts-lockup-view-model-v2', 'ytm-shorts-lockup-view-model',
        'ytd-video-renderer:has(a[href^="/shorts/"])', 'ytd-grid-video-renderer:has(a[href^="/shorts/"])',
        'ytm-video-with-context-renderer:has(a[href^="/shorts/"])', 'ytm-compact-video-renderer:has(a[href^="/shorts/"])',
        'ytd-guide-entry-renderer:has(a[title="Shorts"])', 'ytd-mini-guide-entry-renderer[aria-label="Shorts"]',
        'ytm-pivot-bar-item-renderer:has(.pivot-shorts)', 'yt-tab-shape[tab-title="Shorts"]'
    ].join(',') + ' { display: none !important; }';

    function injectStyles() {
        if (document.getElementById(STYLE_ID)) { return true; }
        var root = document.head || document.documentElement;
        if (!root) { return false; }
        var style = document.createElement('style');
        style.id = STYLE_ID;
        style.textContent = IS_YOUTUBE_MUSIC ? '' : CSS;
        root.appendChild(style);
        if (!IS_YOUTUBE_MUSIC && featureEnabled('hideShorts')) {
            var shorts = document.createElement('style');
            shorts.id = STYLE_ID + '-shorts';
            shorts.textContent = HIDE_SHORTS_CSS;
            root.appendChild(shorts);
        }
        // Shorts pages keep YouTube's stock UI; transformPlayer() re-enables
        // the sheet when the SPA returns to a regular page.
        if (isShortsPath()) { style.disabled = true; }
        return true;
    }

    function setAudioOnlyStyles(enabled) {
        var id = STYLE_ID + '-audio';
        var existing = document.getElementById(id);
        if (enabled && !existing) {
            var style = document.createElement('style');
            style.id = id;
            style.textContent = AUDIO_ONLY_CSS;
            (document.head || document.documentElement).appendChild(style);
        } else if (!enabled && existing) {
            existing.remove();
        }
    }

    // ------------------------------------------------------------------
    // Background playback
    // ------------------------------------------------------------------

    // Track real visibility state separately since we override the values that
    // YouTube reads. The capture listener runs before the site's listeners,
    // notifies Tube Cleaner's own observers, and keeps the hidden transition
    // from reaching YouTube's background-pause handler.
    var _realHidden = false;
    var realVisibilityObservers = [];

    function findDocumentGetter(name) {
        try {
            var proto = document;
            while (proto) {
                var descriptor = Object.getOwnPropertyDescriptor(proto, name);
                if (descriptor && typeof descriptor.get === 'function') {
                    return descriptor.get;
                }
                proto = Object.getPrototypeOf(proto);
            }
        } catch (e) { /* ignore */ }
        return null;
    }

    var nativeHiddenGetter = findDocumentGetter('hidden');

    function updateRealVisibility() {
        try {
            _realHidden = nativeHiddenGetter ? nativeHiddenGetter.call(document) : document.hidden;
        } catch (e) { /* ignore */ }
    }

    function observeRealVisibility(callback) {
        realVisibilityObservers.push(callback);
        return function () {
            var index = realVisibilityObservers.indexOf(callback);
            if (index !== -1) realVisibilityObservers.splice(index, 1);
        };
    }

    function onRealVisibilityChange(event) {
        updateRealVisibility();
        var observers = realVisibilityObservers.slice();
        for (var i = 0; i < observers.length; i++) {
            try { observers[i](); } catch (e) { /* ignore */ }
        }
        if (_realHidden && event && typeof event.stopImmediatePropagation === 'function') {
            event.stopImmediatePropagation();
        }
    }

    // Capture initially and keep using the native prototype getter after the
    // document instance properties are shadowed for background playback.
    updateRealVisibility();
    document.addEventListener('visibilitychange', onRealVisibilityChange, true);

    function enableBackgroundPlayback() {
        try {
            Object.defineProperty(document, 'hidden', {
                get: function () { return false; },
                configurable: true
            });
        } catch (e) { /* ignore */ }
        try {
            Object.defineProperty(document, 'visibilityState', {
                get: function () { return 'visible'; },
                configurable: true
            });
        } catch (e) { /* ignore */ }
        try {
            Object.defineProperty(document, 'webkitHidden', {
                get: function () { return false; },
                configurable: true
            });
        } catch (e) { /* ignore */ }
        try {
            Object.defineProperty(document, 'webkitVisibilityState', {
                get: function () { return 'visible'; },
                configurable: true
            });
        } catch (e) { /* ignore */ }
    }

    // ------------------------------------------------------------------
    // YouTube Music
    //
    // music.youtube.com ships a complete responsive player with its own
    // transport, settings page, and Media Session module, so Tube Cleaner never
    // nativeizes its <video>, adds controls, or draws a toolbar there. The
    // integration below owns only what the stock site leaves broken in Safari:
    //
    // - The document-start visibility shadow above. Song mode plays an
    //   audio-only MSE source (no video track), which WebKit lets continue under
    //   lock as long as page script does not pause it; the shadow keeps YTM's
    //   own background check reading "visible".
    // - The Audio quality choice. YTM's Playback settings menu (client id
    //   MUSIC_WEB_AUDIO_QUALITY, values '2' Normal and '1' Low) applies a pick by
    //   writing ytcfg AUDIO_QUALITY, which selects the audio itag on the next
    //   track load. Sessions the server does not remember lose it on reload, so
    //   the last pick is stored locally and written back before playback.
    // - Ad breaks. While the ad player presents (getPresentingPlayerType() 2
    //   with the ad-showing class) the <video> carries the ad media; seeking
    //   that media to its own end finishes the ad through the player's normal
    //   ended path and content resumes at 0. The content element is never sought.
    // - Now Playing. YTM publishes Media Session metadata itself; when it has
    //   not (fresh load, replaced player), the current track is published from
    //   the player API with the player bar as fallback, and handlers keep their
    //   stock meaning by driving the player API.
    // ------------------------------------------------------------------

    var MUSIC_AUDIO_QUALITY_KEY = 'wblock.tubeCleaner.musicAudioQuality';
    var MUSIC_AUDIO_QUALITY_VALUES = { '1': 'AUDIO_QUALITY_LOW', '2': 'AUDIO_QUALITY_MEDIUM' };
    var MUSIC_AD_PLAYER_TYPE = 2;
    var musicState = { video: null, player: null, unbind: null, adEnds: 0, lastAdEnd: 0, published: null, publishedId: '', owns: false };

    function musicYtcfg() {
        var cfg = window.ytcfg;
        return cfg && typeof cfg.get === 'function' && typeof cfg.set === 'function' ? cfg : null;
    }

    function getMusicAudioQuality() {
        try {
            var stored = localStorage.getItem(MUSIC_AUDIO_QUALITY_KEY);
            return /^AUDIO_QUALITY_[A-Z]+$/.test(stored || '') ? stored : null;
        } catch (e) { return null; }
    }

    function setMusicAudioQuality(value) {
        try {
            if (value) localStorage.setItem(MUSIC_AUDIO_QUALITY_KEY, value);
            else localStorage.removeItem(MUSIC_AUDIO_QUALITY_KEY);
        } catch (e) { /* ignore */ }
    }

    function applyMusicAudioQuality() {
        var cfg = musicYtcfg();
        var preferred = getMusicAudioQuality();
        if (!cfg || !preferred) return false;
        try {
            if (cfg.get('AUDIO_QUALITY') === preferred) return false;
            cfg.set('AUDIO_QUALITY', preferred);
            log('YouTube Music audio quality restored:', preferred);
            return true;
        } catch (e) { return false; }
    }

    function musicAudioQualityMenu(node) {
        var el = null;
        try { el = node && node.nodeType === 1 ? node.closest('ytmusic-setting-single-option-menu-renderer') : null; } catch (e) { return null; }
        return el && el.data && el.data.itemId === 'MUSIC_WEB_AUDIO_QUALITY' ? el : null;
    }

    function rememberMusicAudioQuality(menu) {
        try {
            var items = menu.data && menu.data.items || [];
            var item = items[menu.selected] && items[menu.selected].settingMenuItemRenderer;
            var value = item && MUSIC_AUDIO_QUALITY_VALUES[String(item.value)];
            if (!value) return;
            setMusicAudioQuality(value);
            var cfg = musicYtcfg();
            if (cfg && cfg.get('AUDIO_QUALITY') !== value) cfg.set('AUDIO_QUALITY', value);
        } catch (e) { /* ignore */ }
    }

    function onMusicSettingsClick(event) {
        var menu = musicAudioQualityMenu(event.target);
        if (!menu) return;
        // The listbox updates `selected` after this capture listener; read it
        // once the click has settled and once more after the endpoint round trip.
        setTimeout(function () { rememberMusicAudioQuality(menu); }, 0);
        setTimeout(function () { rememberMusicAudioQuality(menu); }, 600);
    }

    function musicPlayer() {
        return document.getElementById('movie_player');
    }

    function musicAdShowing(player) {
        try {
            return !!player && player.classList.contains('ad-showing') &&
                typeof player.getPresentingPlayerType === 'function' &&
                player.getPresentingPlayerType() === MUSIC_AD_PLAYER_TYPE;
        } catch (e) { return false; }
    }

    function endMusicAd(player, video) {
        // A paused ad (preroll waiting for the first tap) does not reach its
        // ended path from a seek; the playing listener retries once it runs.
        if (!video || video.paused || !musicAdShowing(player)) return false;
        var duration = Number(video.duration);
        if (!isFinite(duration) || duration <= 0) return false;
        // Wait for the ad media to actually progress: ending it during its own
        // load left the ad player stuck at the end in a pod of two.
        if (!(video.currentTime > 0.5)) return false;
        if (video.currentTime >= duration - 0.25) return false;
        var now = Date.now();
        if (now - musicState.lastAdEnd < 1000) return false;
        musicState.lastAdEnd = now;
        try { video.currentTime = duration; } catch (e) { return false; }
        musicState.adEnds++;
        log('YouTube Music ad ended');
        return true;
    }

    function musicTextOf(node) {
        if (!node) return '';
        if (typeof node === 'string') return node;
        if (node.simpleText) return String(node.simpleText);
        if (node.runs && node.runs.length) return node.runs.map(function (run) { return run.text || ''; }).join('');
        return '';
    }

    function musicTrackData(player) {
        var data = {}, details = {}, album = '';
        try { data = player.getVideoData() || {}; } catch (e) { /* ignore */ }
        try {
            var response = typeof player.getPlayerResponse === 'function' ? player.getPlayerResponse() : null;
            details = response && response.videoDetails || {};
        } catch (e) { /* ignore */ }
        try {
            var next = typeof data.getWatchNextResponse === 'function' ? data.getWatchNextResponse() : null;
            var overlay = next && next.playerOverlays && next.playerOverlays.playerOverlayRenderer;
            var mediaSession = overlay && overlay.browserMediaSession && overlay.browserMediaSession.browserMediaSessionRenderer;
            album = musicTextOf(mediaSession && mediaSession.album);
        } catch (e) { /* ignore */ }
        var bar = document.querySelector('ytmusic-player-bar');
        var barTitle = bar && bar.querySelector('.title');
        var barByline = bar && bar.querySelector('.byline');
        if (!album && barByline) {
            var albumLink = barByline.querySelector('a[href^="browse/"], a[href^="/browse/"]');
            album = albumLink ? albumLink.textContent.trim() : '';
        }
        var artistLink = barByline && barByline.querySelector('a[href^="channel/"], a[href^="/channel/"]');
        var thumbnails = details.thumbnail && details.thumbnail.thumbnails || [];
        if (!thumbnails.length && bar) {
            var image = bar.querySelector('img.image');
            if (image && image.src) thumbnails = [{ url: image.src, width: 60, height: 60 }];
        }
        return {
            id: data.video_id || details.videoId || '',
            title: String(data.title || details.title || (barTitle && barTitle.textContent.trim()) || ''),
            artist: String(data.author || details.author || (artistLink && artistLink.textContent.trim()) || ''),
            album: String(album || ''),
            artwork: thumbnails.filter(function (thumb) { return thumb && thumb.url; }).map(function (thumb) {
                var art = { src: String(thumb.url) };
                if (thumb.width && thumb.height) art.sizes = thumb.width + 'x' + thumb.height;
                return art;
            })
        };
    }

    function setupYouTubeMusic() {
        document.addEventListener('click', onMusicSettingsClick, true);
        applyMusicAudioQuality();
        document.addEventListener('yt-navigate-finish', applyMusicAudioQuality, true);
        // ytcfg is defined by an inline head script; apply again once it exists.
        if (!musicYtcfg()) {
            document.addEventListener('DOMContentLoaded', applyMusicAudioQuality, { once: true });
        }

        observeMusicPlayer();
    }

    var musicPlayerObserver = null;
    var musicClassObserver = null;

    function observeMusicPlayer() {
        if (typeof MutationObserver === 'undefined') { bindMusicPlayer(); return; }
        musicPlayerObserver = new MutationObserver(function () { bindMusicPlayer(); });
        var start = function () {
            try { musicPlayerObserver.observe(document.documentElement || document, { childList: true, subtree: true }); } catch (e) { /* ignore */ }
            bindMusicPlayer();
        };
        if (document.documentElement) start();
        else document.addEventListener('DOMContentLoaded', start, { once: true });
    }

    // YTM keeps one persistent <video>; rebind only when the player or its
    // element is actually replaced so listeners never stack.
    function bindMusicPlayer() {
        var player = musicPlayer();
        var video = player && player.querySelector('video');
        if (!player || !video) return;
        if (musicState.player === player && musicState.video === video) return;
        unbindMusicPlayer();
        musicState.player = player;
        musicState.video = video;

        var hadVideoTitle = video.hasAttribute('title');
        var originalVideoTitle = video.getAttribute('title');
        var seekGesture = false, seekWasPlaying = false, seekResumeTimer = null;
        function isSeekControl(target) {
            try { return !!(target && target.closest && target.closest('tp-yt-paper-slider#progress-bar')); }
            catch (e) { return false; }
        }
        function onSeekStart(event) {
            if (seekGesture || !isSeekControl(event.target)) return;
            seekGesture = true;
            // YTM pauses while dragging its song-mode slider. Remember the state
            // before its target listener runs so a playing song remains playing.
            seekWasPlaying = !video.paused && !video.ended;
        }
        function onSeekEnd() {
            if (!seekGesture) return;
            seekGesture = false;
            if (seekResumeTimer !== null) clearTimeout(seekResumeTimer);
            seekResumeTimer = setTimeout(function () {
                seekResumeTimer = null;
                if (seekWasPlaying && musicState.player === player && video.paused && !video.ended && !musicAdShowing(player)) {
                    try { if (typeof player.playVideo === 'function') player.playVideo(); else video.play(); } catch (e) { /* ignore */ }
                }
                seekWasPlaying = false;
            }, 100);
        }
        function onSeekCancel() { seekGesture = false; seekWasPlaying = false; }
        function onAdSignal() { endMusicAd(player, video); }
        function onTrackSignal() { syncMusicNowPlaying(player, video); }
        function onTimeUpdate() { endMusicAd(player, video); scheduleMusicPosition(player, video); }
        function onNavigate() { syncMusicNowPlaying(player, video); }
        function onVisibility() {
            // iOS suspends a real video track under lock. PiP is WebKit's public
            // background-video session and keeps that track alive; audio-only
            // song mode has no PiP support and continues through the shadowed
            // visibility state as before.
            if (_realHidden) enterPiP(video);
            else if (document.hasFocus() && isPiPActive(video)) exitPiP(video);
        }
        function onFocus() {
            if (!_realHidden && isPiPActive(video)) exitPiP(video);
        }
        function onBlur() {
            if (IS_IPHONE && !video.paused && !video.ended) enterPiP(video);
        }

        video.addEventListener('loadedmetadata', onAdSignal);
        video.addEventListener('durationchange', onAdSignal);
        video.addEventListener('playing', onAdSignal);
        video.addEventListener('timeupdate', onTimeUpdate);
        video.addEventListener('loadedmetadata', onTrackSignal);
        video.addEventListener('durationchange', onTrackSignal);
        video.addEventListener('play', onTrackSignal);
        video.addEventListener('pause', onTrackSignal);
        video.addEventListener('ended', onTrackSignal);
        document.addEventListener('yt-navigate-finish', onNavigate, true);
        document.addEventListener('pointerdown', onSeekStart, true);
        document.addEventListener('touchstart', onSeekStart, true);
        document.addEventListener('pointerup', onSeekEnd, true);
        document.addEventListener('touchend', onSeekEnd, true);
        document.addEventListener('pointercancel', onSeekCancel, true);
        document.addEventListener('touchcancel', onSeekCancel, true);
        var removeVisibilityObserver = observeRealVisibility(onVisibility);
        window.addEventListener('focus', onFocus);
        window.addEventListener('blur', onBlur);

        if (typeof MutationObserver !== 'undefined') {
            musicClassObserver = new MutationObserver(function () {
                endMusicAd(player, video);
                syncMusicNowPlaying(player, video);
            });
            try { musicClassObserver.observe(player, { attributes: true, attributeFilter: ['class'] }); } catch (e) { /* ignore */ }
        }

        musicState.unbind = function () {
            video.removeEventListener('loadedmetadata', onAdSignal);
            video.removeEventListener('durationchange', onAdSignal);
            video.removeEventListener('playing', onAdSignal);
            video.removeEventListener('timeupdate', onTimeUpdate);
            video.removeEventListener('loadedmetadata', onTrackSignal);
            video.removeEventListener('durationchange', onTrackSignal);
            video.removeEventListener('play', onTrackSignal);
            video.removeEventListener('pause', onTrackSignal);
            video.removeEventListener('ended', onTrackSignal);
            document.removeEventListener('yt-navigate-finish', onNavigate, true);
            document.removeEventListener('pointerdown', onSeekStart, true);
            document.removeEventListener('touchstart', onSeekStart, true);
            document.removeEventListener('pointerup', onSeekEnd, true);
            document.removeEventListener('touchend', onSeekEnd, true);
            document.removeEventListener('pointercancel', onSeekCancel, true);
            document.removeEventListener('touchcancel', onSeekCancel, true);
            removeVisibilityObserver();
            window.removeEventListener('focus', onFocus);
            window.removeEventListener('blur', onBlur);
            if (hadVideoTitle) video.setAttribute('title', originalVideoTitle || '');
            else video.removeAttribute('title');
            if (seekResumeTimer !== null) clearTimeout(seekResumeTimer);
        };

        endMusicAd(player, video);
        syncMusicNowPlaying(player, video);
    }

    function unbindMusicPlayer() {
        if (musicState.unbind) { try { musicState.unbind(); } catch (e) { /* ignore */ } }
        musicState.unbind = null;
        if (musicClassObserver) { try { musicClassObserver.disconnect(); } catch (e) { /* ignore */ } }
        musicClassObserver = null;
        if (musicPositionTimer !== null) { clearTimeout(musicPositionTimer); musicPositionTimer = null; }
        musicState.player = null;
        musicState.video = null;
        musicState.owns = false;
        musicState.published = null;
    }

    var musicPositionTimer = null;

    function scheduleMusicPosition(player, video) {
        if (!musicState.owns || musicPositionTimer !== null) return;
        musicPositionTimer = setTimeout(function () {
            musicPositionTimer = null;
            publishMusicPosition(player, video);
        }, 500);
    }

    function publishMusicPosition(player, video) {
        var session = navigator.mediaSession;
        if (!musicState.owns || !session || typeof session.setPositionState !== 'function') return;
        var duration = Number(video.duration), position = Number(video.currentTime), rate = Number(video.playbackRate) || 1;
        if (!isFinite(duration) || duration <= 0 || !isFinite(position) || position < 0 || rate <= 0) return;
        try { session.setPositionState({ duration: duration, playbackRate: rate, position: Math.min(position, duration) }); }
        catch (e) { /* transient media state */ }
    }

    // Publish Now Playing only when YTM has not. Its own module sets metadata
    // on videodatachange; a matching title means it is in charge and nothing
    // here touches the session. Ad metadata is YTM's as well.
    function syncMusicNowPlaying(player, video) {
        var session = navigator.mediaSession;
        if (!session || typeof MediaMetadata === 'undefined') return;
        if (musicAdShowing(player)) {
            // Ad metadata and position belong to the site's own module.
            musicState.owns = false;
            return;
        }
        var track = musicTrackData(player);
        if (!track.title) return;
        if (IS_IOS) video.setAttribute('title', track.title);
        // Keep lock-screen seeking deterministic even when YTM owns metadata.
        // These handlers preserve the site's meaning and only call its player API.
        installMusicActionHandlers(player, session);
        var current = session.metadata;
        var currentTitle = current && current.title || '';
        var stockOwns = !!current && currentTitle === track.title && current !== musicState.published;
        if (stockOwns) {
            musicState.owns = false;
            musicState.published = null;
            return;
        }
        var stale = !current || currentTitle !== track.title ||
            (current === musicState.published && musicState.publishedId !== track.id);
        if (stale) {
            var init = { title: track.title, artist: track.artist, album: track.album };
            if (track.artwork.length) init.artwork = track.artwork;
            var metadata;
            try { metadata = new MediaMetadata(init); }
            catch (e) {
                delete init.artwork;
                try { metadata = new MediaMetadata(init); } catch (ignored) { return; }
            }
            try { session.metadata = metadata; } catch (e) { return; }
            musicState.published = metadata;
            musicState.publishedId = track.id;
            musicState.owns = true;
            log('YouTube Music Now Playing published:', track.title);
        }
        if (!musicState.owns) return;
        try { session.playbackState = video.ended ? 'none' : (video.paused ? 'paused' : 'playing'); } catch (e) { /* ignore */ }
        publishMusicPosition(player, video);
    }

    // Stock meaning only: every handler forwards to the player API, and nothing
    // resumes playback on its own, so a pause from the lock screen stays paused.
    function installMusicActionHandlers(player, session) {
        if (typeof session.setActionHandler !== 'function') return;
        function call(name, args) {
            try { if (typeof player[name] === 'function') player[name].apply(player, args || []); } catch (e) { /* ignore */ }
        }
        function seekBy(offset) {
            var amount = Number(offset);
            if (!isFinite(amount) || amount === 0) amount = 10;
            try { call('seekTo', [Math.max(0, player.getCurrentTime() + amount)]); } catch (e) { /* ignore */ }
        }
        var handlers = {
            play: function () { call('playVideo'); },
            pause: function () { call('pauseVideo'); },
            seekbackward: function (details) { seekBy(-(details && details.seekOffset || 10)); },
            seekforward: function (details) { seekBy(details && details.seekOffset || 10); },
            seekto: function (details) { if (details && isFinite(details.seekTime)) call('seekTo', [details.seekTime]); },
            nexttrack: function () { call('nextVideo'); },
            previoustrack: function () { call('previousVideo'); }
        };
        for (var action in handlers) {
            try { session.setActionHandler(action, handlers[action]); } catch (e) { /* unsupported action */ }
        }
    }

    // ------------------------------------------------------------------
    // Core: extract the <video> from YouTube's player and make it native
    // ------------------------------------------------------------------

    var currentState = null;

    // ------------------------------------------------------------------
    // Per-video resource tracking
    //
    // YouTube is a single-page app. Navigating between videos (or the player
    // recreating its <video> element) used to leak resources: each new video
    // added more document/window listeners, MutationObservers, and setInterval
    // timers without removing the previous video's. We track the active video's
    // teardown callbacks and run them before activating a new video, so resource
    // counts stay flat no matter how many videos play in a session.
    // ------------------------------------------------------------------

    var activeVideo = null;
    var playerObserver = null;
    var activeCleanups = [];
    var playbackCarry = null;

    function youtubePlayerVideoId(player) {
        try {
            var data = player && typeof player.getVideoData === 'function' ? player.getVideoData() : null;
            var id = data && (data.video_id || data.videoId);
            return id && /^[A-Za-z0-9_-]{11}$/.test(String(id)) ? String(id) : null;
        } catch (e) { return null; }
    }

    // YouTube's live player reports isLive only while the stream is airing;
    // an archived stream plays as an ordinary video.
    function isYouTubeLive(player) {
        try {
            var data = player && typeof player.getVideoData === 'function' ? player.getVideoData() : null;
            return !!(data && data.isLive);
        } catch (e) { return false; }
    }

    // On a live stream WebKit's scrubber spans YouTube's synthetic duration,
    // days past the newest media, so a drag or skip lands where nothing has
    // been broadcast and playback stalls (#934). Any seek past the buffered
    // live edge is pulled back to just behind it; YouTube's own seekToLiveHead
    // does not recover once the element has jumped that far.
    function setupLiveSeekGuard(player, video) {
        var correcting = false;
        function liveEdge() {
            try {
                var ranges = video.buffered;
                return ranges && ranges.length ? ranges.end(ranges.length - 1) : null;
            } catch (e) { return null; }
        }
        function onSeeking() {
            if (correcting || !isYouTubeLive(player)) return;
            var edge = liveEdge();
            if (edge === null || !(video.currentTime > edge + 1)) return;
            correcting = true;
            try { video.currentTime = Math.max(0, edge - 0.5); }
            catch (e) { /* leave the stream where YouTube puts it */ }
            setTimeout(function () { correcting = false; }, 0);
        }
        video.addEventListener('seeking', onSeeking);
        registerCleanup(function () { video.removeEventListener('seeking', onSeeking); });
    }

    function youtubeUrlVideoId() {
        try {
            var pathMatch = location.pathname.match(/^\/(?:shorts|embed)\/([A-Za-z0-9_-]{11})(?:\/|$)/);
            var queryId = new URLSearchParams(location.search).get('v');
            if (pathMatch) return pathMatch[1];
            if (queryId && /^[A-Za-z0-9_-]{11}$/.test(queryId)) return queryId;
        } catch (e) { /* ignore malformed URLs */ }
        return null;
    }

    function youtubeVideoIdentity(player) {
        // The URL leads the persistent player during SPA navigation. YouTube's
        // player data is the confirmation that the media element changed.
        return youtubePlayerVideoId(player) || youtubeUrlVideoId();
    }

    function readPlaybackPosition(videoId) {
        try {
            var value = JSON.parse(localStorage.getItem(STORAGE_POSITION + videoId) || 'null');
            return value && isFinite(value.time) && value.time > 0 ? Number(value.time) : null;
        } catch (e) { return null; }
    }

    function writePlaybackPosition(videoId, time, duration, ended) {
        try {
            if (ended || (duration > 0 && time >= duration - 0.5)) {
                localStorage.removeItem(STORAGE_POSITION + videoId);
            } else if (isFinite(time)) {
                if (time > 0.25) {
                    storageSet(STORAGE_POSITION + videoId, JSON.stringify({ time: time, updatedAt: Date.now() }));
                } else {
                    localStorage.removeItem(STORAGE_POSITION + videoId);
                }
            }
        } catch (e) { /* ignore */ }
    }

    function setupPlaybackPosition(player, video) {
        var videoId = youtubeVideoIdentity(player);
        if (!videoId) { playbackCarry = null; return; }
        // A live stream has no stable position to come back to.
        if (isYouTubeLive(player)) { playbackCarry = null; return; }
        var previousIdentity = playbackCarry && playbackCarry.identity;
        var carried = playbackCarry && playbackCarry.identity === videoId ? playbackCarry : null;
        playbackCarry = null;
        var cancelled = false;
        var restored = false;
        var stateApplied = !carried;
        var waitingForMediaTransition = !!(previousIdentity && previousIdentity !== videoId);
        var writeTimer = null;
        var saved = readPlaybackPosition(videoId);

        function restore() {
            if (cancelled || restored || waitingForMediaTransition || activeVideo !== video ||
                youtubeVideoIdentity(player) !== videoId) return;
            if (video.readyState < 1 || !isFinite(video.duration) || video.duration <= 0) return;
            restored = true;
            var positionApplied = true;
            if (saved !== null) {
                if (saved >= video.duration - 0.5) {
                    writePlaybackPosition(videoId, 0, video.duration, true);
                } else if (Math.abs(video.currentTime - saved) > 0.75 &&
                    !(carried && previousIdentity === videoId && video.currentTime > 0.25)) {
                    try { video.currentTime = Math.min(saved, Math.max(0, video.duration - 0.1)); }
                    catch (e) { positionApplied = false; }
                }
            }
            if (!positionApplied) { restored = false; return; }
            applyState();
        }

        function applyState() {
            if (cancelled || stateApplied || !carried || activeVideo !== video) return;
            stateApplied = true;
            try {
                if (carried.paused) video.pause();
                else if (video.paused && !video.ended) {
                    var request = video.play();
                    if (request && request.catch) request.catch(function () { /* autoplay policy */ });
                }
            } catch (e) { /* preserve state when the browser permits it */ }
        }

        function persist(force) {
            if (writeTimer !== null) { clearTimeout(writeTimer); writeTimer = null; }
            if (cancelled && !force) return;
            writePlaybackPosition(videoId, Number(video.currentTime), Number(video.duration), video.ended);
        }

        function schedulePersist() {
            if (cancelled || writeTimer !== null) return;
            writeTimer = setTimeout(function () { writeTimer = null; persist(false); }, 1000);
        }

        function onEnded() { persist(true); }
        function onTimeUpdate() { schedulePersist(); }
        function onPause() { schedulePersist(); }
        function onMetadata() {
            if (waitingForMediaTransition) {
                waitingForMediaTransition = false;
                video._wblockConfirmedVideoId = videoId;
            }
            restore();
        }
        function onPageHide() { persist(true); }

        video._wblockPlaybackState = { identity: videoId, paused: video.paused };
        video._wblockConfirmedVideoId = videoId;
        video.addEventListener('loadedmetadata', onMetadata);
        video.addEventListener('durationchange', onMetadata);
        video.addEventListener('timeupdate', onTimeUpdate);
        video.addEventListener('pause', onPause);
        video.addEventListener('ended', onEnded);
        window.addEventListener('pagehide', onPageHide);
        restore();

        registerCleanup(function () {
            if (writeTimer !== null) clearTimeout(writeTimer);
            cancelled = true;
            persist(true);
            video.removeEventListener('loadedmetadata', onMetadata);
            video.removeEventListener('durationchange', onMetadata);
            video.removeEventListener('timeupdate', onTimeUpdate);
            video.removeEventListener('pause', onPause);
            video.removeEventListener('ended', onEnded);
            window.removeEventListener('pagehide', onPageHide);
            delete video._wblockPlaybackState;
        });
    }

    function registerCleanup(fn) {
        activeCleanups.push(fn);
    }

    function releaseActiveVideo() {
        var previousVideo = activeVideo;
        if (previousVideo && previousVideo._wblockPlaybackState) {
            // An emptied element is YouTube swapping streams, not a user pause.
            previousVideo._wblockPlaybackState.paused = previousVideo.paused && previousVideo.readyState > 0;
            playbackCarry = previousVideo._wblockPlaybackState;
        }
        if (qualityRequest) cancelQualityRequest();
        var cleanups = activeCleanups;
        activeCleanups = [];
        for (var i = 0; i < cleanups.length; i++) {
            try { cleanups[i](); } catch (e) { /* ignore */ }
        }
        // The same media element can survive a YouTube SPA navigation. Reset
        // hook flags after teardown so activateVideo() reattaches resources when
        // that element is immediately activated again.
        if (previousVideo) {
            previousVideo._wblockAutoPiPHooked = false;
            previousVideo._wblockControlsGuarded = false;
            previousVideo._wblockControlsPatched = false;
            previousVideo._wblockMediaSessionHooked = false;
        }
        activeVideo = null;
        pipActive = false;
    }

    // Grow a regular watch-page player toward a narrow video's natural aspect
    // ratio. YouTube reserves a 16:9 frame even for square and portrait uploads;
    // in narrow layouts that wastes most of the available width. Expand only
    // when doing so makes the player taller, and cap the result at 85% of the
    // viewport so a portrait upload cannot dominate a large desktop page.
    function setupVideoAspectLayout(player, video) {
        if (!player || !video) return;
        var isHarness = location.protocol === 'file:';
        var isWatchPage = /^\/watch(?:\/|$)/.test(location.pathname);
        if (!isHarness && (!isWatchPage || location.hostname === 'music.youtube.com')) return;
        if (/^\/shorts(?:\/|$)/.test(location.pathname)) return;

        var hosts = [];
        var updateFrame = null;
        var resizeObserver = null;
        var contentAnchor = null;

        function clearLayout() {
            if (contentAnchor) {
                contentAnchor.classList.remove('wblock-tc-content-offset');
                contentAnchor.style.removeProperty('--wblock-tc-content-margin');
                contentAnchor = null;
            }
            for (var i = 0; i < hosts.length; i++) {
                hosts[i].classList.remove('wblock-tc-aspect-host');
                hosts[i].style.removeProperty('--wblock-tc-player-height');
            }
            hosts = [];
        }

        // Find the first watch-page block after the player. Known desktop and
        // mobile containers are preferred; walking outward to the first visible
        // next sibling covers YouTube experiments with different tag names.
        function findContentAnchor(rect) {
            var selectors = [
                '#below',
                'ytm-single-column-watch-next-results-renderer',
                'ytm-watch-next-secondary-results-renderer',
                'ytm-slim-video-metadata-section-renderer',
                'ytd-watch-metadata',
                '#watch-metadata'
            ];
            for (var i = 0; i < selectors.length; i++) {
                var candidate = document.querySelector(selectors[i]);
                if (!candidate || candidate.contains(player) || player.contains(candidate)) continue;
                var candidateRect = candidate.getBoundingClientRect();
                if (candidateRect.width && candidateRect.top >= rect.bottom - 16) return candidate;
            }

            var node = player;
            for (var depth = 0; node && node.parentElement && depth < 12; depth++) {
                var sibling = node.nextElementSibling;
                while (sibling) {
                    var siblingRect = sibling.getBoundingClientRect();
                    if (siblingRect.width && siblingRect.height && siblingRect.top >= rect.bottom - 16) {
                        return sibling;
                    }
                    sibling = sibling.nextElementSibling;
                }
                node = node.parentElement;
                if (node === document.body || node === document.documentElement) break;
            }
            return null;
        }

        // Resize every consecutive wrapper that currently reserves exactly the
        // same box as #movie_player. This moves watch metadata down with the
        // taller player without touching unrelated page columns or the body.
        function findHosts(rect) {
            if (!rect.width || !rect.height) return;
            var node = player;
            for (var depth = 0; node && depth < 8; depth++) {
                if (node === document.body || node === document.documentElement) break;
                var nodeRect = node.getBoundingClientRect();
                if (Math.abs(nodeRect.width - rect.width) > 4 ||
                    Math.abs(nodeRect.height - rect.height) > 4) break;
                hosts.push(node);
                node = node.parentElement;
            }
        }

        // Mobile YouTube keeps the player in a body-level fixed container and
        // reserves flow space with a separate .player-placeholder div inside
        // ytm-watch. Rebuild this list after each geometry change so recycled
        // containers do not retain the old video's sizing.
        function ensurePlaceholderHost() {
            var placeholder = document.querySelector('.player-placeholder');
            if (placeholder && !player.contains(placeholder) && !placeholder.contains(player)) {
                var found = false;
                for (var i = 0; i < hosts.length; i++) {
                    if (hosts[i] === placeholder) { found = true; break; }
                }
                if (!found) hosts.push(placeholder);
            }
        }

        function observeGeometryHosts() {
            if (!resizeObserver) return;
            for (var i = 0; i < hosts.length; i++) {
                try { resizeObserver.observe(hosts[i]); } catch (e) { /* ignore recycled nodes */ }
            }
        }

        function updateLayout() {
            updateFrame = null;
            clearLayout();
            var rect = player.getBoundingClientRect();
            if (!rect.width || !rect.height) return;
            var baseAspect = rect.width / rect.height;
            findHosts(rect);
            ensurePlaceholderHost();
            observeGeometryHosts();

            var fullscreen = document.fullscreenElement || document.webkitFullscreenElement ||
                player.classList.contains('ytp-fullscreen') || video.webkitDisplayingFullscreen === true ||
                video.webkitPresentationMode === 'fullscreen';
            var sourceWidth = Number(video.videoWidth) || 0;
            var sourceHeight = Number(video.videoHeight) || 0;
            if (fullscreen || !sourceWidth || !sourceHeight || !hosts.length) {
                clearLayout();
                return;
            }

            var baseHeight = rect.width / baseAspect;
            var naturalHeight = rect.width * sourceHeight / sourceWidth;
            var viewportHeight = document.documentElement.clientHeight || window.innerHeight || baseHeight;
            var targetHeight = Math.min(naturalHeight, Math.max(baseHeight, viewportHeight * 0.85));
            if (targetHeight <= baseHeight + 2) {
                clearLayout();
                return;
            }

            var heightValue = Math.round(targetHeight * 100) / 100 + 'px';
            for (var i = 0; i < hosts.length; i++) {
                hosts[i].style.setProperty('--wblock-tc-player-height', heightValue);
                hosts[i].classList.add('wblock-tc-aspect-host');
            }

            // Content offset: when the outermost host is out of normal flow
            // (position:fixed/absolute), growing it does not push the watch
            // content below it. Add a margin-top to compensate. Compute this
            // synchronously (one forced reflow) instead of a second rAF to
            // avoid a visible one-frame jump.
            var anchor = findContentAnchor(rect);
            if (anchor) {
                // Remove our previous offset so we can read the natural position.
                if (anchor === contentAnchor) {
                    anchor.classList.remove('wblock-tc-content-offset');
                    anchor.style.removeProperty('--wblock-tc-content-margin');
                }
                var naturalTop = anchor.getBoundingClientRect().top;
                var playerBottom = player.getBoundingClientRect().bottom;
                var gap = playerBottom - naturalTop;
                if (gap > 1) {
                    // Add the gap to the element's existing margin so the total
                    // margin pushes it below the expanded player.
                    var existingMargin = parseFloat(getComputedStyle(anchor).marginTop) || 0;
                    var marginValue = Math.round((existingMargin + gap) * 100) / 100 + 'px';
                    anchor.style.setProperty('--wblock-tc-content-margin', marginValue);
                    anchor.classList.add('wblock-tc-content-offset');
                    contentAnchor = anchor;
                } else {
                    contentAnchor = null;
                }
            } else if (contentAnchor) {
                contentAnchor.classList.remove('wblock-tc-content-offset');
                contentAnchor.style.removeProperty('--wblock-tc-content-margin');
                contentAnchor = null;
            }
        }

        function scheduleUpdate() {
            if (updateFrame !== null) return;
            updateFrame = requestAnimationFrame(updateLayout);
        }

        video.addEventListener('loadedmetadata', scheduleUpdate);
        video.addEventListener('resize', scheduleUpdate);
        video.addEventListener('emptied', scheduleUpdate);
        window.addEventListener('resize', scheduleUpdate);
        if (typeof ResizeObserver !== 'undefined') {
            try {
                resizeObserver = new ResizeObserver(scheduleUpdate);
                resizeObserver.observe(player);
                if (player.parentElement) resizeObserver.observe(player.parentElement);
            } catch (e) { resizeObserver = null; }
        }
        document.addEventListener('fullscreenchange', scheduleUpdate);
        document.addEventListener('webkitfullscreenchange', scheduleUpdate);
        video.addEventListener('webkitbeginfullscreen', scheduleUpdate);
        video.addEventListener('webkitendfullscreen', scheduleUpdate);
        video.addEventListener('webkitpresentationmodechanged', scheduleUpdate);
        video.addEventListener('enterpictureinpicture', scheduleUpdate);
        video.addEventListener('leavepictureinpicture', scheduleUpdate);
        scheduleUpdate();

        registerCleanup(function () {
            video.removeEventListener('loadedmetadata', scheduleUpdate);
            video.removeEventListener('resize', scheduleUpdate);
            video.removeEventListener('emptied', scheduleUpdate);
            window.removeEventListener('resize', scheduleUpdate);
            document.removeEventListener('fullscreenchange', scheduleUpdate);
            document.removeEventListener('webkitfullscreenchange', scheduleUpdate);
            video.removeEventListener('webkitbeginfullscreen', scheduleUpdate);
            video.removeEventListener('webkitendfullscreen', scheduleUpdate);
            video.removeEventListener('webkitpresentationmodechanged', scheduleUpdate);
            video.removeEventListener('enterpictureinpicture', scheduleUpdate);
            video.removeEventListener('leavepictureinpicture', scheduleUpdate);
            if (resizeObserver) { try { resizeObserver.disconnect(); } catch (e) { /* ignore */ } }
            resizeObserver = null;
            if (updateFrame !== null) cancelAnimationFrame(updateFrame);
            clearLayout();
        });
    }

    // Activate a video element: tear down the previous video's resources first,
    // then apply every per-video enhancement. Called on first transform and again
    // whenever the player recreates its <video> element.
    function activateVideo(player, video) {
        releaseActiveVideo();
        activeVideo = video;
        if (featureEnabled('resumePosition')) setupPlaybackPosition(player, video);
        registerCleanup(cancelQualityRequest);
        registerCleanup(cancelMobileQualityRestore);
        forceNativeControls(video);
        guardNativeControls(video);
        pinNativeControls(video);
        setupNativeTouchControls(video);

        // Safari's controls live in WebKit's shadow tree, so let events reach
        // the video in the bubble phase but stop YouTube's outer player shell
        // from treating native scrubber and long-press gestures as player taps.
        // Blocking the move and mouse-compat events keeps YouTube's bubble-phase
        // handlers quiet, but its capture-phase document handlers run first and
        // still see the stream; pinNativeControls() is what actually keeps a
        // native scrubber drag alive.
        var competingEvents = [
            'click', 'pointerdown', 'pointermove', 'pointerup',
            'mousedown', 'mousemove', 'mouseup',
            'touchstart', 'touchmove', 'touchend'
        ];
        function blockCompetingClicks(event) { event.stopPropagation(); }
        for (var i = 0; i < competingEvents.length; i++) {
            video.addEventListener(competingEvents[i], blockCompetingClicks);
        }
        registerCleanup(function () {
            for (var i = 0; i < competingEvents.length; i++) {
                video.removeEventListener(competingEvents[i], blockCompetingClicks);
            }
        });

        setupVideoAspectLayout(player, video);
        setupPinchFullscreen(player, video);
        // Keep YouTube's media listeners intact. SABR/MSE uses waiting,
        // stalled, progress, and related events to maintain the stream. The
        // iOS toolbar contains only a compact quality selector positioned above
        // Safari's native controls; playback remains owned by the video element.
        if (featureEnabled('toolbar')) buildToolbar(player, video);
        if (featureEnabled('pictureInPicture')) setupAutoPiP(video);
        setupMediaSession(player, video);
        setupLiveSeekGuard(player, video);
        if (featureEnabled('chapters')) setupChapters(player, video);
        if (featureEnabled('captions')) setupNativeSubtitles(player, video);
        if (featureEnabled('sponsorBlock')) setupSponsorBlock(player, video);
        if (IS_IOS) {
            // Let SABR start adaptively; restore our preference only after progress.
            storageRemove('yt-player-quality');
            applyPreferredQuality();
        }
    }

    var mediaSessionOwner = null;

    function setupMediaSession(container, video) {
        if (!video || video._wblockMediaSessionHooked || !navigator.mediaSession ||
            typeof MediaMetadata === 'undefined') return;
        video._wblockMediaSessionHooked = true;
        var session = navigator.mediaSession;
        var positionTimer = null;
        var metadataTimer = null;
        var hadVideoTitle = video.hasAttribute('title');
        var originalVideoTitle = video.getAttribute('title');

        function meta(name) {
            var element = document.querySelector('meta[property="' + name + '"],meta[name="' + name + '"]');
            return element && element.content || '';
        }

        function playerData() {
            var player = findPlayer();
            try { return player && typeof player.getVideoData === 'function' ? player.getVideoData() || {} : {}; }
            catch (e) { return {}; }
        }

        function metadataData() {
            var data = playerData();
            var details = window.ytInitialPlayerResponse && window.ytInitialPlayerResponse.videoDetails || {};
            var title = data.title || details.title || meta('og:title') || document.title || location.hostname;
            var artist = data.author || data.ownerChannelName || details.author || details.channelTitle ||
                meta('og:site_name') || location.hostname;
            var thumbnails = (data.thumbnail && data.thumbnail.thumbnails) || (details.thumbnail && details.thumbnail.thumbnails);
            var artwork = video.poster || (thumbnails && thumbnails.length && thumbnails[thumbnails.length - 1].url) || meta('og:image');
            var result = { title: String(title), artist: String(artist) };
            if (artwork) result.artwork = [{ src: String(artwork) }];
            var chapters = video._wblockChapterData;
            if (chapters && chapters.length) {
                result.chapterInfo = chapters.map(function (chapter) {
                    return { startTime: chapter.start, title: chapter.title };
                });
            }
            return result;
        }

        function clearOwner(previous) {
            if (!previous || mediaSessionOwner !== previous) return;
            (previous._wblockMediaActions || []).forEach(function (action) {
                try { if (typeof session.setActionHandler === 'function') session.setActionHandler(action, null); } catch (e) { /* ignore */ }
            });
            if (session.metadata === previous._wblockMediaMetadata) {
                try { session.metadata = null; } catch (e) { /* ignore */ }
            }
            previous._wblockMediaActions = null;
            previous._wblockMediaMetadata = null;
        }

        function refreshMetadata() {
            if (mediaSessionOwner !== video) return;
            var data = metadataData();
            if (IS_IOS && data.title) video.setAttribute('title', data.title);
            var metadata;
            try { metadata = new MediaMetadata(data); }
            catch (e) {
                delete data.chapterInfo;
                try { metadata = new MediaMetadata(data); }
                catch (ignored) {
                    delete data.artwork;
                    try { metadata = new MediaMetadata(data); } catch (ignoredAgain) { return; }
                }
            }
            if (mediaSessionOwner !== video) return;
            video._wblockMediaMetadata = metadata;
            try { session.metadata = metadata; } catch (e) { /* ignore */ }
        }

        function scheduleMetadata() {
            if (metadataTimer !== null) return;
            metadataTimer = setTimeout(function () {
                metadataTimer = null;
                refreshMetadata();
            }, 50);
        }

        function updateState() {
            if (mediaSessionOwner !== video) return;
            try { session.playbackState = video.ended ? 'none' : (video.paused ? 'paused' : 'playing'); }
            catch (e) { /* ignore */ }
        }

        function updatePosition() {
            if (mediaSessionOwner !== video || typeof session.setPositionState !== 'function' || positionTimer !== null) return;
            positionTimer = setTimeout(function () {
                positionTimer = null;
                if (mediaSessionOwner !== video) return;
                // A live stream's duration is synthetic; Now Playing would show
                // a days-long scrubber, so publish no position at all.
                if (isYouTubeLive(container)) {
                    try { session.setPositionState(); } catch (e) { /* ignore */ }
                    return;
                }
                var duration = Number(video.duration), position = Number(video.currentTime), rate = Number(video.playbackRate) || 1;
                if (!isFinite(duration) || duration <= 0 || !isFinite(position) || position < 0 || !isFinite(rate) || rate <= 0) return;
                try { session.setPositionState({ duration: duration, playbackRate: rate, position: Math.min(position, duration) }); }
                catch (e) { /* ignore transient media state */ }
            }, 200);
        }

        function seekBy(offset) {
            var amount = Number(offset);
            if (!isFinite(amount) || amount === 0) amount = 10;
            try { video.currentTime = Math.max(0, Math.min(video.duration || Infinity, video.currentTime + amount)); }
            catch (e) { /* ignore */ }
        }

        function claim() {
            if (mediaSessionOwner !== video) {
                clearOwner(mediaSessionOwner);
                mediaSessionOwner = video;
            }
            refreshMetadata();
            updateState();
            updatePosition();
            if (typeof session.setActionHandler !== 'function') return;
            var actions = {
                play: function () { var request = video.play(); if (request && request.catch) request.catch(function () {}); },
                pause: function () { try { video.pause(); } catch (e) {} },
                seekbackward: function (details) { seekBy(-(details && details.seekOffset || 10)); },
                seekforward: function (details) { seekBy(details && details.seekOffset || 10); },
                seekto: function (details) {
                    if (!details || !isFinite(details.seekTime)) return;
                    try {
                        if (details.fastSeek && typeof video.fastSeek === 'function') video.fastSeek(details.seekTime);
                        else video.currentTime = details.seekTime;
                    } catch (e) { /* ignore */ }
                },
                stop: function () { try { video.pause(); if (!video.ended) video.currentTime = 0; } catch (e) {} }
            };
            video._wblockMediaActions = Object.keys(actions);
            for (var action in actions) {
                try { session.setActionHandler(action, actions[action]); } catch (e) { /* unsupported action */ }
            }
        }

        function onPlay() { claim(); }
        function onPause() { updateState(); updatePosition(); }
        function onEnded() { updateState(); updatePosition(); }
        function onMetadataChange() { scheduleMetadata(); updatePosition(); }
        function onRateChange() { scheduleMetadata(); updatePosition(); }
        function onTimeUpdate() { updatePosition(); }
        function onNavigate() { scheduleMetadata(); }

        video.addEventListener('play', onPlay);
        video.addEventListener('pause', onPause);
        video.addEventListener('ended', onEnded);
        video.addEventListener('loadedmetadata', onMetadataChange);
        video.addEventListener('durationchange', onMetadataChange);
        video.addEventListener('loadeddata', onMetadataChange);
        video.addEventListener('ratechange', onRateChange);
        video.addEventListener('timeupdate', onTimeUpdate);
        document.addEventListener('yt-navigate-finish', onNavigate, true);
        document.addEventListener('yt-page-data-updated', onNavigate, true);
        if (!video.paused) claim();

        registerCleanup(function () {
            video.removeEventListener('play', onPlay);
            video.removeEventListener('pause', onPause);
            video.removeEventListener('ended', onEnded);
            video.removeEventListener('loadedmetadata', onMetadataChange);
            video.removeEventListener('durationchange', onMetadataChange);
            video.removeEventListener('loadeddata', onMetadataChange);
            video.removeEventListener('ratechange', onRateChange);
            video.removeEventListener('timeupdate', onTimeUpdate);
            document.removeEventListener('yt-navigate-finish', onNavigate, true);
            document.removeEventListener('yt-page-data-updated', onNavigate, true);
            if (positionTimer !== null) clearTimeout(positionTimer);
            if (metadataTimer !== null) clearTimeout(metadataTimer);
            positionTimer = null;
            metadataTimer = null;
            if (mediaSessionOwner !== video) return;
            mediaSessionOwner = null;
            if (session.metadata === video._wblockMediaMetadata) {
                try { session.metadata = null; } catch (e) { /* ignore */ }
            }
            (video._wblockMediaActions || []).forEach(function (action) {
                try { if (typeof session.setActionHandler === 'function') session.setActionHandler(action, null); } catch (e) { /* ignore */ }
            });
            try { session.playbackState = 'none'; } catch (e) { /* ignore */ }
            video._wblockMediaMetadata = null;
            video._wblockMediaActions = null;
            if (hadVideoTitle) video.setAttribute('title', originalVideoTitle || '');
            else video.removeAttribute('title');
        });
    }

    function restoreNativeMediaCapabilities(video) {
        if (!video) return;
        try {
            if (!video.controls) { video.controls = true; }
            if (!video.hasAttribute('controls')) { video.setAttribute('controls', ''); }
            ensurePlaysInline(video);
            // YouTube may suppress native PiP and fullscreen-adjacent controls
            // while its custom chrome is active. Those restrictions no longer
            // apply once Safari's native controls own interaction.
            if (video.hasAttribute('controlslist')) { video.removeAttribute('controlslist'); }
            if (video.hasAttribute('disablepictureinpicture')) { video.removeAttribute('disablepictureinpicture'); }
            if (video.disablePictureInPicture) { video.disablePictureInPicture = false; }

            var opaque = hasOpaqueMediaSource(video);
            if (IS_IOS) {
                // WebKit requires remote playback to stay disabled for ManagedMediaSource/blob playback.
                if (!video.disableRemotePlayback) { video.disableRemotePlayback = true; }
                if (!video.hasAttribute('disableremoteplayback')) {
                    video.setAttribute('disableremoteplayback', '');
                }
                if (video.getAttribute('x-webkit-airplay') === 'allow') video.removeAttribute('x-webkit-airplay');
            } else if (!opaque) {
                if (video.hasAttribute('disableremoteplayback')) { video.removeAttribute('disableremoteplayback'); }
                if (video.disableRemotePlayback) { video.disableRemotePlayback = false; }
                if (video.getAttribute('x-webkit-airplay') !== 'allow') {
                    video.setAttribute('x-webkit-airplay', 'allow');
                }
            } else if (video.getAttribute('x-webkit-airplay') === 'allow') {
                video.removeAttribute('x-webkit-airplay');
            }
        } catch (e) { /* ignore */ }
    }

    function setupNativeTouchControls(video) {
        if (!IS_IOS) return;
        var touch = null;
        var lastTap = null;

        function begin(event) {
            if (event.touches.length !== 1) { touch = null; lastTap = null; return; }
            var point = event.touches[0];
            touch = { id: point.identifier, x: point.clientX, y: point.clientY, time: Date.now() };
        }
        function move(event) {
            if (!touch) return;
            var point = event.touches[0];
            if (event.touches.length !== 1 || point.identifier !== touch.id ||
                Math.hypot(point.clientX - touch.x, point.clientY - touch.y) > 10) {
                touch = null;
                lastTap = null;
            }
        }
        function cancel() { touch = null; lastTap = null; }
        function end(event) {
            if (event.target !== video || event.touches.length) { cancel(); return; }
            // iPadOS emits compatibility mouse exits after a tap, immediately
            // fading WebKit's native controls. Cancel their generation, not the
            // pointer stream used by native buttons and scrubbers.
            event.preventDefault();
            var point = event.changedTouches[0];
            var now = Date.now();
            var tap = touch;
            touch = null;
            if (!tap || !point || point.identifier !== tap.id || now - tap.time > 500 ||
                Math.hypot(point.clientX - tap.x, point.clientY - tap.y) > 10) {
                lastTap = null;
                return;
            }
            // Notify our toolbar without synthetic mouse events to WebKit.
            var doubleTap = !!(lastTap && now - lastTap.time < 350 &&
                Math.hypot(point.clientX - lastTap.x, point.clientY - lastTap.y) < 30);
            lastTap = doubleTap ? null : { time: now, x: point.clientX, y: point.clientY };
            video.dispatchEvent(new CustomEvent('wblock-tc-video-tap', {
                detail: { doubleTap: doubleTap, clientX: point.clientX, clientY: point.clientY }
            }));
        }
        video.addEventListener('touchstart', begin, { capture: true, passive: true });
        video.addEventListener('touchmove', move, { capture: true, passive: true });
        video.addEventListener('touchcancel', cancel, true);
        video.addEventListener('touchend', end, { capture: true, passive: false });
        registerCleanup(function () {
            video.removeEventListener('touchstart', begin, true);
            video.removeEventListener('touchmove', move, true);
            video.removeEventListener('touchcancel', cancel, true);
            video.removeEventListener('touchend', end, true);
        });
    }

    function forceNativeControls(video) {
        if (video._wblockControlsPatched) return;
        video._wblockControlsPatched = true;
        restoreNativeMediaCapabilities(video);
    }

    // WebKit renders Safari's native controls from the controls content
    // attribute. Do not replace the native property descriptor: early instance
    // shadowing can break WebKit's own media-controls initialization. Restore the
    // attribute at each mutation microtask instead.
    function guardNativeControls(video) {
        if (!video || video._wblockControlsGuarded) return;
        video._wblockControlsGuarded = true;

        function restore() { restoreNativeMediaCapabilities(video); }

        var observer = null;
        try {
            observer = new MutationObserver(restore);
            observer.observe(video, {
                attributes: true,
                attributeFilter: [
                    'controls', 'controlslist', 'disablepictureinpicture',
                    'disableremoteplayback', 'playsinline',
                    'webkit-playsinline', 'x-webkit-airplay'
                ]
            });
        } catch (e) { /* ignore */ }

        restore();

        registerCleanup(function () {
            if (observer) { try { observer.disconnect(); } catch (e) { /* ignore */ } }
        });
    }

    // The observer restore above is not enough for native scrubber drags.
    // YouTube's activity handlers listen in the capture phase on the document
    // and player ancestors, so they run before the video's bubble-phase
    // blockers no matter what, and they respond to the pointer stream by
    // clearing the controls attribute. The restore re-adds it a microtask
    // later, but WebKit has already torn down and rebuilt the inline shadow
    // controls, cancelling the drag after a few pixels (0.1.13 shipped only
    // bubble-phase blockers, which is why drags still died outside
    // fullscreen). Stop the teardown at the source instead: while Tube
    // Cleaner owns the video, writes that would turn the controls attribute
    // off are ignored. Shadowing is installed only after the attribute is
    // natively set, so WebKit's media-controls initialization is unaffected.
    function pinNativeControls(video) {
        if (!video || video._wblockControlsPinned) return;
        video._wblockControlsPinned = true;

        var nativeRemoveAttribute = video.removeAttribute;
        var nativeSetAttribute = video.setAttribute;
        var nativeToggleAttribute = video.toggleAttribute;

        function isControlsName(name) {
            return String(name).toLowerCase() === 'controls';
        }

        try {
            video.removeAttribute = function (name) {
                if (isControlsName(name)) return;
                return nativeRemoveAttribute.apply(this, arguments);
            };
            video.setAttribute = function (name) {
                // A redundant re-set still runs WebKit's attribute-changed
                // path; skip it so nothing rebuilds the shadow controls.
                if (isControlsName(name) && this.hasAttribute('controls')) return;
                return nativeSetAttribute.apply(this, arguments);
            };
            if (typeof nativeToggleAttribute === 'function') {
                video.toggleAttribute = function (name) {
                    if (isControlsName(name)) {
                        if (!this.hasAttribute('controls')) {
                            nativeSetAttribute.call(this, 'controls', '');
                        }
                        return true;
                    }
                    return nativeToggleAttribute.apply(this, arguments);
                };
            }
            // YouTube answers every PiP presentation change by exiting
            // fullscreen on the video (#919). After its swipe-down player that
            // tears PiP down, and with it background playback. Exiting
            // fullscreen never applies to a video that is in PiP.
            if (typeof video.webkitExitFullscreen === 'function') {
                video.webkitExitFullscreen = function () {
                    if (this.webkitPresentationMode === 'picture-in-picture') return;
                    return Object.getPrototypeOf(this).webkitExitFullscreen.apply(this, arguments);
                };
            }
            var descriptor = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, 'controls');
            if (descriptor && descriptor.get && descriptor.set) {
                Object.defineProperty(video, 'controls', {
                    configurable: true,
                    get: function () { return descriptor.get.call(this); },
                    set: function (value) {
                        // Property writes need the same no-op guard as setAttribute:
                        // reasserting true during a tap still mutates WebKit's controls.
                        if (value && !descriptor.get.call(this)) { descriptor.set.call(this, true); }
                    }
                });
            }
        } catch (e) { /* partial pin; the observer restore still applies */ }

        registerCleanup(function () {
            video._wblockControlsPinned = false;
            try { delete video.removeAttribute; } catch (e) { /* ignore */ }
            try { delete video.setAttribute; } catch (e) { /* ignore */ }
            try { delete video.toggleAttribute; } catch (e) { /* ignore */ }
            try { delete video.webkitExitFullscreen; } catch (e) { /* ignore */ }
            try { delete video.controls; } catch (e) { /* ignore */ }
        });
    }

    // Ensure inline playback on iOS/iPadOS. Without `playsinline`, iOS opens the
    // video in the fullscreen system player instead of playing inline. YouTube's
    // desktop player (served to iPadOS by default) may omit this attribute, and
    // since we reuse YouTube's <video> element we must set it ourselves.
    function ensurePlaysInline(video) {
        if (!video) return;
        try {
            if (!video.playsInline) { video.playsInline = true; }
            if (!video.hasAttribute('playsinline')) { video.setAttribute('playsinline', ''); }
            if (!video.hasAttribute('webkit-playsinline')) { video.setAttribute('webkit-playsinline', ''); }
        } catch (e) { /* ignore */ }
    }

    // ------------------------------------------------------------------
    // SponsorBlock
    //
    // Query SponsorBlock's k-anonymous endpoint with only five hexadecimal
    // characters of the video's SHA-256 hash. The exact YouTube id never leaves
    // the page; the returned bucket is filtered locally. Deliberately fetch all
    // supported categories once; defaults still enable only standard
    // sponsors so Tube Cleaner does not unexpectedly remove editorial content.
    // ------------------------------------------------------------------

    var SPONSORBLOCK_API = 'https://sponsor.ajay.app/api/skipSegments/';
    var SPONSORBLOCK_SETTINGS_KEY = 'wblock.tubeCleaner.sponsorBlock';
    var SPONSORBLOCK_CATEGORIES = [
        { id: 'sponsor', color: '#00d400' },
        { id: 'selfpromo', color: '#ffff00' },
        { id: 'interaction', color: '#cc00ff' },
        { id: 'intro', color: '#00ffff' },
        { id: 'outro', color: '#0202ed' },
        { id: 'preview', color: '#008fd6' },
        { id: 'filler', color: '#7300ff' },
        { id: 'music_offtopic', color: '#ff9900' }
    ];
    var sponsorBlockDisabledVideos = {};
    var sponsorBlockSettingsCache = null;
    // YouTube keeps the page alive across navigations. Retain a small resolved
    // segment cache for that session so revisiting a video does not query the
    // same hash bucket again. Empty results are cached too.
    var sponsorBlockSegmentCache = {};
    var sponsorBlockSegmentCacheOrder = [];

    function cachedSponsorBlockSegments(videoId) {
        return Object.prototype.hasOwnProperty.call(sponsorBlockSegmentCache, videoId) ?
            sponsorBlockSegmentCache[videoId] : null;
    }

    function cacheSponsorBlockSegments(videoId, segments) {
        if (!Object.prototype.hasOwnProperty.call(sponsorBlockSegmentCache, videoId)) {
            sponsorBlockSegmentCacheOrder.push(videoId);
        }
        sponsorBlockSegmentCache[videoId] = segments;
        while (sponsorBlockSegmentCacheOrder.length > 24) {
            delete sponsorBlockSegmentCache[sponsorBlockSegmentCacheOrder.shift()];
        }
    }

    function sponsorBlockLocale() {
        var language = (navigator.language || 'en').toLowerCase().split('-')[0];
        var english = {
            title: 'SponsorBlock settings', enabled: 'Enable SponsorBlock', notice: 'Show Undo after automatic skips',
            duration: 'Minimum segment length', current: 'Disable for this video', channel: 'Disable on this channel', reset: 'Reset defaults',
            using: 'About SponsorBlock', donate: 'Donate', close: 'Close',
            hideControls: 'Hide these controls (double-tap the video to show them)',
            any: 'Any length', auto: 'Auto skip', ask: 'Show skip button', off: 'Disabled',
            skipped: 'segment skipped', segment: 'segment', undo: 'Undo', skip: 'Skip',
            names: ['Sponsor', 'Self-promotion', 'Interaction reminder', 'Intro', 'Outro', 'Preview or recap', 'Filler', 'Off-topic music']
        };
        var translations = {
            de: { title:'SponsorBlock-Einstellungen',enabled:'SponsorBlock aktivieren',notice:'Rückgängig nach automatischem Überspringen anzeigen',duration:'Mindestlänge',current:'Für dieses Video deaktivieren',reset:'Zurücksetzen',any:'Beliebige Länge',auto:'Automatisch',ask:'Schaltfläche anzeigen',off:'Deaktiviert',skipped:'übersprungen',segment:'Segment',undo:'Rückgängig',skip:'Überspringen',names:['Sponsor','Eigenwerbung','Interaktionserinnerung','Intro','Outro','Vorschau oder Rückblick','Füllmaterial','Themenfremde Musik'] },
            es: { title:'Ajustes de SponsorBlock',enabled:'Activar SponsorBlock',notice:'Mostrar Deshacer tras saltos automáticos',duration:'Duración mínima',current:'Desactivar para este vídeo',reset:'Restablecer',any:'Cualquier duración',auto:'Saltar automáticamente',ask:'Mostrar botón',off:'Desactivado',skipped:'omitido',segment:'segmento',undo:'Deshacer',skip:'Saltar',names:['Patrocinio','Autopromoción','Recordatorio de interacción','Introducción','Cierre','Avance o resumen','Relleno','Música no relacionada'] },
            fr: { title:'Réglages SponsorBlock',enabled:'Activer SponsorBlock',notice:'Afficher Annuler après les sauts automatiques',duration:'Durée minimale',current:'Désactiver pour cette vidéo',reset:'Réinitialiser',any:'Toute durée',auto:'Ignorer automatiquement',ask:'Afficher le bouton',off:'Désactivé',skipped:'ignoré',segment:'segment',undo:'Annuler',skip:'Ignorer',names:['Sponsor','Autopromotion','Rappel d’interaction','Introduction','Conclusion','Aperçu ou résumé','Remplissage','Musique hors sujet'] },
            it: { title:'Impostazioni SponsorBlock',enabled:'Attiva SponsorBlock',notice:'Mostra Annulla dopo i salti automatici',duration:'Durata minima',current:'Disattiva per questo video',reset:'Ripristina',any:'Qualsiasi durata',auto:'Salta automaticamente',ask:'Mostra pulsante',off:'Disattivato',skipped:'saltato',segment:'segmento',undo:'Annulla',skip:'Salta',names:['Sponsor','Autopromozione','Promemoria interazione','Introduzione','Finale','Anteprima o riepilogo','Riempitivo','Musica fuori tema'] },
            pt: { title:'Configurações do SponsorBlock',enabled:'Ativar SponsorBlock',notice:'Mostrar Desfazer após pulos automáticos',duration:'Duração mínima',current:'Desativar para este vídeo',reset:'Restaurar padrões',any:'Qualquer duração',auto:'Pular automaticamente',ask:'Mostrar botão',off:'Desativado',skipped:'ignorado',segment:'segmento',undo:'Desfazer',skip:'Pular',names:['Patrocínio','Autopromoção','Lembrete de interação','Introdução','Encerramento','Prévia ou resumo','Enchimento','Música fora do tema'] },
            ja: { title:'SponsorBlock設定',enabled:'SponsorBlockを有効にする',notice:'自動スキップ後に元に戻すを表示',duration:'最小セグメント長',current:'この動画では無効にする',reset:'初期設定に戻す',any:'すべての長さ',auto:'自動スキップ',ask:'スキップボタンを表示',off:'無効',skipped:'をスキップしました',segment:'セグメント',undo:'元に戻す',skip:'スキップ',names:['スポンサー','自己宣伝','操作のお願い','イントロ','アウトロ','予告・あらすじ','フィラー','無関係な音楽'] },
            ko: { title:'SponsorBlock 설정',enabled:'SponsorBlock 활성화',notice:'자동 건너뛰기 후 실행 취소 표시',duration:'최소 구간 길이',current:'이 동영상에서 비활성화',reset:'기본값 복원',any:'모든 길이',auto:'자동 건너뛰기',ask:'건너뛰기 버튼 표시',off:'비활성화',skipped:'건너뜀',segment:'구간',undo:'실행 취소',skip:'건너뛰기',names:['스폰서','자기 홍보','상호작용 알림','인트로','아웃트로','미리보기 또는 요약','필러','주제와 무관한 음악'] },
            ru: { title:'Настройки SponsorBlock',enabled:'Включить SponsorBlock',notice:'Показывать отмену после автопропуска',duration:'Минимальная длина',current:'Отключить для этого видео',reset:'Сбросить',any:'Любая длина',auto:'Пропускать автоматически',ask:'Показывать кнопку',off:'Отключено',skipped:'пропущен',segment:'фрагмент',undo:'Отменить',skip:'Пропустить',names:['Спонсор','Самореклама','Напоминание о взаимодействии','Вступление','Концовка','Анонс или обзор','Заполнитель','Музыка не по теме'] },
            zh: { title:'SponsorBlock 设置',enabled:'启用 SponsorBlock',notice:'自动跳过后显示撤销',duration:'最短片段长度',current:'对这个视频停用',reset:'恢复默认设置',any:'任意长度',auto:'自动跳过',ask:'显示跳过按钮',off:'已停用',skipped:'已跳过',segment:'片段',undo:'撤销',skip:'跳过',names:['赞助内容','自我推广','互动提醒','片头','片尾','预告或回顾','填充内容','无关音乐'] }
        };
        var selected = translations[language] || english;
        var channelLabels = { de:'Auf diesem Kanal deaktivieren', es:'Desactivar en este canal',
            fr:'Désactiver sur cette chaîne', it:'Disattiva su questo canale', pt:'Desativar neste canal',
            ja:'このチャンネルでは無効にする', ko:'이 채널에서 비활성화', ru:'Отключить на этом канале', zh:'对这个频道停用' };
        var usingLabels = { de:'Über SponsorBlock', es:'Acerca de SponsorBlock', fr:'À propos de SponsorBlock',
            it:'Informazioni su SponsorBlock', pt:'Sobre o SponsorBlock', ja:'SponsorBlockについて', ko:'SponsorBlock 정보',
            ru:'О SponsorBlock', zh:'关于 SponsorBlock' };
        if (!selected.channel) selected.channel = channelLabels[language] || english.channel;
        var donateLabels = { de:'Spenden', es:'Donar', fr:'Faire un don', it:'Dona', pt:'Doar', ja:'寄付', ko:'기부',
            ru:'Поддержать', zh:'捐款' };
        if (!selected.using) selected.using = usingLabels[language] || english.using;
        if (!selected.donate) selected.donate = donateLabels[language] || english.donate;
        var closeLabels = { de:'Schließen', es:'Cerrar', fr:'Fermer', it:'Chiudi', pt:'Fechar', ja:'閉じる', ko:'닫기',
            ru:'Закрыть', zh:'关闭' };
        if (!selected.close) selected.close = closeLabels[language] || english.close;
        var hideControlsLabels = { de:'Diese Steuerelemente ausblenden (Doppeltippen auf das Video zeigt sie)',
            es:'Ocultar estos controles (toca dos veces el vídeo para mostrarlos)',
            fr:'Masquer ces commandes (touchez deux fois la vidéo pour les afficher)',
            it:'Nascondi questi controlli (tocca due volte il video per mostrarli)',
            pt:'Ocultar estes controles (toque duas vezes no vídeo para mostrá-los)',
            ja:'このコントロールを非表示（動画をダブルタップで表示）', ko:'이 컨트롤 숨기기(동영상을 두 번 탭하면 표시)',
            ru:'Скрыть эти элементы управления (двойное нажатие по видео покажет их)', zh:'隐藏这些控件（双击视频可显示）' };
        if (!selected.hideControls) selected.hideControls = hideControlsLabels[language] || english.hideControls;
        return selected;
    }

    function defaultSponsorBlockSettings() {
        var modes = {};
        for (var i = 0; i < SPONSORBLOCK_CATEGORIES.length; i++) modes[SPONSORBLOCK_CATEGORIES[i].id] = 'off';
        modes.sponsor = 'auto';
        return { enabled: true, showNotice: true, minimumDuration: 0, modes: modes, excludedChannels: [] };
    }

    function loadSponsorBlockSettings() {
        if (sponsorBlockSettingsCache) return sponsorBlockSettingsCache;
        var settings = defaultSponsorBlockSettings();
        var shared = null;
        try {
            if (typeof GM_getValue === 'function') shared = GM_getValue(SPONSORBLOCK_SETTINGS_KEY, null);
        } catch (e) { /* use local preferences outside wBlock */ }
        try {
            // The native importer writes only this allowlisted settings object.
            // A native snapshot wins over stale, origin-local preferences.
            var saved = shared || JSON.parse(localStorage.getItem(SPONSORBLOCK_SETTINGS_KEY) || '{}');
            if (typeof saved.enabled === 'boolean') settings.enabled = saved.enabled;
            if (typeof saved.showNotice === 'boolean') settings.showNotice = saved.showNotice;
            if (isFinite(saved.minimumDuration)) settings.minimumDuration = Math.max(0, Number(saved.minimumDuration));
            if (Array.isArray(saved.excludedChannels)) settings.excludedChannels = saved.excludedChannels.filter(function (id) {
                return typeof id === 'string' && id.length < 200;
            }).slice(0, 200);
            if (saved.modes) for (var id in settings.modes) {
                if (saved.modes[id] === 'auto' || saved.modes[id] === 'ask' || saved.modes[id] === 'off') settings.modes[id] = saved.modes[id];
            }
        } catch (e) { /* use defaults */ }
        sponsorBlockSettingsCache = settings;
        if (!shared) persistSharedSponsorBlockSettings(settings);
        return settings;
    }

    function persistSharedSponsorBlockSettings(settings) {
        // GM storage crosses the authenticated userscript bridge. Do not send
        // arbitrary localStorage or an upstream SponsorBlock export to native.
        if (typeof GM_setValue !== 'function') return;
        try { GM_setValue(SPONSORBLOCK_SETTINGS_KEY, settings); }
        catch (e) { /* local playback settings still work without the bridge */ }
    }

    function saveSponsorBlockSettings(settings) {
        sponsorBlockSettingsCache = settings;
        storageSet(SPONSORBLOCK_SETTINGS_KEY, JSON.stringify(settings));
        persistSharedSponsorBlockSettings(settings);
        document.dispatchEvent(new CustomEvent('wblock-tc-sponsor-settings'));
    }

    function sponsorBlockVideoId() {
        return youtubeVideoIdentity(findPlayer());
    }

    function sponsorBlockChannelId() {
        try {
            var details = window.ytInitialPlayerResponse && window.ytInitialPlayerResponse.videoDetails;
            if (details && details.channelId) return details.channelId;
            var link = document.querySelector('#owner a[href*="/channel/"], #owner a[href^="/@"], ' +
                'ytd-channel-name a[href], ytm-slim-owner-renderer a[href]');
            if (link) return new URL(link.href, location.href).pathname;
        } catch (e) { /* ignore */ }
        return null;
    }

    function sponsorBlockChannelExcluded(settings) {
        var channelId = sponsorBlockChannelId();
        return !!(channelId && settings.excludedChannels.indexOf(channelId) !== -1);
    }

    function sponsorBlockCategoryName(category) {
        var locale = sponsorBlockLocale();
        for (var i = 0; i < SPONSORBLOCK_CATEGORIES.length; i++) {
            if (SPONSORBLOCK_CATEGORIES[i].id === category) return locale.names[i];
        }
        return category;
    }

    function showSponsorBlockNotice(player, video, segment, ignored, action) {
        var existing = player.querySelector('.wblock-tc-sponsor-notice');
        if (existing) existing.remove();
        var locale = sponsorBlockLocale();
        var notice = document.createElement('div');
        notice.className = 'wblock-tc-sponsor-notice';
        // Keep the toast translucent so it never blots out the content under
        // it; the blur keeps the label readable over bright video frames.
        var noticePad = IS_IOS ? '7px 10px' : '9px 12px';
        var noticeFont = IS_IOS ? '12px' : '13px';
        notice.style.cssText = 'position:absolute;right:16px;top:16px;z-index:2147483647;' +
            'display:flex;align-items:center;gap:10px;padding:' + noticePad + ';border-radius:9px;' +
            'background:rgba(20,20,20,.55);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);' +
            'color:#fff;font:' + noticeFont + ' -apple-system,BlinkMacSystemFont,sans-serif;' +
            'box-shadow:0 3px 14px rgba(0,0,0,.25);pointer-events:auto;transition:opacity .3s';
        var label = document.createElement('span');
        label.textContent = sponsorBlockCategoryName(segment.category) + ' ' +
            (action === 'undo' ? locale.skipped : locale.segment);
        var actionButton = document.createElement('button');
        actionButton.type = 'button';
        actionButton.textContent = action === 'undo' ? locale.undo : locale.skip;
        actionButton.style.cssText = 'border:0;background:transparent;color:#69a9ff;font:inherit;font-weight:600;' +
            'padding:2px;cursor:pointer';
        notice.appendChild(label);
        notice.appendChild(actionButton);
        player.appendChild(notice);
        var fadeTimer = setTimeout(function () { notice.style.opacity = '0'; }, 3700);
        var removeTimer = setTimeout(function () { if (notice.parentNode) notice.remove(); }, 4000);
        actionButton.addEventListener('click', function () {
            if (action === 'undo') {
                ignored[segment.UUID || segment.segment.join(':')] = true;
                try { video.currentTime = segment.segment[0] + 0.01; } catch (e) { /* ignore */ }
            } else {
                try { video.currentTime = segment.segment[1]; } catch (e) { /* ignore */ }
            }
            clearTimeout(fadeTimer);
            clearTimeout(removeTimer);
            notice.remove();
        });
        return function () { clearTimeout(fadeTimer); clearTimeout(removeTimer); if (notice.parentNode) notice.remove(); };
    }

    function setupSponsorBlock(player, video) {
        var videoId = sponsorBlockVideoId();
        if (!player || !video || !videoId || !window.crypto || !crypto.subtle || !window.fetch) return;
        var cancelled = false;
        var controller = null;
        var requested = false;
        var segments = [];
        var ignored = {};
        var notified = {};
        var removeNotice = null;
        var boundaryTimer = null;
        var boundaryKey = null;
        var timingSuspended = false;

        function clearBoundaryTimer() {
            if (boundaryTimer !== null) clearTimeout(boundaryTimer);
            boundaryTimer = null;
            boundaryKey = null;
        }

        function segmentState(item, settings) {
            var key = item.UUID || item.category + ':' + item.segment.join(':');
            var mode = settings.modes[item.category] || 'off';
            var eligible = mode !== 'off' && !ignored[key] &&
                (!item.actionType || item.actionType === 'skip') &&
                item.segment[1] - item.segment[0] >= settings.minimumDuration;
            return { key: key, mode: mode, eligible: eligible };
        }

        // Undo and ask-mode notification state lasts only until playback leaves
        // that segment. Staying inside after Undo remains protected, while a
        // later re-entry behaves like the first visit.
        function clearExitedSegmentState(now) {
            for (var i = 0; i < segments.length; i++) {
                var item = segments[i];
                if (now >= item.segment[0] && now < item.segment[1]) continue;
                var key = item.UUID || item.category + ':' + item.segment.join(':');
                delete ignored[key];
                delete notified[key];
            }
        }

        // Keep timeupdate as a throttling/background fallback, but normally arm
        // one timer for the next segment boundary. This avoids waiting up to a
        // full timeupdate interval before an automatic skip.
        function scheduleNextBoundary(settings, now, force) {
            if (cancelled || timingSuspended || video.seeking || video.paused || video.ended || !settings.enabled ||
                sponsorBlockDisabledVideos[videoId] || sponsorBlockChannelExcluded(settings)) {
                clearBoundaryTimer();
                return;
            }
            var next = null;
            var nextState = null;
            for (var i = 0; i < segments.length; i++) {
                var item = segments[i];
                var state = segmentState(item, settings);
                if (!state.eligible || state.mode === 'ask' && notified[state.key] || item.segment[0] <= now) continue;
                next = item;
                nextState = state;
                break;
            }
            if (!next) { clearBoundaryTimer(); return; }
            var key = nextState.key + '@' + next.segment[0] + ':' + video.playbackRate;
            if (!force && boundaryTimer !== null && boundaryKey === key) return;
            clearBoundaryTimer();
            boundaryKey = key;
            var rate = isFinite(video.playbackRate) && video.playbackRate > 0 ? video.playbackRate : 1;
            var delay = Math.max(0, (next.segment[0] - now) * 1000 / rate + 8);
            boundaryTimer = setTimeout(function () {
                boundaryTimer = null;
                boundaryKey = null;
                onTimeUpdate();
            }, Math.min(delay, 2147483647));
        }

        function onTimeUpdate(forceSchedule) {
            if (timingSuspended || video.seeking) { clearBoundaryTimer(); return; }
            var settings = loadSponsorBlockSettings();
            if (!settings.enabled || sponsorBlockDisabledVideos[videoId] || sponsorBlockChannelExcluded(settings)) {
                clearBoundaryTimer();
                return;
            }
            var now = video.currentTime;
            var duration = video.duration;
            var hasDuration = isFinite(duration) && duration > 0;
            // Once the media sits at its end, a segment whose SponsorBlock end
            // time overshoots the real duration would keep re-seeking the
            // element. YouTube treats any seek from its ended state as a
            // replay request, so that loop restarts the video.
            if (video.ended || (hasDuration && now >= duration - 0.05)) { clearBoundaryTimer(); return; }
            clearExitedSegmentState(now);
            for (var i = 0; i < segments.length; i++) {
                var item = segments[i];
                var state = segmentState(item, settings);
                if (!state.eligible) continue;
                if (now >= item.segment[0] && now < item.segment[1] - 0.05) {
                    if (state.mode === 'ask') {
                        if (!notified[state.key]) {
                            notified[state.key] = true;
                            if (removeNotice) removeNotice();
                            removeNotice = showSponsorBlockNotice(player, video, item, ignored, 'skip');
                        }
                        scheduleNextBoundary(settings, now, true);
                        return;
                    }
                    var target = item.segment[1];
                    // Seeking a Safari media element to its exact duration
                    // replays the video instead of ending it (the SponsorBlock
                    // extension works around the same WebKit behavior). Stop
                    // just short of the end so playback finishes on its own.
                    if (hasDuration && target >= duration - 0.001) target = video.loop ? 0 : Math.max(0, duration - 0.001);
                    try { video.currentTime = target; } catch (e) { return; }
                    if (settings.showNotice) {
                        if (removeNotice) removeNotice();
                        removeNotice = showSponsorBlockNotice(player, video, item, ignored, 'undo');
                    }
                    scheduleNextBoundary(settings, item.segment[1], true);
                    return;
                }
            }
            scheduleNextBoundary(settings, now, !!forceSchedule);
        }

        function acceptBucket(bucket) {
            var found = [];
            if (Array.isArray(bucket)) for (var i = 0; i < bucket.length; i++) {
                if (bucket[i].videoID === videoId && Array.isArray(bucket[i].segments)) {
                    found = bucket[i].segments.filter(function (item) {
                        return item && SPONSORBLOCK_CATEGORIES.some(function (category) { return category.id === item.category; }) &&
                            Array.isArray(item.segment) && isFinite(item.segment[0]) && isFinite(item.segment[1]) &&
                            item.segment[1] > item.segment[0];
                    }).sort(function (a, b) { return a.segment[0] - b.segment[0]; });
                    break;
                }
            }
            segments = found;
            cacheSponsorBlockSegments(videoId, found);
            onTimeUpdate(true);
        }

        function loadSegments() {
            var settings = loadSponsorBlockSettings();
            if (requested || cancelled || !settings.enabled || sponsorBlockDisabledVideos[videoId] ||
                sponsorBlockChannelExcluded(settings)) return;
            var cached = cachedSponsorBlockSegments(videoId);
            if (cached !== null) {
                requested = true;
                segments = cached;
                onTimeUpdate(true);
                return;
            }
            requested = true;
            controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
            crypto.subtle.digest('SHA-256', new TextEncoder().encode(videoId)).then(function (buffer) {
                var bytes = new Uint8Array(buffer);
                var hash = '';
                var categoryIds = SPONSORBLOCK_CATEGORIES.map(function (category) { return category.id; });
                for (var i = 0; i < bytes.length; i++) hash += ('0' + bytes[i].toString(16)).slice(-2);
                var query = '?categories=' + encodeURIComponent(JSON.stringify(categoryIds)) +
                    '&actionTypes=' + encodeURIComponent(JSON.stringify(['skip']));
                return fetch(SPONSORBLOCK_API + hash.slice(0, 5) + query,
                    controller ? { signal: controller.signal } : {});
            }).then(function (response) {
                if (!response.ok) return [];
                return response.json();
            }).then(function (bucket) {
                if (!cancelled) acceptBucket(bucket);
            }).catch(function (error) {
                if (!cancelled && (!error || error.name !== 'AbortError')) log('SponsorBlock unavailable', error);
            });
        }

        function onSettingsChange() {
            if (removeNotice) { removeNotice(); removeNotice = null; }
            loadSegments();
            onTimeUpdate(true);
        }
        function onTimeUpdateEvent() { onTimeUpdate(false); }
        function onPlaybackResumed() { timingSuspended = false; onTimeUpdate(true); }
        function onPlaybackTimingChange() { onTimeUpdate(true); }
        function suspendBoundaryTimer() { timingSuspended = true; clearBoundaryTimer(); }

        // iOS fullscreen fallback. Entering the native full-screen player can
        // stop dispatching timeupdate to the shared element (or leave the
        // boundary timer suspended after a waiting/seeking burst), so a segment
        // entered while full-screen plays through instead of skipping. A low-rate
        // poll re-checks the timeline whenever the element is advancing, and the
        // presentation/fullscreen transitions re-arm the boundary timer. The poll
        // never forces a skip while a seek or stall is in progress.
        var pollTimer = null;
        function pollBoundary() {
            if (cancelled || timingSuspended || video.seeking || video.paused || video.ended) { return; }
            onTimeUpdate(false);
        }
        function startPoll() {
            if (pollTimer !== null || !IS_IOS) { return; }
            pollTimer = setInterval(pollBoundary, 300);
        }
        function stopPoll() {
            if (pollTimer !== null) { clearInterval(pollTimer); pollTimer = null; }
        }
        function onFullscreenChange() {
            timingSuspended = false;
            onTimeUpdate(true);
            startPoll();
        }

        video.addEventListener('timeupdate', onTimeUpdateEvent);
        video.addEventListener('playing', onPlaybackResumed);
        video.addEventListener('seeked', onPlaybackResumed);
        video.addEventListener('ratechange', onPlaybackTimingChange);
        video.addEventListener('seeking', suspendBoundaryTimer);
        video.addEventListener('waiting', suspendBoundaryTimer);
        video.addEventListener('stalled', suspendBoundaryTimer);
        video.addEventListener('pause', clearBoundaryTimer);
        video.addEventListener('ended', clearBoundaryTimer);
        document.addEventListener('wblock-tc-sponsor-settings', onSettingsChange);
        if (IS_IOS) {
            video.addEventListener('webkitbeginfullscreen', onFullscreenChange);
            video.addEventListener('webkitendfullscreen', onFullscreenChange);
            document.addEventListener('fullscreenchange', onFullscreenChange);
            document.addEventListener('webkitfullscreenchange', onFullscreenChange);
            startPoll();
        }
        registerCleanup(function () {
            cancelled = true;
            clearBoundaryTimer();
            stopPoll();
            video.removeEventListener('timeupdate', onTimeUpdateEvent);
            video.removeEventListener('playing', onPlaybackResumed);
            video.removeEventListener('seeked', onPlaybackResumed);
            video.removeEventListener('ratechange', onPlaybackTimingChange);
            video.removeEventListener('seeking', suspendBoundaryTimer);
            video.removeEventListener('waiting', suspendBoundaryTimer);
            video.removeEventListener('stalled', suspendBoundaryTimer);
            video.removeEventListener('pause', clearBoundaryTimer);
            video.removeEventListener('ended', clearBoundaryTimer);
            document.removeEventListener('wblock-tc-sponsor-settings', onSettingsChange);
            if (IS_IOS) {
                video.removeEventListener('webkitbeginfullscreen', onFullscreenChange);
                video.removeEventListener('webkitendfullscreen', onFullscreenChange);
                document.removeEventListener('fullscreenchange', onFullscreenChange);
                document.removeEventListener('webkitfullscreenchange', onFullscreenChange);
            }
            if (controller) controller.abort();
            if (removeNotice) removeNotice();
        });
        loadSegments();
    }

    // ------------------------------------------------------------------
    // Per-feature switches the app prepends as __wblockTubeCleanerFeatures
    // (Userscripts page, Tube Cleaner row; wBlock #671). Everything except the
    // opt-in Shorts filter (#884) defaults to on so older wBlock builds, which
    // do not inject the constant, behave as before. Native controls and ad handling are not switchable: they are
    // what the script is for.
    var tubeCleanerFeatures = (function () {
        var features = {
            chapters: true,
            captions: true,
            pictureInPicture: true,
            backgroundPlayback: true,
            sponsorBlock: true,
            resumePosition: true,
            toolbar: true,
            hideShorts: false
        };
        var injected = typeof __wblockTubeCleanerFeatures === 'object' ? __wblockTubeCleanerFeatures : null;
        if (!injected) return features;
        for (var key in features) {
            if (typeof injected[key] === 'boolean') features[key] = injected[key];
        }
        return features;
    })();
    function featureEnabled(name) { return tubeCleanerFeatures[name] !== false; }


    // Chapters
    //
    // Safari's native chapter picker is filled from a <track kind="chapters">
    // element, the same way the CC menu is filled from subtitle tracks.
    // addTextTrack("chapters") creates a JavaScript TextTrack, but WebKit's
    // AVPlayer chapter menu does not enumerate those in-memory tracks. Read
    // YouTube's chapter list from ytInitialData / the player response, build a
    // WebVTT blob, and attach it as a real track element.
    // ------------------------------------------------------------------

    function collectChapterRenderers(node, out) {
        if (!node || typeof node !== 'object') return;
        var seen = typeof WeakSet === 'function' ? new WeakSet() : [];
        var stack = [node];
        while (stack.length) {
            var current = stack.pop();
            if (!current || typeof current !== 'object') continue;
            try {
                if (typeof WeakSet === 'function' && seen.add) {
                    if (seen.has(current)) continue;
                    seen.add(current);
                } else if (seen.indexOf(current) !== -1) {
                    continue;
                } else {
                    seen.push(current);
                }
            } catch (e) { continue; }
            if (Array.isArray(current)) {
                for (var i = 0; i < current.length; i++) stack.push(current[i]);
                continue;
            }
            try {
                if (current.macroMarkersListItemRenderer) out.push(current.macroMarkersListItemRenderer);
            } catch (e) { /* ignore a poisoned getter */ }
            try {
                if (current.chapterRenderer) out.push(current.chapterRenderer);
            } catch (e) { /* ignore a poisoned getter */ }
            try {
                var markersList = current.markersList;
                var markerType = markersList && String(markersList.markerType || '');
                if (markersList && markersList.markers &&
                    /CHAPTER|TIMESTAMP/i.test(markerType) && !/HEATMAP/i.test(markerType)) {
                    var entityId = current.externalVideoId || '';
                    var currentId = currentChapterVideoId();
                    var idMismatch = entityId && currentId &&
                        /^[A-Za-z0-9_-]{11}$/.test(currentId) && entityId !== currentId;
                    if (!idMismatch) {
                        var markers = markersList.markers;
                        for (var m = 0; m < markers.length; m++) {
                            if (markers[m]) { out.push(markers[m]); }
                        }
                    }
                }
            } catch (e) { /* ignore a poisoned getter */ }
            try {
                for (var key in current) {
                    if (Object.prototype.hasOwnProperty.call(current, key)) {
                        try { stack.push(current[key]); } catch (ignored) { /* skip throwing property */ }
                    }
                }
            } catch (e) { /* ignore */ }
        }
    }

    // Parse "0:00", "1:23", or "1:23:45" into seconds.
    function parseTimestamp(text) {
        if (!text) return null;
        var parts = String(text).trim().split(':');
        var seconds = 0;
        for (var i = 0; i < parts.length; i++) {
            var n = parseInt(parts[i], 10);
            if (isNaN(n)) return null;
            seconds = seconds * 60 + n;
        }
        return seconds;
    }

    // Format seconds as m:ss or h:mm:ss for the native chapter menu label.
    function formatTimestamp(sec) {
        sec = Math.max(0, Math.floor(sec));
        var h = Math.floor(sec / 3600);
        var m = Math.floor((sec % 3600) / 60);
        var s = sec % 60;
        var ss = s < 10 ? '0' + s : '' + s;
        if (h > 0) {
            var mm = m < 10 ? '0' + m : '' + m;
            return h + ':' + mm + ':' + ss;
        }
        return m + ':' + ss;
    }

    function chapterTitle(renderer) {
        try {
            var t = renderer.title;
            if (!t) return '';
            if (typeof t === 'string') return t;
            if (t.simpleText) return t.simpleText;
            if (t.runs && t.runs.length) {
                var s = '';
                for (var i = 0; i < t.runs.length; i++) { s += t.runs[i].text || ''; }
                return s;
            }
        } catch (e) { /* ignore */ }
        return '';
    }

    function chapterSourceVideoId(data) {
        try {
            var endpoint = data && data.currentVideoEndpoint;
            if (endpoint && endpoint.watchEndpoint) return endpoint.watchEndpoint.videoId || '';
        } catch (e) { /* try the player response */ }
        try { return data && data.videoDetails && data.videoDetails.videoId || ''; }
        catch (e) { return ''; }
    }

    // Initial globals keep the first watch page across SPA navigation. Prefer
    // the live watch response and reject payloads owned by a different video.
    function chapterDataSource() {
        var sources = [];
        try {
            var watch = document.querySelector('ytd-watch-flexy');
            if (watch && watch.data) sources.push({ data: watch.data, live: true });
        } catch (e) { /* ignore */ }
        try {
            var app = document.querySelector('ytd-app');
            if (app && app.data && app.data.response) sources.push({ data: app.data.response, live: true });
        } catch (e) { /* ignore */ }
        try {
            var player = findPlayer();
            if (player && typeof player.getPlayerResponse === 'function') {
                var response = player.getPlayerResponse();
                if (response) sources.push({ data: response });
            }
        } catch (e) { /* ignore */ }
        try { if (window.ytInitialData) sources.push({ data: window.ytInitialData }); } catch (e) { /* ignore */ }
        try { if (window.ytInitialPlayerResponse) sources.push({ data: window.ytInitialPlayerResponse }); } catch (e) { /* ignore */ }
        var videoId = currentChapterVideoId();
        var unverified = null;
        var emptyLive = null;
        for (var i = 0; i < sources.length; i++) {
            var source = sources[i].data;
            var owner = chapterSourceVideoId(source);
            if (owner && owner !== videoId) continue;
            if (extractChapters(source)) {
                if (owner === videoId) return source;
                if (!unverified) unverified = source;
            } else if (sources[i].live && owner === videoId) {
                emptyLive = source;
            }
        }
        // An identified, chapterless watch page must not inherit an unowned
        // initial payload. Unidentified legacy payloads retain the fingerprint guard.
        return emptyLive || unverified;
    }

    // Extract YouTube's chapters for the current video as a sorted list of
    // { start, title }. Returns null when the page exposes no chapters.
    function extractChapters(data) {
        data = data || chapterDataSource();
        if (!data) return null;
        var renderers = [];
        try { collectChapterRenderers(data, renderers); } catch (e) { return null; }
        if (!renderers.length) return null;

        var chapters = [];
        var seenKeys = {};
        for (var i = 0; i < renderers.length; i++) {
            var r = renderers[i];
            var title = chapterTitle(r);
            var start = null;
            if (typeof r.timeRangeStartMillis === 'number') {
                start = r.timeRangeStartMillis / 1000;
            } else if (r.startMillis !== undefined && r.startMillis !== null && r.startMillis !== '') {
                var millis = Number(r.startMillis);
                if (isFinite(millis)) { start = millis / 1000; }
            } else {
                try {
                    start = parseTimestamp(r.timeDescription && r.timeDescription.simpleText);
                } catch (e) { start = null; }
            }
            if (title && start !== null && start >= 0) {
                // YouTube mirrors the same chapter list in several places in
                // ytInitialData (the engagement panel, the player overlay, and
                // framework/entity updates). The walk therefore finds each
                // chapter more than once; collapse exact duplicates.
                var key = start + '|' + title;
                if (seenKeys[key]) continue;
                seenKeys[key] = true;
                chapters.push({ start: start, title: title });
            }
        }
        if (!chapters.length) return null;
        chapters.sort(function (a, b) { return a.start - b.start; });
        var normalized = [];
        for (var j = 0; j < chapters.length; j++) {
            if (!normalized.length || chapters[j].start > normalized[normalized.length - 1].start) {
                normalized.push(chapters[j]);
            }
        }
        return normalized;
    }

    function currentChapterVideoId() {
        return youtubeUrlVideoId() || youtubePlayerVideoId(findPlayer()) ||
            location.pathname + location.search;
    }

    function formatVttTimestamp(sec) {
        if (!isFinite(sec) || sec < 0) sec = 0;
        var msTotal = Math.round(sec * 1000);
        var hours = Math.floor(msTotal / 3600000);
        msTotal -= hours * 3600000;
        var minutes = Math.floor(msTotal / 60000);
        msTotal -= minutes * 60000;
        var seconds = Math.floor(msTotal / 1000);
        var millis = msTotal - seconds * 1000;
        function pad(n, width) {
            var s = String(n);
            while (s.length < width) s = '0' + s;
            return s;
        }
        return pad(hours, 2) + ':' + pad(minutes, 2) + ':' + pad(seconds, 2) + '.' + pad(millis, 3);
    }

    function vttCueText(text) {
        return String(text || '').replace(/[\r\n]+/g, ' ').replace(/-->/g, '->');
    }

    function chaptersToWebVtt(chapters, duration) {
        var lines = ['WEBVTT', ''];
        var added = 0;
        for (var i = 0; i < chapters.length; i++) {
            var start = chapters[i].start;
            var end;
            if (i + 1 < chapters.length) {
                end = chapters[i + 1].start;
            } else {
                // Last chapter runs to the end of the media. Before metadata is
                // loaded, use a one-second placeholder so the cue is still valid.
                end = duration !== null ? duration : start + 1;
            }
            if (duration !== null && start >= duration) continue;
            if (duration !== null) end = Math.min(end, duration);
            if (!(end > start)) continue;
            // The native chapter menu renders the cue text verbatim, so
            // prefix the title with its timestamp for an at-a-glance list.
            var label = formatTimestamp(start) + '  ' + vttCueText(chapters[i].title);
            lines.push(formatVttTimestamp(start) + ' --> ' + formatVttTimestamp(end));
            lines.push(label);
            lines.push('');
            added++;
        }
        return { vtt: lines.join('\n'), added: added };
    }

    function hideChapterTrack(element) {
        try {
            if (element && element.track) element.track.mode = 'hidden';
        } catch (e) { /* ignore */ }
    }

    function removeChapterTrack(video) {
        if (!video) return;
        var element = video._wblockChaptersElement;
        if (element) {
            if (element._wblockRevokeUrl) {
                try { URL.revokeObjectURL(element._wblockRevokeUrl); } catch (e) { /* ignore */ }
                element._wblockRevokeUrl = null;
            }
            if (element.parentNode) {
                try { element.remove(); } catch (e) { /* ignore */ }
            }
        }
        if (video._wblockChaptersBlobUrl) {
            try { URL.revokeObjectURL(video._wblockChaptersBlobUrl); } catch (e) { /* ignore */ }
        }
        video._wblockChaptersElement = null;
        video._wblockChaptersBlobUrl = null;
        video._wblockChaptersTrack = null;
        video._wblockChapterApplyKey = null;
        video._wblockChapterDuration = null;
    }

    function hideAndRevokeChapterTrack(element) {
        hideChapterTrack(element);
        var stale = element && element._wblockRevokeUrl;
        if (element) element._wblockRevokeUrl = null;
        if (stale) {
            try { URL.revokeObjectURL(stale); } catch (e) { /* ignore */ }
        }
    }

    function installChapterTrack(video, vtt) {
        if (!window.Blob || !URL.createObjectURL) {
            warn('chapter track blobs unavailable');
            return false;
        }
        var blobUrl;
        try {
            blobUrl = URL.createObjectURL(new Blob([vtt], { type: 'text/vtt' }));
        } catch (e) {
            warn('chapter blob URL failed', e);
            return false;
        }
        var element = video._wblockChaptersElement;
        var previousUrl = video._wblockChaptersBlobUrl;
        if (!element || !element.isConnected) {
            element = document.createElement('track');
            element.kind = 'chapters';
            element.label = 'Chapters';
            element.srclang = 'en';
            element.default = true;
            element.setAttribute('data-wblock-native-chapters', '1');
            element.addEventListener('load', function () { hideAndRevokeChapterTrack(element); });
            try {
                video.appendChild(element);
            } catch (e) {
                try { URL.revokeObjectURL(blobUrl); } catch (ignored) { /* ignore */ }
                warn('chapter track attach failed', e);
                return false;
            }
            video._wblockChaptersElement = element;
        } else if (previousUrl) {
            element._wblockRevokeUrl = previousUrl;
        }
        element.src = blobUrl;
        hideChapterTrack(element);
        video._wblockChaptersBlobUrl = blobUrl;
        video._wblockChaptersTrack = element.track;
        return true;
    }

    // Mirror YouTube's chapters onto the native element as a chapters track.
    // YouTube may discard or replace ytInitialData after player startup, so a
    // successful extraction is cached on the video and reused by later media
    // events. Never erase working cues merely because a subsequent lookup is
    // temporarily empty; only clear them when the current video id changes.
    function applyChapters(video) {
        if (!video) return false;
        var videoId = currentChapterVideoId();
        var source = chapterDataSource();
        var chapters = extractChapters(source);
        var fingerprint = chapters ? JSON.stringify(chapters) : '[]';
        var sourceIsCurrentVideo = chapterSourceVideoId(source) === videoId;
        var sourceIsFromPreviousVideo = !sourceIsCurrentVideo && !!(chapters && chapters.length &&
            ((video._wblockChapterVideoId && video._wblockChapterVideoId !== videoId &&
                video._wblockChapterFingerprint === fingerprint) ||
             (video._wblockRejectedChapterFingerprint === fingerprint &&
                video._wblockRejectedChapterVideoId === videoId)));

        if (chapters && chapters.length && !sourceIsFromPreviousVideo) {
            video._wblockChapterData = chapters;
            video._wblockChapterVideoId = videoId;
            video._wblockChapterDataSource = source;
            video._wblockChapterFingerprint = fingerprint;
            video._wblockRejectedChapterFingerprint = null;
            video._wblockRejectedChapterVideoId = null;
        } else if (video._wblockChapterVideoId === videoId &&
            video._wblockChapterData && video._wblockChapterData.length) {
            chapters = video._wblockChapterData;
            fingerprint = video._wblockChapterFingerprint || JSON.stringify(chapters);
        } else {
            removeChapterTrack(video);
            video._wblockChapterData = null;
            video._wblockChapterVideoId = videoId;
            video._wblockChapterDataSource = source;
            video._wblockChapterFingerprint = fingerprint;
            if (sourceIsFromPreviousVideo) {
                video._wblockRejectedChapterFingerprint = fingerprint;
                video._wblockRejectedChapterVideoId = videoId;
            }
            return false;
        }

        var duration = (isFinite(video.duration) && video.duration > 0) ? video.duration : null;
        var applyKey = fingerprint + '|' + (duration === null ? '' : String(duration));
        if (video._wblockChaptersElement && video._wblockChaptersElement.isConnected &&
            video._wblockChapterApplyKey === applyKey) {
            hideChapterTrack(video._wblockChaptersElement);
            return true;
        }

        var built = chaptersToWebVtt(chapters, duration);
        if (!built.added) {
            removeChapterTrack(video);
            return false;
        }
        if (!installChapterTrack(video, built.vtt)) return false;
        video._wblockChapterApplyKey = applyKey;
        video._wblockChapterDuration = duration;
        log('applied', built.added, 'chapters');
        return true;
    }

    function setupChapters(player, video) {
        if (!video) return;
        var attempts = 0;
        var timer = null;

        function stopRetry() {
            if (timer !== null) {
                clearInterval(timer);
                timer = null;
            }
        }

        function refreshChapters() {
            if (applyChapters(video)) {
                stopRetry();
            } else if (timer === null) {
                // Data events can precede hydration on every navigation, not
                // just the first activation. Restart a bounded retry window.
                attempts = 0;
                timer = setInterval(function () {
                    attempts++;
                    if (applyChapters(video) || attempts >= 40) stopRetry();
                }, 250);
            }
        }

        video.addEventListener('loadedmetadata', refreshChapters);
        video.addEventListener('durationchange', refreshChapters);
        document.addEventListener('yt-page-data-updated', refreshChapters, true);
        document.addEventListener('yt-navigate-finish', refreshChapters, true);
        refreshChapters();

        registerCleanup(function () {
            video.removeEventListener('loadedmetadata', refreshChapters);
            video.removeEventListener('durationchange', refreshChapters);
            document.removeEventListener('yt-page-data-updated', refreshChapters, true);
            document.removeEventListener('yt-navigate-finish', refreshChapters, true);
            stopRetry();
            removeChapterTrack(video);
        });
    }

    // ------------------------------------------------------------------
    // Native subtitles
    //
    // Safari exposes <track kind="subtitles"> entries in its native language
    // menu. YouTube publishes signed timed-text URLs in the player response, so
    // convert the usable WebVTT responses to blob-backed tracks without adding
    // another custom control. Some WEB caption URLs now require a Proof-of-
    // Origin token and return an empty HTTP 200; for those, request caption
    // metadata through YouTube's token-free Android VR client first.
    // ------------------------------------------------------------------

    function youtubeText(value) {
        if (!value) return '';
        if (value.simpleText) return value.simpleText;
        if (value.runs && value.runs.length) {
            var text = '';
            for (var i = 0; i < value.runs.length; i++) text += value.runs[i].text || '';
            return text;
        }
        return '';
    }

    function captionTracksFromResponse(response) {
        try {
            var renderer = response && response.captions && response.captions.playerCaptionsTracklistRenderer;
            return renderer && Array.isArray(renderer.captionTracks) ? renderer.captionTracks.slice(0, 24) : [];
        } catch (e) { return []; }
    }

    function currentCaptionTracks(player) {
        var response = null;
        try {
            if (player && typeof player.getPlayerResponse === 'function') response = player.getPlayerResponse();
        } catch (e) { /* fall back */ }
        var tracks = captionTracksFromResponse(response);
        if (!tracks.length) tracks = captionTracksFromResponse(window.ytInitialPlayerResponse);
        return tracks;
    }

    function youtubeConfigValue(key) {
        try {
            if (window.ytcfg && typeof window.ytcfg.get === 'function') {
                var value = window.ytcfg.get(key);
                if (value !== undefined && value !== null) return value;
            }
            if (window.ytcfg && window.ytcfg.data_ && window.ytcfg.data_[key] !== undefined) {
                return window.ytcfg.data_[key];
            }
        } catch (e) { /* ignore */ }
        return null;
    }

    function nativeSubtitleVideoId(player) {
        var id = sponsorBlockVideoId();
        if (id) return id;
        try {
            var data = player && typeof player.getVideoData === 'function' ? player.getVideoData() : null;
            if (data && data.video_id) return String(data.video_id);
        } catch (e) { /* ignore */ }
        return null;
    }

    function captionUrl(track) {
        if (!track || !track.baseUrl) return null;
        try {
            var url = new URL(track.baseUrl, location.href);
            url.searchParams.set('fmt', 'vtt');
            return url.href;
        } catch (e) { return null; }
    }

    function captionsNeedAlternateClient(tracks) {
        for (var i = 0; i < tracks.length; i++) {
            try {
                var url = new URL(tracks[i].baseUrl, location.href);
                if (url.searchParams.get('exp') === 'xpe' && !url.searchParams.get('pot')) return true;
            } catch (e) { /* try the normal URL */ }
        }
        return false;
    }

    function alternateCaptionTracks(videoId, signal) {
        var apiKey = youtubeConfigValue('INNERTUBE_API_KEY');
        if (!apiKey || !videoId) return Promise.resolve([]);
        var visitorData = youtubeConfigValue('VISITOR_DATA');
        if (!visitorData) {
            var context = youtubeConfigValue('INNERTUBE_CONTEXT');
            visitorData = context && context.client && context.client.visitorData;
        }
        var client = {
            clientName: 'ANDROID_VR', clientVersion: '1.65.10', deviceMake: 'Oculus', deviceModel: 'Quest 3',
            androidSdkVersion: 32, osName: 'Android', osVersion: '12L',
            userAgent: 'com.google.android.apps.youtube.vr.oculus/1.65.10 (Linux; U; Android 12L) gzip'
        };
        if (visitorData) client.visitorData = visitorData;
        var headers = {
            'Content-Type': 'application/json',
            'X-YouTube-Client-Name': '28',
            'X-YouTube-Client-Version': client.clientVersion
        };
        if (visitorData) headers['X-Goog-Visitor-Id'] = visitorData;
        return fetch('/youtubei/v1/player?key=' + encodeURIComponent(apiKey) + '&prettyPrint=false', {
            method: 'POST', credentials: 'same-origin', signal: signal,
            headers: headers,
            body: JSON.stringify({
                context: { client: client }, videoId: videoId,
                contentCheckOk: true, racyCheckOk: true
            })
        }).then(function (response) {
            if (!response.ok) return null;
            return response.json();
        }).then(captionTracksFromResponse).catch(function () { return []; });
    }

    // YouTube's auto-generated tracks tag every cue with "align:start
    // position:0%", which its own renderer ignores but Safari honours, so the
    // text hugs the bottom-left corner. Drop the cue settings so the native
    // renderer centres each cue like the manual tracks.
    function normalizeCaptionVtt(text) {
        return text.replace(/^(\d{1,2}:\d{2}:\d{2}\.\d{3}\s+-->\s+\d{1,2}:\d{2}:\d{2}\.\d{3})[ \t][^\r\n]*/gm, '$1');
    }

    function downloadNativeSubtitleTracks(tracks, signal) {
        return Promise.all(tracks.map(function (track) {
            var url = captionUrl(track);
            if (!url) return Promise.resolve(null);
            return fetch(url, { credentials: 'same-origin', signal: signal }).then(function (response) {
                if (!response.ok) return '';
                return response.text();
            }).then(function (text) {
                text = String(text || '').replace(/^\uFEFF/, '');
                if (text.slice(0, 6) !== 'WEBVTT' || text.indexOf('-->') === -1 || text.length > 5000000) return null;
                return { definition: track, vtt: normalizeCaptionVtt(text) };
            }).catch(function () { return null; });
        })).then(function (results) {
            return results.filter(function (result) { return !!result; });
        });
    }

    // Diagnostic counter for the PiP caption pump below.
    var pipCaptionPumpTicks = 0;

    function setupNativeSubtitles(player, video) {
        if (!player || !video || !window.fetch || !window.Blob || !URL.createObjectURL) return;
        var cancelled = false;
        var controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
        var retryTimer = null;
        var attempts = 0;
        var started = false;
        var elements = [];
        var blobUrls = [];
        var subtitleApplying = false;

        function matchingNativeSubtitleTrack(preference) {
            var tracks = nativeSubtitleTracks(video);
            if (!tracks.length) return null;
            if (preference && preference.language) {
                var wanted = String(preference.language).toLowerCase();
                for (var i = 0; i < tracks.length; i++) {
                    var language = String(tracks[i].language || '').toLowerCase();
                    if (language === wanted) return tracks[i];
                }
            }
            if (preference && preference.label) {
                var label = String(preference.label).toLowerCase();
                for (var j = 0; j < tracks.length; j++) {
                    if (String(tracks[j].label || '').toLowerCase() === label) return tracks[j];
                }
            }
            return preferredSubtitleTrack(tracks);
        }

        function setNativeSubtitleMode(pick) {
            subtitleApplying = true;
            var tracks = nativeSubtitleTracks(video);
            for (var i = 0; i < tracks.length; i++) {
                try { tracks[i].mode = tracks[i] === pick ? 'showing' : 'disabled'; } catch (e) { /* ignore */ }
            }
            showingBefore = pick ? [pick] : [];
            setTimeout(function () { subtitleApplying = false; }, 0);
        }

        function youtubeCaptionLanguage() {
            try {
                var option = player && typeof player.getOption === 'function' ? player.getOption('captions', 'track') : null;
                return option && (option.languageCode || option.language || option.vssId || option.name) || '';
            } catch (e) { return ''; }
        }

        function youtubeSubtitlesOn() {
            try { if (player && typeof player.isSubtitlesOn === 'function' && player.isSubtitlesOn()) return true; }
            catch (e) { /* ignore */ }
            return !!youtubeCaptionLanguage();
        }

        function disableYouTubeSubtitles() {
            try {
                if (player && typeof player.setOption === 'function') { player.setOption('captions', 'track', null); }
            } catch (e) { /* ignore */ }
            try {
                if (player && typeof player.unloadModule === 'function') { player.unloadModule('captions'); }
            } catch (e) { /* ignore */ }
        }

        function applyNativeSubtitlePreference() {
            var preference = getSubtitlePreference();
            if (preference && preference.enabled === false) {
                setNativeSubtitleMode(null);
                disableYouTubeSubtitles();
                return;
            }
            var shouldShow = preference && preference.enabled === true || !preference && youtubeSubtitlesOn();
            if (!shouldShow) return;
            var pick = matchingNativeSubtitleTrack(preference || { language: youtubeCaptionLanguage() });
            if (pick) {
                setNativeSubtitleMode(pick);
                disableYouTubeSubtitles();
            }
        }

        // Safari's CC menu only lists real subtitle tracks. YouTube's caption
        // overlay sits under the native <video>, so clicking its hidden CC
        // button cannot show text. Install downloaded WebVTT and let Safari
        // toggle it. Videos with no usable captions get no tracks at all.
        function stopRetry() {
            if (retryTimer !== null) clearInterval(retryTimer);
            retryTimer = null;
        }

        function install(downloads) {
            if (cancelled || !downloads.length) return;
            var seen = {};
            for (var i = 0; i < downloads.length; i++) {
                var definition = downloads[i].definition;
                var language = definition.languageCode || '';
                var label = youtubeText(definition.name) || language || 'CC';
                var key = definition.vssId || language + '|' + label;
                if (seen[key]) continue;
                seen[key] = true;
                try {
                    var blobUrl = URL.createObjectURL(new Blob([downloads[i].vtt], { type: 'text/vtt' }));
                    var element = document.createElement('track');
                    element.kind = 'subtitles';
                    element.label = label;
                    element.srclang = language;
                    element.src = blobUrl;
                    element.setAttribute('data-wblock-native-subtitle', key);
                    video.appendChild(element);
                    elements.push(element);
                    blobUrls.push(blobUrl);
                } catch (e) { /* skip one malformed track */ }
            }
            if (elements.length) {
                log('applied', elements.length, 'Safari caption tracks');
                applyNativeSubtitlePreference();
                setTimeout(applyNativeSubtitlePreference, 0);
                setTimeout(applyNativeSubtitlePreference, 500);
            }
        }

        function loadTracks(tracks) {
            var signal = controller ? controller.signal : undefined;
            var videoId = nativeSubtitleVideoId(player);
            var useAlternateFirst = captionsNeedAlternateClient(tracks);
            var candidates = useAlternateFirst ? alternateCaptionTracks(videoId, signal) : Promise.resolve(tracks);
            candidates.then(function (candidateTracks) {
                if (cancelled) return [];
                return downloadNativeSubtitleTracks(candidateTracks.length ? candidateTracks : tracks, signal);
            }).then(function (downloads) {
                if (cancelled || downloads.length || useAlternateFirst) return downloads;
                return alternateCaptionTracks(videoId, signal).then(function (alternate) {
                    return downloadNativeSubtitleTracks(alternate, signal);
                });
            }).then(function (downloads) {
                if (!cancelled && downloads) install(downloads);
            }).catch(function (error) {
                if (!cancelled && (!error || error.name !== 'AbortError')) log('native subtitles unavailable', error);
            });
        }

        function tryStart() {
            if (started || cancelled) return;
            var tracks = currentCaptionTracks(player);
            if (!tracks.length) return;
            started = true;
            stopRetry();
            loadTracks(tracks);
        }

        tryStart();
        if (!started) {
            retryTimer = setInterval(function () {
                attempts++;
                tryStart();
                if (attempts >= 10) stopRetry();
            }, 500);
        }

        // WebKit repaints native VTT cues into the PiP overlay during the
        // page's rendering updates. A genuinely hidden tab stops those
        // updates, so the PiP window keeps showing the last painted line even
        // though playback and cue timing continue. The media element still
        // fires timeupdate and cuechange while hidden; watch for cue
        // boundaries there and cycle the showing track's mode, which makes
        // WebKit resolve and paint the current cue again. The two halves of
        // the cycle run in separate tasks: a same-task hidden/showing flip
        // coalesces into a no-op configuration change and repaints nothing.
        // A low-rate interval backs up the events in case the throttled
        // background page delivers them late. Cycling only at boundaries
        // keeps the foreground path untouched and avoids flicker.
        var pipCueSignature = null;
        var pipPumpRestorePending = false;
        var pipPumpRestoreTimer = null;
        var pipPumpInterval = null;
        function restoreTrackMode(track) {
            if (!pipPumpRestorePending) return;
            pipPumpRestorePending = false;
            if (pipPumpRestoreTimer !== null) { clearTimeout(pipPumpRestoreTimer); pipPumpRestoreTimer = null; }
            if (cancelled) return;
            try { if (track.mode === 'hidden') track.mode = 'showing'; } catch (e) { /* ignore */ }
            setTimeout(function () { subtitleApplying = false; }, 0);
            // Force the layout that WebKit's PiP caption image is painted from.
            try { void video.offsetWidth; } catch (e) { /* ignore */ }
        }
        function cycleTrackMode(track) {
            if (pipPumpRestorePending) return;
            pipPumpRestorePending = true;
            subtitleApplying = true;
            track.mode = 'hidden';
            pipCaptionPumpTicks++;
            // A hidden macOS tab aligns timers to whole seconds or longer, so
            // a setTimeout restore can leave the track hidden for a long
            // time. Message events are ordinary tasks and are not throttled;
            // the timer only backs them up.
            try {
                if (typeof MessageChannel === 'function') {
                    var channel = new MessageChannel();
                    channel.port1.onmessage = function () {
                        try { channel.port1.close(); } catch (e) { /* ignore */ }
                        restoreTrackMode(track);
                    };
                    channel.port2.postMessage(0);
                }
            } catch (e) { /* fall through to the timer */ }
            pipPumpRestoreTimer = setTimeout(function () {
                pipPumpRestoreTimer = null;
                restoreTrackMode(track);
            }, 0);
        }
        // Safari's track menu and the C shortcut both pick tracks; if two
        // subtitle tracks end up showing at once the text renders twice.
        // Keep only the most recently enabled one.
        var showingBefore = [];
        function enforceSingleSubtitleTrack() {
            var showing = nativeSubtitleTracks(video).filter(function (track) { return track.mode === 'showing'; });
            if (showing.length > 1) {
                var keep = null;
                for (var i = 0; i < showing.length; i++) {
                    if (showingBefore.indexOf(showing[i]) === -1) { keep = showing[i]; break; }
                }
                if (!keep) keep = showing[showing.length - 1];
                for (var j = 0; j < showing.length; j++) {
                    if (showing[j] !== keep) { try { showing[j].mode = 'disabled'; } catch (e) { /* ignore */ } }
                }
                showing = [keep];
            }
            showingBefore = showing;
        }
        function onNativeSubtitleChange() {
            if (subtitleApplying) return;
            enforceSingleSubtitleTrack();
            var showing = nativeSubtitleTracks(video).filter(function (track) { return track.mode === 'showing'; });
            if (showing.length) {
                setSubtitlePreference({ enabled: true, language: showing[0].language || '', label: showing[0].label || '' });
                video._wblockLastSubtitleTrack = showing[0];
            } else {
                setSubtitlePreference({ enabled: false });
            }
            disableYouTubeSubtitles();
        }
        function activeCueSignature(track, time) {
            var cues = track.cues;
            if (!cues) return '';
            var signature = '';
            for (var i = 0; i < cues.length; i++) {
                if (cues[i].startTime <= time && time < cues[i].endTime) {
                    signature += cues[i].startTime + '-' + cues[i].endTime + ';';
                }
            }
            return signature;
        }
        function onPiPCaptionTick() {
            var forced = !!window.__wblockTCForcePiPCaptionPump;
            if (!forced && (!_realHidden || !isPiPActive(video))) { pipCueSignature = null; return; }
            var tracks = video.textTracks;
            if (!tracks) return;
            for (var i = 0; i < tracks.length; i++) {
                var track = tracks[i];
                if (track.mode !== 'showing') continue;
                var signature = activeCueSignature(track, video.currentTime);
                if (pipCueSignature === signature) return;
                pipCueSignature = signature;
                cycleTrackMode(track);
                return;
            }
        }
        function onTrackAdded(event) {
            if (event && event.track) event.track.addEventListener('cuechange', onPiPCaptionTick);
        }
        function onSubtitleRestoreSignal() {
            if (getSubtitlePreference()) { applyNativeSubtitlePreference(); }
        }
        video.addEventListener('timeupdate', onPiPCaptionTick);
        video.addEventListener('loadedmetadata', onSubtitleRestoreSignal);
        video.addEventListener('durationchange', onSubtitleRestoreSignal);
        document.addEventListener('yt-player-state-change', onSubtitleRestoreSignal);
        document.addEventListener('yt-navigate-finish', onSubtitleRestoreSignal);
        if (video.textTracks && typeof video.textTracks.addEventListener === 'function') {
            video.textTracks.addEventListener('addtrack', onTrackAdded);
            video.textTracks.addEventListener('change', onNativeSubtitleChange);
        }
        pipPumpInterval = setInterval(onPiPCaptionTick, 500);

        registerCleanup(function () {
            cancelled = true;
            stopRetry();
            video.removeEventListener('timeupdate', onPiPCaptionTick);
            video.removeEventListener('loadedmetadata', onSubtitleRestoreSignal);
            video.removeEventListener('durationchange', onSubtitleRestoreSignal);
            document.removeEventListener('yt-player-state-change', onSubtitleRestoreSignal);
            document.removeEventListener('yt-navigate-finish', onSubtitleRestoreSignal);
            if (video.textTracks && typeof video.textTracks.removeEventListener === 'function') {
                video.textTracks.removeEventListener('addtrack', onTrackAdded);
                video.textTracks.removeEventListener('change', onNativeSubtitleChange);
            }
            if (pipPumpInterval !== null) { clearInterval(pipPumpInterval); pipPumpInterval = null; }
            pipPumpRestorePending = false;
            if (pipPumpRestoreTimer !== null) { clearTimeout(pipPumpRestoreTimer); pipPumpRestoreTimer = null; }
            if (controller) controller.abort();
            for (var i = 0; i < elements.length; i++) {
                if (elements[i].parentNode) elements[i].remove();
            }
            for (var j = 0; j < blobUrls.length; j++) {
                try { URL.revokeObjectURL(blobUrls[j]); } catch (e) { /* ignore */ }
            }
        });
    }

    // Home/search hover-to-play mounts a tiny html5 player over a thumbnail.
    // Nativeizing it steals the active player, flashes Safari chrome on cards,
    // and makes the real watch/Shorts player look like it never injected.
    function isHoverPreviewPlayer(node) {
        if (!node || node.nodeType !== 1) return false;
        try {
            if (node.closest && node.closest(
                'ytd-video-preview, ytm-video-preview, .video-preview-shim, yt-thumbnail-view-model, ' +
                'ytd-thumbnail, ytd-moving-thumbnail-renderer, ' +
                '#video-preview, #preview, #preview-player, .ytp-inline-preview-ui'
            )) {
                return true;
            }
            var identity = String(node.id || '') + ' ' + String(node.className || '') +
                ' ' + String(node.tagName || '');
            return /(?:video-preview|inline-preview|hover-preview|moving-thumbnail)/i.test(identity);
        } catch (e) { return false; }
    }

    function findPlayer() {
        var candidates = [];
        function add(raw) {
            if (!raw) return;
            var player = raw.matches && raw.matches('.html5-video-player') ? raw :
                (raw.querySelector && raw.querySelector('.html5-video-player')) || raw;
            if (!player.querySelector || !player.querySelector('video')) return;
            if (candidates.indexOf(player) === -1) { candidates.push(player); }
        }

        var known = document.querySelectorAll('#movie_player, .html5-video-player');
        for (var i = 0; i < known.length; i++) {
            if (!isHoverPreviewPlayer(known[i])) { add(known[i]); }
        }
        if (!candidates.length) {
            var wrappers = document.querySelectorAll('ytd-player, ytm-player, #player-container');
            for (var w = 0; w < wrappers.length; w++) {
                if (!isHoverPreviewPlayer(wrappers[w])) { add(wrappers[w]); }
            }
        }
        if (!candidates.length) return null;
        if (candidates.length === 1) return candidates[0];
        var visiblePlaying = null;
        for (var p = 0; p < candidates.length; p++) {
            if (candidates[p].classList.contains('playing-mode') &&
                candidates[p].getAttribute('aria-hidden') !== 'true' && !candidates[p].hidden) {
                if (visiblePlaying) { visiblePlaying = null; break; }
                visiblePlaying = candidates[p];
            }
        }
        if (visiblePlaying) return visiblePlaying;

        // Desktop Shorts can retain multiple player instances. Prefer the
        // visible, initialized, currently-playing one instead of the first DOM
        // match, which is commonly an offscreen previous Short.
        var best = candidates[0];
        var bestScore = -Infinity;
        for (var c = 0; c < candidates.length; c++) {
            var candidate = candidates[c];
            var video = candidate.querySelector('video');
            var score = 0;
            try {
                if (candidate.getAttribute('aria-hidden') === 'true' || candidate.hidden) { score -= 200; }
                if (candidate.classList.contains('playing-mode')) { score += 80; }
                if (video.currentSrc || video.src) { score += 30; }
                if (video.readyState > 0) { score += 30; }
                if (!video.paused && !video.ended) { score += 100; }
                var rect = candidate.getBoundingClientRect();
                if (rect.width > 1 && rect.height > 1 &&
                    rect.bottom > 0 && rect.right > 0 &&
                    rect.top < window.innerHeight && rect.left < window.innerWidth) {
                    score += 60;
                }
                var style = getComputedStyle(candidate);
                if (style.display === 'none' || style.visibility === 'hidden') { score -= 200; }
            } catch (e) { /* keep the structural score */ }
            if (score > bestScore) {
                best = candidate;
                bestScore = score;
            }
        }
        return best;
    }

    function isMiniPlayer(player) {
        if (!player || !player.classList) return false;
        return player.classList.contains('ytp-small-mode') ||
            player.classList.contains('ytp-miniplayer') ||
            !!document.querySelector('ytd-miniplayer #movie_player, ytm-miniplayer #movie_player');
    }

    function isShortsPath() {
        return /^\/shorts(?:\/|$)/.test(location.pathname);
    }

    // Users asked for YouTube's stock Shorts experience: the Shorts UI
    // (action rail, subscribe row, sound picker, tap gestures) is built
    // around YouTube's own player chrome, so nativeizing the reel player
    // does more harm than good there. On /shorts paths the stylesheet is
    // suspended and any nativeized player is fully released; navigating
    // back to a regular page re-enables everything pre-paint.
    var shortsSuspensionComplete = false;

    function setStylesSuspended(suspended) {
        var style = document.getElementById(STYLE_ID);
        if (style && style.disabled !== suspended) { style.disabled = suspended; }
    }

    function suspendForShorts() {
        // The stylesheet can appear after the first suspension pass (the
        // document observer injects it pre-paint), so re-disable it cheaply
        // on every call.
        setStylesSuspended(true);
        if (shortsSuspensionComplete) return;
        shortsSuspensionComplete = true;
        if (playerObserver) {
            try { playerObserver.disconnect(); } catch (e) { /* ignore */ }
            playerObserver = null;
        }
        var released = activeVideo;
        if (released) {
            releaseActiveVideo();
            // Teardown keeps the forced controls attribute; strip it so
            // Safari's native bar does not cover the Shorts UI.
            try { released.removeAttribute('controls'); } catch (e) { /* ignore */ }
        }
        var marked = document.querySelectorAll('.wblock-tc-native, [' + ATTR_CLEANED + ']');
        for (var i = 0; i < marked.length; i++) {
            marked[i].classList.remove('wblock-tc-native');
            marked[i].removeAttribute(ATTR_CLEANED);
        }
    }

    // Hand a nativeized player back to YouTube when it becomes a miniplayer or
    // feed preview, so neither keeps native controls or auto-PiP hooks.
    function releasePlayer(player) {
        if (playerObserver) {
            try { playerObserver.disconnect(); } catch (e) { /* ignore */ }
            playerObserver = null;
        }
        if (activeVideo) { releaseActiveVideo(); }
        player.classList.remove('wblock-tc-native');
        player.removeAttribute(ATTR_CLEANED);
        if (isHoverPreviewPlayer(player)) {
            var video = player.querySelector('video');
            if (video) video.removeAttribute('controls');
        }
        setAudioOnlyStyles(false);
    }

    function transformPlayer() {
        // YouTube Music owns a complete responsive player and Media Session.
        // Native controls are invisible in song mode and duplicate its transport
        // in video mode, so the Music integration is background playback only.
        if (IS_YOUTUBE_MUSIC) return;
        if (isShortsPath()) {
            suspendForShorts();
            return;
        }
        setStylesSuspended(false);
        shortsSuspensionComplete = false;

        var player = findPlayer();
        if (!player) {
            // m.youtube.com moves the watch player into a home-feed preview.
            var moved = document.querySelector('.wblock-tc-native');
            if (moved && isHoverPreviewPlayer(moved)) releasePlayer(moved);
            return;
        }

        if (isMiniPlayer(player)) {
            releasePlayer(player);
            return;
        }

        var video = player.querySelector('video');
        if (!video) return;
        if (isHoverPreviewPlayer(player) || isHoverPreviewPlayer(video)) return;

        // Check if we already processed this video.
        var videoId = youtubeVideoIdentity(player) || '';
        var toolbarMissing = featureEnabled('toolbar') && !player.querySelector('.wblock-tc-toolbar');
        if (player.getAttribute(ATTR_CLEANED) === videoId && activeVideo === video && !toolbarMissing) return;
        player.setAttribute(ATTR_CLEANED, videoId);

        log('transforming player for', videoId || '(unknown)');

        // 1. Mark the video as native by adding a wrapper class
        player.classList.add('wblock-tc-native');

        // 2-5. Apply all per-video enhancements (native controls, PiP/inline
        // attributes, controls guard, toolbar, auto-PiP).
        // activateVideo first tears down the previous video's resources so
        // nothing leaks across SPA navigations.
        activateVideo(player, video);

        // 6. Apply audio-only preference on desktop only. Hiding the <video>
        // on iOS also hides Safari's native controls, and the mode never reduced
        // SABR video transfer in the first place. Clear old persisted state so
        // users cannot remain trapped on a black, non-interactive player.
        if (IS_IOS) {
            if (isAudioOnly()) { setAudioOnly(false); }
            setAudioOnlyStyles(false);
        } else {
            setAudioOnlyStyles(isAudioOnly());
        }

        // 7. Enable background playback
        if (featureEnabled('backgroundPlayback')) enableBackgroundPlayback();

        if (!IS_IOS) applyPreferredQuality();

        // 7. Observe for video element recreation. The player element persists
        // across SPA navigations, so disconnect any previous observer before
        // creating a new one to avoid accumulating observers.
        if (playerObserver) {
            try { playerObserver.disconnect(); } catch (e) { /* ignore */ }
        }
        playerObserver = new MutationObserver(function () {
            var newVid = player.querySelector('video');
            if (newVid && newVid !== activeVideo) {
                log('re-patching new video element');
                activateVideo(player, newVid);
            }
        });
        playerObserver.observe(player, { childList: true, subtree: true });

        log('player transformed');
    }

    // ------------------------------------------------------------------
    // Quality control via YouTube's internal player UI
    // ------------------------------------------------------------------

    // YouTube's quality labels match quality strings
    var QUALITY_LABELS = {
        auto: 'Auto',
        hd2160: '4K',
        hd1440: '1440p',
        hd1080: '1080p',
        hd720: '720p',
        large: '480p',
        medium: '360p',
        small: '240p',
        tiny: '144p'
    };

    // Ordered from highest to lowest (excluding 'auto')
    var QUALITY_ORDER = [
        'hd2160', 'hd1440', 'hd1080', 'hd720',
        'large', 'medium', 'small', 'tiny'
    ];

    // A blob: src on the media element is conclusive evidence that the page
    // attached a MediaSource / ManagedMediaSource (Tube Cleaner never assigns
    // blob urls itself). On iOS, tearing that element out of the DOM or
    // overwriting its src with a discovered url wedges YouTube's SABR / MMS
    // pipeline and surfaces as a player that refuses to load until refresh.
    function hasOpaqueMediaSource(video) {
        try {
            return !!(video && ((video.currentSrc || '').indexOf('blob:') === 0 ||
                (video.src || '').indexOf('blob:') === 0));
        } catch (e) { return false; }
    }

    // SABR can initially report only the rendition buffered so far (often
    // 360p), on both mobile and desktop Safari. Treat a standard-definition-
    // only response as incomplete rather than making the picker useless. Once
    // a real ladder is reported, offer only it, so choosing above a video's
    // maximum steps down instead of pinning a rendition that does not exist.
    // Selection stays best-effort. Saved iOS choices wait for playback, and a
    // stalled restoration falls back to Auto without forgetting the preference.
    function qualityMenuLevels() {
        var reported = getAvailableQualities();
        var mediumIndex = QUALITY_ORDER.indexOf('medium');
        var hasHigherRendition = reported.some(function (quality) {
            var index = QUALITY_ORDER.indexOf(quality);
            return index !== -1 && index < mediumIndex;
        });
        if (hasHigherRendition) { return reported; }

        var seen = {};
        var levels = [];
        for (var i = 0; i < QUALITY_ORDER.length; i++) {
            seen[QUALITY_ORDER[i]] = true;
            levels.push(QUALITY_ORDER[i]);
        }
        for (var j = 0; j < reported.length; j++) {
            if (!seen[reported[j]]) { seen[reported[j]] = true; levels.push(reported[j]); }
        }
        return levels;
    }

    function getAvailableQualities() {
        var player = findPlayer();
        if (!player || !player.getAvailableQualityLevels) return [];
        var levels = player.getAvailableQualityLevels();
        if (!levels || !levels.length) return [];
        // levels is ordered highest-first, may include 'auto'
        return levels.filter(function (q) { return q && q !== 'auto'; });
    }

    function getCurrentQuality() {
        var player = findPlayer();
        if (!player || !player.getPlaybackQuality) return 'auto';
        var q = player.getPlaybackQuality();
        return q || 'auto';
    }

    // The SABR mobile player sometimes reports 'unknown' (or lags) from
    // getPlaybackQuality. Fall back to the decoded frame height so the label
    // reflects the stream that is actually rendering.
    function qualityFromVideoHeight(video) {
        var h = video && Math.min(video.videoWidth || Infinity, video.videoHeight || Infinity);
        if (!h || !isFinite(h)) return null;
        if (h >= 2000) return 'hd2160';
        if (h >= 1300) return 'hd1440';
        if (h >= 1000) return 'hd1080';
        if (h >= 650) return 'hd720';
        if (h >= 430) return 'large';
        if (h >= 330) return 'medium';
        if (h >= 210) return 'small';
        return 'tiny';
    }

    // Click YouTube's internal settings button to open the quality menu
    function openSettingsMenu(player) {
        var settingsBtn = player.querySelector('.ytp-settings-button') ||
            player.querySelector('[aria-label="Settings"]') ||
            player.querySelector('.ytp-button[aria-label*="Settings"]');
        if (!settingsBtn) { warn('openSettings: no settings button'); return false; }
        var expanded = settingsBtn.getAttribute('aria-expanded') === 'true' ||
            player.classList.contains('ytp-settings-menu-open');
        if (!expanded) { settingsBtn.click(); }
        return true;
    }

    // Find the quality menu item in the settings panel
    function clickQualityMenuItem(player) {
        var menuItems = player.querySelectorAll('.ytp-menuitem');
        for (var i = 0; i < menuItems.length; i++) {
            var item = menuItems[i];
            var content = item.querySelector('.ytp-menuitem-content');
            if (content && content.textContent && content.textContent.match(/\d{3,}/)) {
                // This is the quality menu item (has resolution numbers)
                item.click();
                return true;
            }
        }
        // Alternative: look for the label
        for (var j = 0; j < menuItems.length; j++) {
            var label = menuItems[j].querySelector('.ytp-menuitem-label');
            if (label && label.textContent && label.textContent.toLowerCase().indexOf('quality') !== -1) {
                menuItems[j].click();
                return true;
            }
        }
        return false;
    }

    // Click a specific quality option in the quality submenu
    function clickQualityOption(player, target) {
        var targetLabel = QUALITY_LABELS[target] || target;
        // Try to find by quality label text (e.g. "1080p", "720p")
        var allOptions = player.querySelectorAll('.ytp-quality-menu .ytp-menuitem, ' +
            '.ytp-drop-down-menu-button, [role="menuitemradio"], ' +
            '.ytp-panel-menu .ytp-menuitem');

        // Look for the label that matches our target
        var items = [];
        for (var i = 0; i < allOptions.length; i++) items.push(allOptions[i]);

        // Sort: prefer exact match, then partial match
        var bestMatch = null;
        var bestScore = -1;
        for (var j = 0; j < items.length; j++) {
            var text = items[j].textContent || '';
            var score = 0;
            if (text.indexOf(targetLabel) !== -1) score = 2;
            else if (text.indexOf(target) !== -1) score = 1;
            if (score > bestScore) {
                bestScore = score;
                bestMatch = items[j];
            }
        }

        if (bestMatch && bestScore > 0) {
            log('clicking quality option:', bestMatch.textContent);
            bestMatch.click();
            return true;
        }

        return false;
    }

    // Close the settings panel
    function closeSettingsPanel(player) {
        var backBtn = player.querySelector('.ytp-panel-header button');
        if (backBtn) {
            backBtn.click();
            return true;
        }
        // Click the settings button again to toggle it closed
        var settingsBtn = player.querySelector('.ytp-settings-button');
        if (settingsBtn) {
            settingsBtn.click();
        }
        return false;
    }

    var qualityGeneration = 0;
    var qualityRequest = null;

    function cancelQualityRequest() {
        var request = qualityRequest;
        if (!request) return;
        request.cancelled = true;
        qualityGeneration++;
        for (var i = 0; i < request.timers.length; i++) clearTimeout(request.timers[i]);
        request.timers = [];
        closeSettingsPanel(request.player);
        qualityRequest = null;
        for (var j = 0; j < request.callbacks.length; j++) request.callbacks[j](false);
    }

    function finishQualityRequest(request, worked) {
        if (qualityRequest !== request || request.cancelled || request.generation !== qualityGeneration) return;
        for (var i = 0; i < request.timers.length; i++) clearTimeout(request.timers[i]);
        request.timers = [];
        qualityRequest = null;
        for (var j = 0; j < request.callbacks.length; j++) request.callbacks[j](worked);
    }

    function setQuality(target, callback) {
        cancelMobileQualityRestore();
        var player = findPlayer();
        if (!player || !activeVideo) {
            warn('setQuality: no player');
            if (callback) callback(false);
            return false;
        }
        if (qualityRequest) {
            if (qualityRequest.player === player && qualityRequest.target === target) {
                if (callback) qualityRequest.callbacks.push(callback);
                return true;
            }
            cancelQualityRequest();
        }

        if (target !== 'auto') {
            var levels = qualityMenuLevels();
            if (levels.indexOf(target) === -1) {
                var targetIdx = QUALITY_ORDER.indexOf(target);
                for (var i = targetIdx + 1; i < QUALITY_ORDER.length; i++) {
                    if (levels.indexOf(QUALITY_ORDER[i]) !== -1) {
                        target = QUALITY_ORDER[i];
                        break;
                    }
                }
            }
            log('setQuality:', target, 'available:', levels);
        }

        var request = {
            player: player, video: activeVideo, target: target, generation: ++qualityGeneration,
            cancelled: false, timers: [], callbacks: callback ? [callback] : []
        };
        qualityRequest = request;

        function current() {
            return qualityRequest === request && !request.cancelled &&
                request.generation === qualityGeneration && activeVideo === request.video;
        }
        function later(fn, delay) {
            request.timers.push(setTimeout(function () {
                if (current()) fn();
            }, delay));
        }
        function fallback() {
            if (!current()) return;
            closeSettingsPanel(player);
            var worked = false;
            try {
                if (player.setPlaybackQualityRange) {
                    // Pin one rendition like YouTube's own menu. SABR ignores a
                    // capped ladder and setPlaybackQuality(), so only 144p used
                    // to switch, and nothing but 'auto','auto' releases the pin.
                    player.setPlaybackQualityRange(target, target);
                    worked = true;
                } else if (player.setPlaybackQuality) {
                    player.setPlaybackQuality(target);
                    worked = true;
                }
                if (worked && target === 'auto') localStorage.removeItem('yt-player-quality');
            } catch (e) { log('quality API fallback failed', e); }
            if (worked && target !== 'auto' && !IS_IOS) {
                try {
                    localStorage.setItem('yt-player-quality', JSON.stringify({
                        quality: target, previousQuality: 'auto', expiry: Date.now() + 86400000
                    }));
                } catch (e) { /* ignore */ }
            }
            finishQualityRequest(request, worked);
        }

        // The YouTube menu is authoritative for SABR. API calls are used only
        // after a menu step is unavailable or fails, never in parallel with it.
        try {
            if (!openSettingsMenu(player)) { fallback(); return true; }
            later(function () {
                if (!clickQualityMenuItem(player)) { fallback(); return; }
                later(function () {
                    if (!clickQualityOption(player, target)) { fallback(); return; }
                    later(function () {
                        closeSettingsPanel(player);
                        finishQualityRequest(request, true);
                    }, 100);
                }, 200);
            }, 200);
        } catch (e) {
            warn('quality UI failed', e);
            fallback();
        }
        return true;
    }

    var mobileQualityCleanup = null;

    function cancelMobileQualityRestore() {
        if (mobileQualityCleanup) mobileQualityCleanup();
    }

    function restoreMobileQuality(preferred) {
        cancelMobileQualityRestore();
        var video = activeVideo;
        var player = findPlayer();
        if (!video || !player || QUALITY_ORDER.indexOf(preferred) === -1) return;
        var lastTime = video.currentTime;
        var monitor = null;
        function stop() {
            video.removeEventListener('timeupdate', onProgress);
            if (monitor !== null) clearInterval(monitor);
            monitor = null;
            if (mobileQualityCleanup === stop) mobileQualityCleanup = null;
        }
        function current() {
            return activeVideo === video && getPreferredQuality() === preferred;
        }
        function onProgress() {
            if (!current()) { stop(); return; }
            var advance = video.currentTime - lastTime;
            lastTime = video.currentTime;
            if (video.paused || video.seeking || video.ended || video.readyState < 2 ||
                player.classList.contains('ad-showing') || advance <= 0 || advance > 3) return;
            stop();
            // Use the same bounded request as a manual choice, never pin a
            // rendition before the stream has begun producing frames.
            setQuality(preferred, function (worked) {
                if (!worked || !current()) return;
                storageRemove('yt-player-quality');
                var previousTime = video.currentTime;
                var previousCheck = Date.now();
                var stalled = 0;
                var observed = 0;
                mobileQualityCleanup = stop;
                monitor = setInterval(function () {
                    if (!current() || video.ended) { stop(); return; }
                    var now = Date.now();
                    var elapsed = Math.min(1000, Math.max(0, now - previousCheck));
                    previousCheck = now;
                    if (video.paused || video.seeking || document.hidden ||
                        player.classList.contains('ad-showing')) {
                        stalled = 0;
                        previousTime = video.currentTime;
                        return;
                    }
                    observed += elapsed;
                    stalled = video.currentTime !== previousTime ? 0 : stalled + elapsed;
                    previousTime = video.currentTime;
                    if (stalled >= 8000) {
                        stop();
                        // Recover this video without forgetting the user's choice
                        // for the next one or repeatedly forcing a stalled stream.
                        setQuality('auto');
                    } else if (observed >= 20000) {
                        stop();
                    }
                }, 500);
            });
        }
        mobileQualityCleanup = stop;
        video.addEventListener('timeupdate', onProgress);
    }

    function applyPreferredQuality() {
        var preferred = getPreferredQuality();
        if (IS_IOS) {
            if (preferred === 'auto') cancelMobileQualityRestore();
            else restoreMobileQuality(preferred);
            return;
        }
        if (preferred === 'auto') return;
        var player = findPlayer();
        if (!player || !player.setPlaybackQualityRange) return;
        // Cap SABR at the saved quality. Do not click the settings menu or pin
        // a single rendition: either one restarts the stream when 4K is still
        // warming up from a lower startup ladder.
        try { player.setPlaybackQualityRange('tiny', preferred); }
        catch (e) { /* ignore */ }
    }

    // ------------------------------------------------------------------
    // Toolbar overlay (playback controls and SponsorBlock settings)
    // ------------------------------------------------------------------

    // The player establishes a containing/stacking context on mobile Safari,
    // which can clip even position:fixed children to its small inline frame.
    // Portal open menus to <body> so they are genuine page overlays and can use
    // the whole YouTube viewport. The portal still opens right above its
    // button (or below it when there is more room there), not at the screen
    // edge, so the menu reads as belonging to the pill that opened it.
    function showMobilePageOverlay(menu, anchor, maxHeight, gap) {
        if (!IS_IOS || !menu || !document.body) { return; }
        if (menu.parentNode !== document.body) { document.body.appendChild(menu); }
        var rect = anchor.getBoundingClientRect();
        var viewHeight = window.innerHeight;
        var above = rect.top - gap - 8;
        var below = viewHeight - rect.bottom - gap - 8;
        var openUp = above >= Math.min(maxHeight, 240) || above >= below;
        menu.style.position = 'fixed';
        menu.style.right = Math.max(8, window.innerWidth - rect.right) + 'px';
        menu.style.top = openUp ? 'auto' : (rect.bottom + gap) + 'px';
        menu.style.bottom = openUp ? (viewHeight - rect.top + gap) + 'px' : 'auto';
        menu.style.marginTop = '0';
        menu.style.marginBottom = '0';
        // Let short menus end at their final control. max-height reserves
        // scrolling only for a panel that genuinely exceeds the room.
        menu.style.height = 'auto';
        menu.style.maxHeight = Math.max(120, Math.min(maxHeight, openUp ? above : below)) + 'px';
        // A short/landscape phone can still be smaller than a full panel.
        // Keep scrolling inside the overlay rather than growing it off-screen.
        menu.style.overflowY = 'auto';
        menu.style.webkitOverflowScrolling = 'touch';
        menu.style.overscrollBehavior = 'contain';
        menu.style.zIndex = '2147483647';
    }

    function removeMobilePageOverlay(menu) {
        if (IS_IOS && menu && menu.parentNode === document.body) { menu.remove(); }
    }

    function toolbarBoxStyle() {
        var opacity = IS_IOS ? '1' : '0.75';
        var font = IS_IOS ? '14px' : '11px';
        // Sit just above Safari's control bar, which reaches 52px above the
        // video's bottom edge. Before Safari 27 the macOS volume slider rose
        // about 125px out of that bar and closed when a pill covered it; 27
        // moved volume to the top corner.
        var bottom = IS_IOS ? 'calc(56px + env(safe-area-inset-bottom, 0px))'
            : (SAFARI_MAJOR >= 27 ? '58px' : '130px');
        var right = IS_IOS ? 'max(8px, env(safe-area-inset-right, 0px))' : '8px';
        var edges = 'bottom:' + bottom + ';right:' + right + ';top:auto;left:auto';
        return 'position:absolute;' + edges + ';z-index:2147483646;display:flex;flex-direction:column;gap:6px;align-items:flex-end' +
            ';pointer-events:none;font:' + font + '/1.2 -apple-system,system-ui,sans-serif;opacity:' +
            opacity + ';transition:opacity 0.15s';
    }

    function placeDesktopAnchoredMenu(menu, options) {
        options = options || {};
        menu.style.position = 'absolute';
        menu.style.height = 'auto';
        menu.style.maxHeight = options.maxHeight || '60vh';
        menu.style.top = 'auto';
        menu.style.bottom = '100%';
        menu.style.left = options.upLeft || 'auto';
        menu.style.right = options.upRight || '0';
        menu.style.marginTop = '0';
        menu.style.marginBottom = options.gap || '4px';
    }

    function buildToolbar(player, video) {
        var existing = player.querySelector('.wblock-tc-toolbar');
        if (existing) {
            if (existing._wblockQualityTimer) clearInterval(existing._wblockQualityTimer);
            existing.remove();
        }

        var toolbar = document.createElement('div');
        toolbar.className = 'wblock-tc-toolbar';
        // Watch pages sit above Safari's native control strip at the
        // bottom-right. The mobile toolbar auto-hides and reappears on a
        // tap to the video surface. (Shorts never builds a toolbar; the
        // cleaner is fully suspended there.)
        toolbar.style.cssText = toolbarBoxStyle();

        var btnStyle = 'background:rgba(0,0,0,0.7);color:#fff;border:none;border-radius:4px;padding:3px 8px;font-size:11px;cursor:pointer;-webkit-user-select:none;user-select:none';
        // On iOS, use larger touch targets (minimum 44pt)
        if (IS_IOS) {
            btnStyle = 'background:rgba(0,0,0,0.78);color:#fff;border:none;border-radius:8px;padding:8px 12px;min-width:44px;min-height:44px;font-size:14px;cursor:pointer;-webkit-user-select:none;user-select:none;touch-action:manipulation';
        }
        var playbackRow = document.createElement('div');
        playbackRow.className = 'wblock-tc-playback-row';
        var rowJustify = 'flex-end';
        playbackRow.style.cssText = 'display:flex;gap:6px;align-items:center;justify-content:' + rowJustify;
        var servicesRow = document.createElement('div');
        servicesRow.className = 'wblock-tc-services-row';
        servicesRow.style.cssText = 'display:flex;gap:6px;align-items:center;justify-content:' + rowJustify;
        // Services (SB) sit on top; the quality picker is the row nearest the
        // native control strip so the pill people reach for most is lowest.
        toolbar.appendChild(servicesRow);
        toolbar.appendChild(playbackRow);

        // Quality selector
        var qualityBtn = document.createElement('button');
        qualityBtn.className = 'wblock-tc-quality-button';
        qualityBtn.type = 'button';
        qualityBtn.style.cssText = btnStyle;
        function updateQualityBtn() {
            var preferred = getPreferredQuality();
            var current = getCurrentQuality();
            if (current === 'auto' || current === 'unknown' || !QUALITY_LABELS[current]) {
                var mapped = qualityFromVideoHeight(video);
                if (mapped) current = mapped;
            }
            var currentLabel = QUALITY_LABELS[current] || current;
            if (preferred === 'auto') {
                // Auto is a mode, not a wedged setting. Small portrait players
                // legitimately stream 360p on auto; show it as status so it
                // does not read as a stuck quality choice.
                qualityBtn.textContent = current === 'auto' ? 'Auto' : 'Auto (' + currentLabel + ')';
            } else {
                qualityBtn.textContent = currentLabel;
            }
            qualityBtn.title = 'Video quality (click to change)';
        }
        updateQualityBtn();

        // Quality dropdown — opens away from the toolbar edge.
        var qualityMenu = document.createElement('div');
        qualityMenu.className = 'wblock-tc-quality-menu';
        var menuFont = IS_IOS ? '16px' : '12px';
        var menuPadding = IS_IOS ? '8px 0' : '4px 0';
        var menuMinWidth = IS_IOS ? '140px' : '100px';
        var qualityMenuAnchor = 'bottom:100%;right:0;margin-bottom:4px;';
        qualityMenu.style.cssText = 'position:absolute;' + qualityMenuAnchor + 'box-sizing:border-box;background:rgba(0,0,0,0.92);border-radius:5px;padding:' + menuPadding + ';min-width:' + menuMinWidth + ';max-height:60vh;overflow-y:auto;-webkit-overflow-scrolling:touch;display:none;z-index:70;font:' + menuFont + '/1.8 -apple-system,system-ui,sans-serif';

        function buildQualityMenu() {
            // Clear safely — avoid innerHTML which triggers TrustedHTML CSP
            while (qualityMenu.firstChild) {
                qualityMenu.removeChild(qualityMenu.firstChild);
            }
            var levels = qualityMenuLevels();
            var preferred = getPreferredQuality();

            var itemPadding = IS_IOS ? '10px 16px' : '4px 12px';
            // Use real buttons rather than clickable divs. In iOS Safari, a
            // video layer can make synthetic click targets unreliable, while
            // buttons retain their touch activation semantics above the player.
            var itemStyle = 'display:block;width:100%;border:0;background:transparent;font:inherit;line-height:inherit;text-align:left;padding:' +
                itemPadding + ';cursor:pointer;color:#fff;white-space:nowrap;-webkit-appearance:none;appearance:none;touch-action:manipulation';

            // Auto option
            var autoItem = document.createElement('button');
            autoItem.type = 'button';
            autoItem.style.cssText = itemStyle;
            autoItem.textContent = 'Auto';
            if (preferred === 'auto') {
                autoItem.style.color = '#4fc3f7';
            }
            autoItem.addEventListener('click', function (e) {
                e.preventDefault();
                e.stopPropagation();
                setPreferredQuality('auto');
                setQuality('auto');
                updateQualityBtn();
                qualityMenu.style.display = 'none';
            });
            qualityMenu.appendChild(autoItem);

            // Available quality levels
            for (var i = 0; i < levels.length; i++) {
                (function (q) {
                    var item = document.createElement('button');
                    item.type = 'button';
                    item.style.cssText = itemStyle;
                    item.textContent = QUALITY_LABELS[q] || q;
                    if (preferred === q) {
                        item.style.color = '#4fc3f7';
                    }
                    item.addEventListener('click', function (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        setPreferredQuality(q);
                        setQuality(q);
                        updateQualityBtn();
                        qualityMenu.style.display = 'none';
                    });
                    qualityMenu.appendChild(item);
                })(levels[i]);
            }
        }

        qualityBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            if (sponsorMenu) {
                sponsorMenu.style.display = 'none';
                if (sponsorBtn) sponsorBtn.setAttribute('aria-expanded', 'false');
            }
            if (qualityMenu.style.display === 'none') {
                buildQualityMenu();
                if (IS_IOS) {
                    showMobilePageOverlay(qualityMenu, qualityBtn, 520, 4);
                } else {
                    placeDesktopAnchoredMenu(qualityMenu, { maxHeight: '60vh', gap: '4px' });
                }
                qualityMenu.style.display = 'block';
            } else {
                qualityMenu.style.display = 'none';
            }
        });

        // Close menu on outside click
        function onDocumentClick() {
            qualityMenu.style.display = 'none';
        }
        document.addEventListener('click', onDocumentClick);
        registerCleanup(function () {
            document.removeEventListener('click', onDocumentClick);
            removeMobilePageOverlay(qualityMenu);
        });

        var qualityWrap = document.createElement('div');
        qualityWrap.style.cssText = 'position:relative';
        qualityWrap.appendChild(qualityBtn);
        qualityWrap.appendChild(qualityMenu);
        playbackRow.appendChild(qualityWrap);

        // Update quality label periodically. Store the timer on the toolbar so
        // it can be cleared when the toolbar is rebuilt (avoids a leak across
        // video-element re-creation).
        toolbar._wblockQualityTimer = setInterval(updateQualityBtn, 2000);
        registerCleanup(function () {
            if (toolbar._wblockQualityTimer) {
                clearInterval(toolbar._wblockQualityTimer);
                toolbar._wblockQualityTimer = null;
            }
        });

        // Audio-only toggle
        var audioBtn = document.createElement('button');
        audioBtn.className = 'wblock-tc-audio-button';
        audioBtn.type = 'button';
        audioBtn.style.cssText = btnStyle;
        function updateAudioBtn() {
            audioBtn.textContent = isAudioOnly() ? 'Video' : 'Audio';
            audioBtn.title = isAudioOnly() ? 'Switch to video mode' : 'Switch to audio-only mode';
        }
        updateAudioBtn();
        audioBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            var next = !isAudioOnly();
            setAudioOnly(next);
            setAudioOnlyStyles(next);
            updateAudioBtn();
        });
        if (!IS_IOS) { playbackRow.appendChild(audioBtn); }

        // SponsorBlock settings. This mirrors SponsorBlock's familiar category
        // colors and Auto / Show button / Disabled choices without importing
        // its extension-only React, chrome.storage, voting, and submission UI.
        var sponsorWrap = document.createElement('div');
        sponsorWrap.style.cssText = 'position:relative';
        var sponsorBtn = document.createElement('button');
        sponsorBtn.className = 'wblock-tc-sponsor-button';
        sponsorBtn.type = 'button';
        sponsorBtn.style.cssText = btnStyle;
        sponsorBtn.textContent = 'SB';
        sponsorBtn.setAttribute('aria-haspopup', 'dialog');
        sponsorBtn.setAttribute('aria-expanded', 'false');
        var sponsorMenu = document.createElement('div');
        sponsorMenu.className = 'wblock-tc-sponsor-menu';
        sponsorMenu.setAttribute('role', 'dialog');
        sponsorMenu.setAttribute('aria-label', sponsorBlockLocale().title);
        sponsorMenu.style.cssText = 'position:absolute;bottom:100%;right:0;margin-bottom:6px;box-sizing:border-box;' +
            'width:' + (IS_IOS ? 'min(340px,calc(100vw - 16px))' : '310px') + ';max-height:65vh;overflow:auto;' +
            'background:rgba(22,22,24,.98);border:1px solid rgba(255,255,255,.14);border-radius:10px;' +
            'padding:12px;color:#fff;display:none;z-index:80;font:' + (IS_IOS ? '14px' : '12px') +
            '/1.35 -apple-system,system-ui,sans-serif;box-shadow:0 8px 28px rgba(0,0,0,.45);text-align:left';

        function updateSponsorButton() {
            var buttonSettings = loadSponsorBlockSettings();
            var enabled = buttonSettings.enabled && !sponsorBlockDisabledVideos[sponsorBlockVideoId()] &&
                !sponsorBlockChannelExcluded(buttonSettings);
            sponsorBtn.style.color = enabled ? '#00d400' : '#aaa';
            sponsorBtn.title = sponsorBlockLocale().title;
            sponsorBtn.setAttribute('aria-pressed', enabled ? 'true' : 'false');
        }

        function sponsorCheckboxRow(labelText, checked, onChange) {
            var label = document.createElement('label');
            label.style.cssText = 'display:flex;align-items:center;gap:8px;padding:6px 0;cursor:pointer';
            var input = document.createElement('input');
            input.type = 'checkbox';
            input.checked = checked;
            input.style.cssText = 'width:16px;height:16px;accent-color:#00d400';
            input.addEventListener('change', function () { onChange(input.checked); });
            var text = document.createElement('span');
            text.textContent = labelText;
            label.appendChild(input);
            label.appendChild(text);
            return label;
        }

        function buildSponsorMenu() {
            while (sponsorMenu.firstChild) sponsorMenu.removeChild(sponsorMenu.firstChild);
            var locale = sponsorBlockLocale();
            var settings = loadSponsorBlockSettings();
            var heading = document.createElement('div');
            heading.textContent = 'SponsorBlock';
            heading.style.cssText = 'position:sticky;top:-12px;z-index:1;display:flex;align-items:center;justify-content:space-between;gap:12px;' +
                'background:rgb(22,22,24);margin:-12px -12px 7px;padding:4px 8px 4px 12px;font-weight:700;font-size:' + (IS_IOS ? '18px' : '15px');
            var close = document.createElement('button');
            close.type = 'button'; close.className = 'wblock-tc-sponsor-close';
            close.textContent = '\u00d7';
            close.setAttribute('aria-label', locale.close);
            close.title = locale.close;
            close.style.cssText = 'flex:0 0 44px;width:44px;height:44px;padding:0;background:transparent;color:#fff;' +
                'border:0;border-radius:6px;font:28px/1 -apple-system,system-ui,sans-serif;cursor:pointer';
            close.addEventListener('click', function () { hideSponsorMenu(); sponsorBtn.focus(); });
            heading.appendChild(close);
            sponsorMenu.appendChild(heading);
            sponsorMenu.appendChild(sponsorCheckboxRow(locale.enabled, settings.enabled, function (checked) {
                settings.enabled = checked;
                saveSponsorBlockSettings(settings);
                updateSponsorButton();
                buildSponsorMenu();
            }));

            var divider = document.createElement('div');
            divider.style.cssText = 'height:1px;background:rgba(255,255,255,.12);margin:5px 0';
            sponsorMenu.appendChild(divider);
            for (var i = 0; i < SPONSORBLOCK_CATEGORIES.length; i++) {
                (function (category, index) {
                    var row = document.createElement('label');
                    row.style.cssText = 'display:grid;grid-template-columns:10px 1fr auto;align-items:center;gap:8px;padding:5px 0';
                    var color = document.createElement('span');
                    color.style.cssText = 'width:9px;height:9px;border-radius:2px;background:' + category.color;
                    var name = document.createElement('span');
                    name.textContent = locale.names[index];
                    var select = document.createElement('select');
                    select.setAttribute('data-sponsor-category', category.id);
                    select.style.cssText = 'max-width:' + (IS_IOS ? '150px' : '125px') + ';background:#353538;color:#fff;' +
                        'border:1px solid #5b5b60;border-radius:5px;padding:' + (IS_IOS ? '7px 5px' : '3px 4px') + ';font:inherit';
                    [['auto', locale.auto], ['ask', locale.ask], ['off', locale.off]].forEach(function (optionData) {
                        var option = document.createElement('option');
                        option.value = optionData[0];
                        option.textContent = optionData[1];
                        select.appendChild(option);
                    });
                    select.value = settings.modes[category.id];
                    select.disabled = !settings.enabled;
                    select.addEventListener('change', function () {
                        settings.modes[category.id] = select.value;
                        saveSponsorBlockSettings(settings);
                    });
                    row.appendChild(color); row.appendChild(name); row.appendChild(select);
                    sponsorMenu.appendChild(row);
                })(SPONSORBLOCK_CATEGORIES[i], i);
            }

            var optionsDivider = divider.cloneNode(false);
            sponsorMenu.appendChild(optionsDivider);
            sponsorMenu.appendChild(sponsorCheckboxRow(locale.notice, settings.showNotice, function (checked) {
                settings.showNotice = checked;
                saveSponsorBlockSettings(settings);
            }));
            // Whole-toolbar visibility preference. It lives here because this
            // is the only settings surface Tube Cleaner has; it hides the
            // quality and SB pills together on this device.
            sponsorMenu.appendChild(sponsorCheckboxRow(locale.hideControls, isToolbarHidden(), function (checked) {
                setToolbarHidden(checked);
            }));
            var durationRow = document.createElement('label');
            durationRow.style.cssText = 'display:flex;align-items:center;justify-content:space-between;gap:10px;padding:6px 0';
            var durationLabel = document.createElement('span');
            durationLabel.textContent = locale.duration;
            var durationSelect = document.createElement('select');
            durationSelect.style.cssText = 'background:#353538;color:#fff;border:1px solid #5b5b60;border-radius:5px;padding:3px 4px;font:inherit';
            [[0, locale.any], [1, '1 s'], [2, '2 s'], [5, '5 s'], [10, '10 s']].forEach(function (value) {
                var option = document.createElement('option'); option.value = value[0]; option.textContent = value[1];
                durationSelect.appendChild(option);
            });
            if (![0, 1, 2, 5, 10].includes(settings.minimumDuration)) {
                var importedDuration = document.createElement('option');
                importedDuration.value = String(settings.minimumDuration);
                importedDuration.textContent = String(settings.minimumDuration) + ' s';
                durationSelect.appendChild(importedDuration);
            }
            durationSelect.value = String(settings.minimumDuration);
            durationSelect.addEventListener('change', function () {
                settings.minimumDuration = Number(durationSelect.value);
                saveSponsorBlockSettings(settings);
            });
            durationRow.appendChild(durationLabel); durationRow.appendChild(durationSelect);
            sponsorMenu.appendChild(durationRow);

            var currentId = sponsorBlockVideoId();
            sponsorMenu.appendChild(sponsorCheckboxRow(locale.current, !!sponsorBlockDisabledVideos[currentId], function (checked) {
                if (checked) sponsorBlockDisabledVideos[currentId] = true;
                else delete sponsorBlockDisabledVideos[currentId];
                document.dispatchEvent(new CustomEvent('wblock-tc-sponsor-settings'));
                updateSponsorButton();
            }));
            var channelId = sponsorBlockChannelId();
            if (channelId) {
                var channelRow = sponsorCheckboxRow(locale.channel,
                    settings.excludedChannels.indexOf(channelId) !== -1, function (checked) {
                        var index = settings.excludedChannels.indexOf(channelId);
                        if (checked && index === -1) settings.excludedChannels.push(channelId);
                        if (!checked && index !== -1) settings.excludedChannels.splice(index, 1);
                        saveSponsorBlockSettings(settings);
                        updateSponsorButton();
                    });
                channelRow.setAttribute('data-sponsor-channel', channelId);
                sponsorMenu.appendChild(channelRow);
            }
            var footer = document.createElement('div');
            footer.style.cssText = 'display:flex;flex-wrap:wrap;gap:8px;align-items:center;justify-content:space-between;margin-top:8px;padding-top:8px;' +
                'border-top:1px solid rgba(255,255,255,.12)';
            var reset = document.createElement('button');
            reset.type = 'button'; reset.textContent = locale.reset;
            reset.style.cssText = 'background:transparent;color:#aaa;border:0;padding:3px 0;font:inherit;cursor:pointer';
            reset.addEventListener('click', function () {
                sponsorBlockSettingsCache = defaultSponsorBlockSettings();
                saveSponsorBlockSettings(sponsorBlockSettingsCache);
                updateSponsorButton();
                buildSponsorMenu();
            });
            // SponsorBlock data is CC BY-NC-SA 4.0; the credit link is a license term.
            var credits = document.createElement('span');
            credits.style.cssText = 'display:inline-flex;flex-wrap:wrap;gap:10px';
            var credit = document.createElement('a');
            credit.href = 'https://sponsor.ajay.app/'; credit.target = '_blank'; credit.rel = 'noopener noreferrer';
            credit.textContent = locale.using; credit.style.cssText = 'color:#69a9ff;text-decoration:underline;text-underline-offset:2px';
            var donate = document.createElement('a');
            donate.href = 'https://sponsor.ajay.app/donate/'; donate.target = '_blank'; donate.rel = 'noopener noreferrer';
            donate.textContent = locale.donate; donate.style.cssText = 'color:#69a9ff;text-decoration:none';
            credits.appendChild(credit); credits.appendChild(donate);
            footer.appendChild(reset); footer.appendChild(credits); sponsorMenu.appendChild(footer);

        }

        function hideSponsorMenu() {
            sponsorMenu.style.display = 'none';
            sponsorBtn.setAttribute('aria-expanded', 'false');
        }

        sponsorBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            qualityMenu.style.display = 'none';
            if (sponsorMenu.style.display === 'none') {
                buildSponsorMenu();
                if (IS_IOS) {
                    showMobilePageOverlay(sponsorMenu, sponsorBtn, 700, 6);
                } else {
                    placeDesktopAnchoredMenu(sponsorMenu, { maxHeight: '65vh', gap: '6px' });
                }
                sponsorMenu.style.display = 'block';
                sponsorBtn.setAttribute('aria-expanded', 'true');
            } else {
                hideSponsorMenu();
            }
        });
        sponsorMenu.addEventListener('click', function (e) { e.stopPropagation(); });
        function onSponsorOutsideClick() { hideSponsorMenu(); }
        document.addEventListener('click', onSponsorOutsideClick);
        registerCleanup(function () {
            document.removeEventListener('click', onSponsorOutsideClick);
            removeMobilePageOverlay(sponsorMenu);
        });
        updateSponsorButton();
        sponsorWrap.appendChild(sponsorBtn); sponsorWrap.appendChild(sponsorMenu); servicesRow.appendChild(sponsorWrap);

        // PiP button is intentionally omitted — Safari's native controls
        // already provide PiP. Auto PiP handles automatic PiP entry.

        // Device-level "hide these controls" preference. While set, the
        // toolbar refuses to appear except while one of its own panels is
        // open (so the checkbox that unsets it stays reachable) or after a
        // deliberate double-tap / double-click reveal on the video.
        var toolbarUserHidden = isToolbarHidden();
        var toolbarRevealOverride = false;
        function anyToolbarPanelOpen() {
            var panels = [qualityMenu, sponsorMenu];
            return panels.some(function (p) {
                return p && p.style.display !== 'none' && p.style.display !== '';
            });
        }
        function toolbarSuppressed() {
            return toolbarUserHidden && !toolbarRevealOverride && !anyToolbarPanelOpen();
        }

        // WebKit's AutoHideController uses a four-second idle deadline and
        // suspends it during pointer interaction. Its shadow-tree visibility
        // is private, so mirror the public input and playback signals.
        var toolbarPointers = new Set();
        var nativeControlHover = false;
        function toolbarInteractionActive() {
            return toolbarPointers.size > 0 || nativeControlHover || video.seeking ||
                video.webkitCurrentPlaybackTargetIsWireless;
        }
        // Native controls do not expose their hit-test rectangles.
        // Treat the bottom control strip as native chrome.
        function overNativeControlStrip(x, y) {
            var rect = video.getBoundingClientRect();
            return x >= rect.left && x <= rect.right && y <= rect.bottom &&
                y >= rect.bottom - Math.min(64, rect.height / 3);
        }
        function bindNativeToolbarInteractions(show, schedule) {
            function down(event) {
                if (!player.contains(event.target)) return;
                toolbarPointers.add(event.pointerId);
                clearTimeout(toolbarTimer);
                if (event.pointerType === 'mouse') show();
            }
            function up(event) {
                if (toolbarPointers.delete(event.pointerId)) schedule();
            }
            function move(event) {
                if (event.pointerType !== 'mouse') return;
                var wasHovering = nativeControlHover;
                nativeControlHover = event.target === video && overNativeControlStrip(event.clientX, event.clientY);
                if (player.contains(event.target)) { show(); schedule(); }
                else if (wasHovering) schedule();
            }
            function leave(event) {
                nativeControlHover = false;
                toolbarPointers.delete(event.pointerId);
                schedule();
            }
            function reset() {
                toolbarPointers.clear();
                nativeControlHover = false;
                schedule();
            }
            function wirelessChanged() {
                if (video.webkitCurrentPlaybackTargetIsWireless) show();
                schedule();
            }
            document.addEventListener('pointerdown', down, true);
            document.addEventListener('pointerup', up, true);
            document.addEventListener('pointercancel', up, true);
            document.addEventListener('pointermove', move, true);
            player.addEventListener('pointerleave', leave);
            window.addEventListener('blur', reset);
            video.addEventListener('webkitpresentationmodechanged', reset);
            video.addEventListener('seeking', show);
            video.addEventListener('seeked', schedule);
            video.addEventListener('ended', show);
            video.addEventListener('webkitcurrentplaybacktargetiswirelesschanged', wirelessChanged);
            registerCleanup(function () {
                toolbarPointers.clear();
                document.removeEventListener('pointerdown', down, true);
                document.removeEventListener('pointerup', up, true);
                document.removeEventListener('pointercancel', up, true);
                document.removeEventListener('pointermove', move, true);
                player.removeEventListener('pointerleave', leave);
                window.removeEventListener('blur', reset);
                video.removeEventListener('webkitpresentationmodechanged', reset);
                video.removeEventListener('seeking', show);
                video.removeEventListener('seeked', schedule);
                video.removeEventListener('ended', show);
                video.removeEventListener('webkitcurrentplaybacktargetiswirelesschanged', wirelessChanged);
            });
        }

        if (IS_IOS) {
            // The mobile toolbar auto-hides a few seconds after playback
            // resumes and reappears on a tap to the video surface, mirroring
            // Safari's own control-chrome behavior. It stays visible while a
            // settings panel is open and while the video is paused. Native iOS
            // media controls occupy the bottom strip, but taps on the rest of
            // the video reach the touch-tap listener without mouse emulation.
            var toolbarTimer = null;
            var TOOLBAR_HIDE_DELAY = 4000;

            function showToolbar() {
                if (toolbarSuppressed()) return;
                toolbar.style.opacity = '1';
                toolbar.classList.remove('wblock-tc-toolbar-hidden');
                clearTimeout(toolbarTimer);
            }
            function hideToolbar(force) {
                // Never hide while a settings panel is open — the controls
                // that opened it must remain reachable to close it again.
                var panels = [qualityMenu, sponsorMenu];
                var anyOpen = panels.some(function (p) {
                    return p && p.style.display !== 'none' && p.style.display !== '';
                });
                if (anyOpen || (!force && !toolbarSuppressed() &&
                    (toolbarInteractionActive() || video.paused || video.ended))) { scheduleHideToolbar(); return; }
                toolbar.style.opacity = '0';
                toolbar.classList.add('wblock-tc-toolbar-hidden');
            }
            function scheduleHideToolbar() {
                clearTimeout(toolbarTimer);
                if (!toolbarUserHidden && (toolbarInteractionActive() || video.paused || video.ended)) return;
                toolbarTimer = setTimeout(hideToolbar, TOOLBAR_HIDE_DELAY);
            }

            function isToolbarVisible() {
                return toolbar.style.opacity === '1';
            }

            // Tap the video surface to toggle the toolbar. Safari's native
            // controls stay up while paused and taps on their own buttons never
            // hide them, so those taps only reveal; toggling on them would leave
            // every later tap inverted against the native controls.
            function onVideoTap(e) {
                var point = e.type === 'click' ? e : e.detail;
                var nativeChrome = video.paused || video.ended ||
                    overNativeControlStrip(point.clientX, point.clientY);
                if (isToolbarVisible() && !nativeChrome) {
                    hideToolbar(true);
                } else {
                    showToolbar();
                    if (!video.paused && !video.ended) { scheduleHideToolbar(); }
                }
            }
            video.addEventListener('click', onVideoTap);

            // Double-tap reveals (or re-hides) the toolbar while the hide
            // preference is on; single taps keep ignoring it.
            function onVideoReveal() {
                if (!toolbarUserHidden) return;
                toolbarRevealOverride = !toolbarRevealOverride;
                if (toolbarRevealOverride) {
                    showToolbar();
                    if (!video.paused && !video.ended) { scheduleHideToolbar(); }
                } else {
                    hideToolbar();
                }
            }
            video.addEventListener('dblclick', onVideoReveal);

            function onToolbarPref() {
                toolbarUserHidden = isToolbarHidden();
                toolbarRevealOverride = false;
                if (toolbarUserHidden) {
                    scheduleHideToolbar();
                } else {
                    showToolbar();
                    if (!video.paused && !video.ended) { scheduleHideToolbar(); }
                }
            }
            document.addEventListener('wblock-tc-toolbar-pref', onToolbarPref);

            function onNativeVideoTap(event) {
                if (event.detail.doubleTap && toolbarUserHidden) onVideoReveal();
                else onVideoTap(event);
            }
            video.addEventListener('wblock-tc-video-tap', onNativeVideoTap);

            // Keep visible while the toolbar itself is being touched.
            toolbar.addEventListener('touchstart', function () {
                showToolbar();
                if (!video.paused && !video.ended) { scheduleHideToolbar(); }
            });

            // Auto-hide shortly after playback starts; show again on pause.
            function onVideoPlay() { scheduleHideToolbar(); }
            function onVideoPause() { showToolbar(); }
            video.addEventListener('play', onVideoPlay);
            video.addEventListener('pause', onVideoPause);

            bindNativeToolbarInteractions(showToolbar, scheduleHideToolbar);

            // Initial state: visible if paused, auto-hide once playing. The
            // hide preference starts it hidden outright.
            if (toolbarUserHidden) {
                toolbar.style.opacity = '0';
                toolbar.classList.add('wblock-tc-toolbar-hidden');
            } else {
                showToolbar();
                if (!video.paused && !video.ended) { scheduleHideToolbar(); }
            }

            registerCleanup(function () {
                clearTimeout(toolbarTimer);
                video.removeEventListener('click', onVideoTap);
                video.removeEventListener('wblock-tc-video-tap', onNativeVideoTap);
                video.removeEventListener('dblclick', onVideoReveal);
                document.removeEventListener('wblock-tc-toolbar-pref', onToolbarPref);
                video.removeEventListener('play', onVideoPlay);
                video.removeEventListener('pause', onVideoPause);
            });
        } else {
            // Set a hidden baseline before applying the saved toolbar preference.
            toolbar.style.opacity = '0';
            toolbar.classList.add('wblock-tc-toolbar-hidden');

            var toolbarTimer = null;
            var TOOLBAR_HIDE_DELAY = 4000;
            var _isOverPlayer = false;
            var _isOverToolbar = false;
            function clearNativeControlHover() {
                nativeControlHover = false;
            }

            function desktopPanelOpen() {
                var panels = [qualityMenu, sponsorMenu];
                return panels.some(function (p) {
                    return p && p.style.display !== 'none' && p.style.display !== '';
                });
            }

            function pointOverPlayer(x, y) {
                var rect = player.getBoundingClientRect();
                if (x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom) {
                    return true;
                }
                var bar = toolbar.getBoundingClientRect();
                return x >= bar.left && x <= bar.right && y >= bar.top && y <= bar.bottom;
            }

            function showToolbar() {
                if (toolbarSuppressed()) return;
                toolbar.style.opacity = '1';
                toolbar.classList.remove('wblock-tc-toolbar-hidden');
                clearTimeout(toolbarTimer);
            }

            function hideToolbar() {
                if (!toolbarSuppressed() && (desktopPanelOpen() || _isOverToolbar || toolbarInteractionActive() || video.paused || video.ended)) {
                    showToolbar();
                    return;
                }
                toolbar.style.opacity = '0';
                toolbar.classList.add('wblock-tc-toolbar-hidden');
            }

            function scheduleHideToolbar() {
                if (!toolbarSuppressed() && (desktopPanelOpen() || _isOverToolbar || toolbarInteractionActive() || video.paused || video.ended)) {
                    showToolbar();
                    return;
                }
                clearTimeout(toolbarTimer);
                toolbarTimer = setTimeout(hideToolbar, TOOLBAR_HIDE_DELAY);
            }

            // Safari's native controls stay up while the pointer is over the
            // video and reappear on any movement after idle hide. The previous
            // enter-edge-only listener never showed the toolbar again if the
            // cursor was already inside the player when the timer fired.
            function onDocumentMouseMove(e) {
                var over = pointOverPlayer(e.clientX, e.clientY);
                if (over) {
                    _isOverPlayer = true;
                    showToolbar();
                    scheduleHideToolbar();
                    return;
                }
                if (_isOverPlayer || _isOverToolbar) {
                    _isOverPlayer = false;
                    if (!_isOverToolbar) {
                        clearNativeControlHover();
                        hideToolbar();
                    }
                }
            }
            // The video stops bubbling mouse events to protect native controls.
            document.addEventListener('mousemove', onDocumentMouseMove, true);
            document.addEventListener('mouseout', onDocumentMouseOut, true);

            function onPlayerMouseEnter() {
                _isOverPlayer = true;
                showToolbar();
                scheduleHideToolbar();
            }
            function onPlayerMouseLeave() {
                _isOverPlayer = false;
                if (!_isOverToolbar) {
                    clearNativeControlHover();
                    hideToolbar();
                }
            }
            function onDocumentMouseOut(e) {
                if (e.relatedTarget) return;
                _isOverPlayer = false;
                _isOverToolbar = false;
                clearNativeControlHover();
                hideToolbar();
            }
            player.addEventListener('mouseenter', onPlayerMouseEnter);
            player.addEventListener('mouseleave', onPlayerMouseLeave);

            toolbar.addEventListener('mouseenter', function () {
                _isOverToolbar = true;
                showToolbar();
            });

            toolbar.addEventListener('mouseleave', function () {
                _isOverToolbar = false;
                scheduleHideToolbar();
            });

            toolbar.addEventListener('focusin', function () {
                showToolbar();
            });

            function onVideoPlay() { scheduleHideToolbar(); }
            video.addEventListener('play', onVideoPlay);

            function onVideoPause() { showToolbar(); }
            video.addEventListener('pause', onVideoPause);

            // Double-click reveals (or re-hides) the toolbar while the hide
            // preference is on.
            function onVideoReveal() {
                if (!toolbarUserHidden) return;
                toolbarRevealOverride = !toolbarRevealOverride;
                if (toolbarRevealOverride) {
                    showToolbar();
                    scheduleHideToolbar();
                } else {
                    hideToolbar();
                }
            }
            video.addEventListener('dblclick', onVideoReveal);

            function onToolbarPref() {
                toolbarUserHidden = isToolbarHidden();
                toolbarRevealOverride = false;
                if (toolbarUserHidden) { scheduleHideToolbar(); }
            }
            document.addEventListener('wblock-tc-toolbar-pref', onToolbarPref);

            var presentationTimer = null;
            function onPresentationModeChange() {
                if (video.webkitPresentationMode === 'picture-in-picture') {
                    showToolbar();
                    clearTimeout(presentationTimer);
                    presentationTimer = setTimeout(hideToolbar, TOOLBAR_HIDE_DELAY);
                }
            }
            video.addEventListener('webkitpresentationmodechanged', onPresentationModeChange);

            bindNativeToolbarInteractions(showToolbar, scheduleHideToolbar);

            // Match the initially visible native controls without requiring movement.
            if (!toolbarUserHidden) {
                showToolbar();
                scheduleHideToolbar();
            }

            registerCleanup(function () {
                clearTimeout(toolbarTimer);
                clearTimeout(presentationTimer);
                document.removeEventListener('mousemove', onDocumentMouseMove, true);
                document.removeEventListener('mouseout', onDocumentMouseOut, true);
                video.removeEventListener('dblclick', onVideoReveal);
                document.removeEventListener('wblock-tc-toolbar-pref', onToolbarPref);
                player.removeEventListener('mouseenter', onPlayerMouseEnter);
                player.removeEventListener('mouseleave', onPlayerMouseLeave);
                video.removeEventListener('play', onVideoPlay);
                video.removeEventListener('pause', onVideoPause);
                video.removeEventListener('webkitpresentationmodechanged', onPresentationModeChange);
            });
        }

        // Show on CSS class toggle (for keyboard shortcuts)
        toolbar.classList.add('wblock-tc-toolbar-built');

        player.appendChild(toolbar);
        registerCleanup(function () {
            if (toolbar.parentNode) { toolbar.parentNode.removeChild(toolbar); }
        });
    }

    // ------------------------------------------------------------------
    // SPA navigation handling
    // ------------------------------------------------------------------

    var lastUrl = '';

    function onNavigate() {
        var player = findPlayer();
        var video = player && player.querySelector('video');
        var identity = youtubeVideoIdentity(player) || '';
        if (location.href === lastUrl && (!player ||
            (player.getAttribute(ATTR_CLEANED) === identity && activeVideo === video))) return;
        lastUrl = location.href;

        if (player) {
            player.removeAttribute(ATTR_CLEANED);
            // Never remove wblock-tc-native here. Keeping the native class on
            // the persistent player prevents YouTube chrome flashing while the
            // SPA swaps video/page data.
        }

        transformPlayer();
        setTimeout(transformPlayer, 500);
    }

    function watchNavigation() {
        document.addEventListener('yt-navigate-start', onNavigate, true);
        document.addEventListener('yt-navigate-finish', onNavigate, true);
        try {
            document.addEventListener('yt-page-data-updated', onNavigate, true);
        } catch (e) { /* ignore */ }
        window.addEventListener('popstate', onNavigate, true);
    }

    // ------------------------------------------------------------------
    // F hotkey routed to native fullscreen
    // ------------------------------------------------------------------

    // YouTube's own F shortcut fullscreens the #movie_player container. With
    // the player chrome hidden that just zooms the current inline layout,
    // while the native controls fullscreen button presents Safari's real
    // fullscreen player. Intercept F ahead of YouTube's document handlers
    // (capture phase) and drive the video element's native presentation
    // instead. Typing targets pass through untouched so search boxes and
    // comment fields still receive the keystroke.

    function isTypingTarget(target) {
        if (!target || target.nodeType !== 1) { return false; }
        if (target.isContentEditable) { return true; }
        var tag = target.tagName;
        return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT';
    }

    // Native fullscreen state as reported by the element's own events. The
    // webkitDisplayingFullscreen and webkitPresentationMode getters can lag
    // behind or stick after an exit, so a second F press kept asking for an
    // exit that had already happened and never re-entered. Once an event has
    // been observed for an element its events are authoritative.
    function onNativeFullscreenEvent(event) {
        var video = event.target;
        if (!video || video.tagName !== 'VIDEO') return;
        if (event.type === 'webkitbeginfullscreen') video._wblockNativeFullscreenState = true;
        else if (event.type === 'webkitendfullscreen') video._wblockNativeFullscreenState = false;
        else video._wblockNativeFullscreenState = video.webkitPresentationMode === 'fullscreen';
    }

    function videoInNativeFullscreen(video) {
        if (typeof video._wblockNativeFullscreenState === 'boolean') return video._wblockNativeFullscreenState;
        return video.webkitPresentationMode === 'fullscreen' || video.webkitDisplayingFullscreen === true;
    }

    function enterNativeFullscreen(video, useElementApi) {
        if (!useElementApi && typeof video.webkitSupportsPresentationMode === 'function' &&
            video.webkitSupportsPresentationMode('fullscreen') &&
            typeof video.webkitSetPresentationMode === 'function') {
            video.webkitSetPresentationMode('fullscreen');
            return;
        }
        if (typeof video.webkitEnterFullscreen === 'function') video.webkitEnterFullscreen();
    }

    function exitNativeFullscreen(video, useElementApi) {
        if (!useElementApi && typeof video.webkitSetPresentationMode === 'function' &&
            (video.webkitPresentationMode === 'fullscreen' ||
                typeof video.webkitSupportsPresentationMode === 'function')) {
            video.webkitSetPresentationMode('inline');
            return;
        }
        if (typeof video.webkitExitFullscreen === 'function') video.webkitExitFullscreen();
    }

    var fullscreenVerifyTimer = null;

    function toggleNativeFullscreen(video) {
        try {
            var fullscreenElement = document.fullscreenElement || document.webkitFullscreenElement ||
                document.webkitCurrentFullScreenElement;
            if (fullscreenElement && fullscreenElement !== video && !videoInNativeFullscreen(video)) {
                // YouTube's own container fullscreen is active; leave it so the
                // next press can enter the native player.
                if (typeof document.exitFullscreen === 'function') { document.exitFullscreen(); }
                else if (typeof document.webkitExitFullscreen === 'function') { document.webkitExitFullscreen(); }
                return;
            }
            var wasFullscreen = videoInNativeFullscreen(video);
            if (wasFullscreen) exitNativeFullscreen(video, false);
            else enterNativeFullscreen(video, false);
            // If the preferred API silently did nothing (WebKit rejects a
            // presentation-mode change in some transitional states), retry
            // through the element API while the key press still counts as a
            // user gesture.
            if (fullscreenVerifyTimer !== null) clearTimeout(fullscreenVerifyTimer);
            fullscreenVerifyTimer = setTimeout(function () {
                fullscreenVerifyTimer = null;
                if (!video.isConnected || videoInNativeFullscreen(video) !== wasFullscreen) return;
                try {
                    if (wasFullscreen) exitNativeFullscreen(video, true);
                    else enterNativeFullscreen(video, true);
                } catch (e) { /* ignore */ }
            }, 350);
        } catch (e) { /* ignore */ }
    }

    function nativeSubtitleTracks(video) {
        var result = [];
        var tracks = video && video.textTracks;
        if (!tracks) return result;
        for (var i = 0; i < tracks.length; i++) {
            if (tracks[i].kind === 'subtitles' || tracks[i].kind === 'captions') result.push(tracks[i]);
        }
        return result;
    }

    function preferredSubtitleTrack(tracks) {
        var languages = navigator.languages && navigator.languages.length ? navigator.languages : [navigator.language || 'en'];
        for (var l = 0; l < languages.length; l++) {
            var wanted = String(languages[l] || '').toLowerCase();
            var base = wanted.split('-')[0];
            for (var i = 0; i < tracks.length; i++) {
                var language = String(tracks[i].language || '').toLowerCase();
                if (language === wanted || language.split('-')[0] === base) return tracks[i];
            }
        }
        return tracks[0];
    }

    function toggleNativeSubtitles(video) {
        var tracks = nativeSubtitleTracks(video);
        if (!tracks.length) return false;
        var showing = null;
        for (var i = 0; i < tracks.length; i++) {
            if (tracks[i].mode === 'showing') { showing = tracks[i]; break; }
        }
        if (showing) {
            video._wblockLastSubtitleTrack = showing;
            for (var j = 0; j < tracks.length; j++) {
                try { tracks[j].mode = 'disabled'; } catch (e) { /* ignore */ }
            }
            return true;
        }
        var last = video._wblockLastSubtitleTrack;
        var pick = last && tracks.indexOf(last) !== -1 ? last : preferredSubtitleTrack(tracks);
        for (var k = 0; k < tracks.length; k++) {
            try { tracks[k].mode = tracks[k] === pick ? 'showing' : 'disabled'; } catch (e) { /* ignore */ }
        }
        return true;
    }

    function onCaptionHotkey(event) {
        if (event.ctrlKey || event.metaKey || event.altKey) { return; }
        if (event.key !== 'c' && event.key !== 'C') { return; }
        var video = activeVideo;
        if (!video || !video.isConnected) { return; }
        if (isTypingTarget(event.target)) { return; }
        // YouTube's own C shortcut turns on its DOM caption overlay, which
        // the native player hides and which would double any Safari
        // subtitle track. Route the key to the native tracks instead.
        event.preventDefault();
        event.stopImmediatePropagation();
        if (!event.repeat) { toggleNativeSubtitles(video); }
    }

    function onFullscreenHotkey(event) {
        if (event.ctrlKey || event.metaKey || event.altKey) { return; }
        if (event.key !== 'f' && event.key !== 'F') { return; }
        var video = activeVideo;
        if (!video || !video.isConnected) { return; }
        if (isTypingTarget(event.target)) { return; }
        // Consume key repeats too so YouTube never sees a held F, but only
        // toggle once per press.
        event.preventDefault();
        event.stopImmediatePropagation();
        if (!event.repeat) { toggleNativeFullscreen(video); }
    }

    // ------------------------------------------------------------------
    // Pinch-out routed to native fullscreen
    // ------------------------------------------------------------------

    // Mobile YouTube turns a two-finger spread on the player into its own
    // container fullscreen, which with the chrome hidden just scales the
    // inline layout and leaves the page zoomed (#631). Its handlers live on
    // the document in the capture phase, so ours must too: registered at
    // document-start they run first, swallow the gesture, and on release
    // present Safari's real fullscreen player the way the F key does.
    var pinchFullscreenRequests = 0;

    function setupPinchFullscreen(player, video) {
        if (!IS_IOS || !player) return;
        var startDistance = 0;
        var armed = false;
        var active = false;

        function distance(touches) {
            var dx = touches[0].clientX - touches[1].clientX;
            var dy = touches[0].clientY - touches[1].clientY;
            return Math.sqrt(dx * dx + dy * dy);
        }

        function insidePlayer(event) {
            var target = event.target;
            return target && target.nodeType === 1 && player.contains(target);
        }

        function onTouchStart(event) {
            if (!event.touches || event.touches.length !== 2 || !insidePlayer(event)) return;
            active = true;
            armed = false;
            startDistance = distance(event.touches);
            event.stopImmediatePropagation();
        }

        function onTouchMove(event) {
            if (!active) return;
            if (event.touches && event.touches.length === 2 && startDistance > 0 &&
                distance(event.touches) > startDistance * 1.25) {
                armed = true;
            }
            // Non-passive: this is what keeps Safari from zooming the page.
            if (event.cancelable) event.preventDefault();
            event.stopImmediatePropagation();
        }

        function onTouchEnd(event) {
            if (!active) return;
            event.stopImmediatePropagation();
            if (event.touches && event.touches.length) return;
            active = false;
            if (!armed) return;
            armed = false;
            pinchFullscreenRequests++;
            // touchend carries user activation, which the presentation APIs need.
            if (video.isConnected && !videoInNativeFullscreen(video)) toggleNativeFullscreen(video);
        }

        function onGesture(event) {
            if (!insidePlayer(event)) return;
            if (event.cancelable) event.preventDefault();
            event.stopImmediatePropagation();
        }

        var options = { capture: true, passive: false };
        document.addEventListener('touchstart', onTouchStart, options);
        document.addEventListener('touchmove', onTouchMove, options);
        document.addEventListener('touchend', onTouchEnd, options);
        document.addEventListener('touchcancel', onTouchEnd, options);
        document.addEventListener('gesturestart', onGesture, options);
        document.addEventListener('gesturechange', onGesture, options);
        document.addEventListener('gestureend', onGesture, options);
        registerCleanup(function () {
            document.removeEventListener('touchstart', onTouchStart, options);
            document.removeEventListener('touchmove', onTouchMove, options);
            document.removeEventListener('touchend', onTouchEnd, options);
            document.removeEventListener('touchcancel', onTouchEnd, options);
            document.removeEventListener('gesturestart', onGesture, options);
            document.removeEventListener('gesturechange', onGesture, options);
            document.removeEventListener('gestureend', onGesture, options);
        });
    }

    function setupFullscreenHotkey() {
        document.addEventListener('keydown', onFullscreenHotkey, true);
        document.addEventListener('keydown', onCaptionHotkey, true);
        // Capture phase: these events do not bubble.
        document.addEventListener('webkitbeginfullscreen', onNativeFullscreenEvent, true);
        document.addEventListener('webkitendfullscreen', onNativeFullscreenEvent, true);
        document.addEventListener('webkitpresentationmodechanged', onNativeFullscreenEvent, true);
    }

    // ------------------------------------------------------------------
    // Boot
    // ------------------------------------------------------------------

    var documentPlayerObserver = null;

    function nodeMayContainPlayer(node) {
        if (!node || node.nodeType !== 1) { return false; }
        try {
            // YouTube may move the active player into a preview; release it then.
            if (isHoverPreviewPlayer(node)) { return !!(activeVideo && node.contains(activeVideo)); }
            if (node.tagName === 'VIDEO' || node.id === 'movie_player' ||
                node.id === 'player-container' ||
                node.matches('.html5-video-player, ytd-player')) {
                return true;
            }
            return !!node.querySelector('video, #movie_player, .html5-video-player, ytd-player, #player-container');
        } catch (e) { return false; }
    }

    function classMutationOnlyChangesOurClasses(record) {
        if (!record || record.type !== 'attributes' || record.attributeName !== 'class') return false;
        function withoutTubeClasses(value) {
            return String(value || '').split(/\s+/).filter(function (name) {
                return name && name.indexOf('wblock-tc-') !== 0;
            }).join(' ');
        }
        return withoutTubeClasses(record.oldValue) === withoutTubeClasses(record.target.className);
    }

    function observeDocumentForPlayer() {
        if (documentPlayerObserver || typeof MutationObserver === 'undefined') { return; }
        documentPlayerObserver = new MutationObserver(function (records) {
            // The first parser mutation creates <html>; install anti-flash CSS
            // then even when the userscript itself ran before documentElement.
            injectStyles();
            var relevant = false;
            for (var i = 0; i < records.length && !relevant; i++) {
                var record = records[i];
                if (classMutationOnlyChangesOurClasses(record)) continue;
                if (nodeMayContainPlayer(record.target)) { relevant = true; break; }
                for (var j = 0; j < record.addedNodes.length; j++) {
                    if (nodeMayContainPlayer(record.addedNodes[j])) {
                        relevant = true;
                        break;
                    }
                }
            }
            // MutationObserver runs before rendering. Transform now—no polling
            // interval or debounce—so YouTube chrome never reaches next paint.
            if (relevant) { transformPlayer(); }
        });
        try {
            documentPlayerObserver.observe(document, {
                childList: true,
                subtree: true,
                attributes: true,
                attributeFilter: ['id', 'class'],
                attributeOldValue: true
            });
        } catch (e) { /* ignore */ }
    }

    function boot() {
        if (featureEnabled('backgroundPlayback')) enableBackgroundPlayback();
        if (IS_YOUTUBE_MUSIC) {
            setupYouTubeMusic();
            return;
        }
        observeDocumentForPlayer();
        injectStyles();
        lastUrl = location.href;
        watchNavigation();
        setupFullscreenHotkey();
        transformPlayer();

        // Recovery scans only; normal startup is handled pre-paint above.
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', transformPlayer, { once: true });
            window.addEventListener('load', transformPlayer, { once: true });
        }
    }

    boot();

    // Expose debug helpers on window for console testing
    try {
        window.__wblockTubeDebug = {
            getAvailableQualities: getAvailableQualities,
            getCurrentQuality: getCurrentQuality,
            setQuality: setQuality,
            applyPreferredQuality: applyPreferredQuality,
            getPreferredQuality: getPreferredQuality,
            setPreferredQuality: setPreferredQuality,
            isToolbarHidden: isToolbarHidden,
            pipCaptionPumpTicks: function () { return pipCaptionPumpTicks; },
            pinchFullscreenRequests: function () { return pinchFullscreenRequests; },
            setToolbarHidden: setToolbarHidden,
            music: {
                getAudioQuality: getMusicAudioQuality,
                applyAudioQuality: applyMusicAudioQuality,
                state: function () { return musicState; }
            },
            previewSponsorNotice: function () {
                var p = findPlayer();
                if (!p || !activeVideo) return 'no player';
                showSponsorBlockNotice(p, activeVideo, { category: 'sponsor', segment: [0, 5], UUID: 'preview' }, {}, 'undo');
                return 'ok';
            },
            QUALITY_LABELS: QUALITY_LABELS,
            getPlayer: findPlayer,
            getChapters: extractChapters,
            applyChapters: function () { applyChapters(activeVideo); },
            inspectPlayer: function () {
                var p = findPlayer();
                if (!p) return 'no player';
                var methods = [];
                for (var k in p) {
                    if (typeof p[k] === 'function' &&
                        (k.indexOf('playback') !== -1 || k.indexOf('Quality') !== -1)) {
                        methods.push(k);
                    }
                }
                return {
                    methods: methods,
                    hasGetAvailableQualityLevels: typeof p.getAvailableQualityLevels === 'function',
                    hasGetAvailableQualityData: typeof p.getAvailableQualityData === 'function',
                    hasSetPlaybackQualityRange: typeof p.setPlaybackQualityRange === 'function',
                    hasSetPlaybackQuality: typeof p.setPlaybackQuality === 'function',
                    hasGetPlaybackQuality: typeof p.getPlaybackQuality === 'function',
                    levels: typeof p.getAvailableQualityLevels === 'function' ? p.getAvailableQualityLevels() : 'N/A',
                    qualityData: typeof p.getAvailableQualityData === 'function' ? p.getAvailableQualityData() : 'N/A',
                    current: typeof p.getPlaybackQuality === 'function' ? p.getPlaybackQuality() : 'N/A'
                };
            }
        };
        log('debug helpers exposed at window.__wblockTubeDebug');
    } catch (e) { /* ignore */ }
})();
(function () {
  if (typeof __wblockTubeCleanerDeArrow !== "object" || !__wblockTubeCleanerDeArrow.enabled || window.__wblockDeArrowDebug) return;
  const __wblockDeArrowSettings = __wblockTubeCleanerDeArrow;
(function () {
    'use strict';
    if (window.top !== window.self || window.__wblockDeArrowDebug) return;
    function log() {
        if (window.console && console.debug) {
            console.debug.apply(console, ['[wBlock DeArrow]'].concat(Array.prototype.slice.call(arguments)));
        }
    }

    // DeArrow
    //
    // DeArrow stores voted replacement titles and thumbnail timestamps on the
    // SponsorBlock server. The current watch video uses its four-character
    // SHA-256 bucket so its exact id is filtered locally. Visible feed cards use
    // DeArrow's compact single-video endpoint, matching the official extension,
    // and are cached for the page session. An optional fallback uses DeArrow's
    // server-provided random timestamp when a video has no accepted thumbnail.

    var DEARROW_API = 'https://sponsor.ajay.app/api/branding';
    // Stand-in video length, in seconds, for branding responses that leave
    // videoDuration null. Only scales the random fraction; any positive value
    // yields a valid frame.
    var DEARROW_FALLBACK_DURATION = 300;
    var DEARROW_THUMBNAIL_API = 'https://dearrow-thumb.ajay.app/api/v1/getThumbnail';
    var DEARROW_CARD_SELECTOR = [
        'ytd-rich-grid-media', 'ytd-video-renderer', 'ytd-compact-video-renderer',
        'ytd-grid-video-renderer', 'ytd-playlist-video-renderer', 'yt-lockup-view-model',
        'ytm-video-with-context-renderer', 'ytm-compact-video-renderer',
        'ytm-rich-item-renderer', 'ytm-shorts-lockup-view-model'
    ].join(',');
    var DEARROW_WATCH_TITLE_SELECTOR = [
        'ytd-watch-metadata h1 yt-formatted-string',
        '#watch-metadata h1 yt-formatted-string',
        'ytm-slim-video-metadata-section-renderer h1',
        'ytm-watch-metadata h1',
        'h1.title yt-formatted-string'
    ].join(',');
    var deArrowBrandingCache = {};
    var deArrowBrandingCacheOrder = [];
    var deArrowActiveRequests = {};
    var deArrowActiveRequestCount = 0;
    var deArrowIntersectionObserver = null;
    var deArrowPendingScanRoots = [];
    var deArrowScanScheduled = false;

    // The app prepends standalone DeArrow preferences; other managers use the defaults.
    function loadDeArrowSettings() {
        var settings = {
            enabled: true,
            replaceTitles: true,
            replaceThumbnails: true,
            randomThumbnails: false,
            showOriginalOnHover: true,
            originalThumbnailChannels: []
        };
        var injected = typeof __wblockDeArrowSettings === 'object' ? __wblockDeArrowSettings : null;
        if (!injected) return settings;
        for (var key in settings) {
            if (typeof injected[key] === 'boolean') settings[key] = injected[key];
        }
        if (Array.isArray(injected.originalThumbnailChannels)) {
            settings.originalThumbnailChannels = injected.originalThumbnailChannels.map(normalizedDeArrowChannel).filter(Boolean);
        }
        return settings;
    }

    function normalizedDeArrowChannel(value) {
        if (typeof value !== 'string') return null;
        var candidate = value.trim().normalize('NFC');
        if (/^UC[A-Za-z0-9_-]{22}$/.test(candidate)) return candidate;
        if (/^@[\p{L}\p{N}\p{M}._\-·]{1,100}$/u.test(candidate)) return candidate.toLowerCase();
        try {
            var url = new URL(candidate.indexOf('/') === 0 ? candidate :
                (candidate.indexOf('://') >= 0 ? candidate : 'https://' + candidate), 'https://www.youtube.com');
            if (!/^https?:$/.test(url.protocol) ||
                ['youtube.com', 'www.youtube.com', 'm.youtube.com', 'music.youtube.com'].indexOf(url.hostname) < 0) return null;
            var parts = url.pathname.split('/').filter(Boolean).map(decodeURIComponent);
            candidate = parts[0] === 'channel' ? parts[1] : parts[0];
            if (typeof candidate !== 'string') return null;
            candidate = candidate.normalize('NFC');
            if (/^UC[A-Za-z0-9_-]{22}$/.test(candidate)) return candidate;
            if (/^@[\p{L}\p{N}\p{M}._\-·]{1,100}$/u.test(candidate)) return candidate.toLowerCase();
        } catch (e) { /* Invalid channel entries do not match. */ }
        return null;
    }

    function keepOriginalDeArrowThumbnail(card) {
        var channels = loadDeArrowSettings().originalThumbnailChannels;
        if (!channels.length || !card) return false;
        function matches(value) {
            var normalized = normalizedDeArrowChannel(value);
            return normalized !== null && channels.indexOf(normalized) >= 0;
        }
        if (matches(card.getAttribute('data-channel-id'))) return true;
        var owner = card.querySelector('#channel-name a[href], ytd-channel-name a[href], #byline-container a[href]');
        if (!owner) owner = card.querySelector('a[href^="/@"], a[href^="/channel/"], a[href*="youtube.com/@"], a[href*="youtube.com/channel/"]');
        if (owner && matches(owner.getAttribute('href'))) return true;

        // Polymer and the newer lockup renderer expose channel IDs in owner metadata.
        var seen = new WeakSet();
        var budget = 256;
        function visit(value, depth, ownerContext) {
            if (!value || typeof value !== 'object' || depth > 12 || budget-- <= 0 || seen.has(value)) return false;
            seen.add(value);
            var keys = Object.keys(value);
            for (var i = 0; i < keys.length; i++) {
                var key = keys[i];
                var item = value[key];
                if ((key === 'channelId' || (ownerContext &&
                    ['browseId', 'canonicalBaseUrl', 'url', 'channelUrl'].indexOf(key) >= 0)) && matches(item)) return true;
                var ownsChannel = ownerContext || ['ownerText', 'shortBylineText', 'longBylineText',
                    'owner', 'channelName', 'channelEndpoint', 'contentMetadataViewModel'].indexOf(key) >= 0;
                if (visit(item, depth + 1, ownsChannel)) return true;
            }
            return false;
        }
        try {
            return visit(card.data, 0, false) || visit(card.__data && card.__data.data, 0, false);
        } catch (e) { return false; }
    }

    function cachedDeArrowBranding(videoId) {
        return Object.prototype.hasOwnProperty.call(deArrowBrandingCache, videoId) ?
            deArrowBrandingCache[videoId] : undefined;
    }

    function cacheDeArrowBranding(videoId, branding) {
        if (!Object.prototype.hasOwnProperty.call(deArrowBrandingCache, videoId)) {
            deArrowBrandingCacheOrder.push(videoId);
        }
        deArrowBrandingCache[videoId] = branding;
        while (deArrowBrandingCacheOrder.length > 100) {
            delete deArrowBrandingCache[deArrowBrandingCacheOrder.shift()];
        }
    }

    function normalizeDeArrowBranding(value) {
        if (!value || typeof value !== 'object') return null;
        return {
            titles: Array.isArray(value.titles) ? value.titles : [],
            thumbnails: Array.isArray(value.thumbnails) ? value.thumbnails : [],
            videoDuration: isFinite(value.videoDuration) && Number(value.videoDuration) > 0 ? Number(value.videoDuration) : null,
            randomTime: value.randomTime !== null && value.randomTime !== undefined && isFinite(value.randomTime) &&
                Number(value.randomTime) >= 0 ? Number(value.randomTime) : null
        };
    }

    function fetchDeArrowBranding(videoId, hashLookup) {
        var cached = cachedDeArrowBranding(videoId);
        if (cached !== undefined) return Promise.resolve(cached);
        if (deArrowActiveRequests[videoId]) return deArrowActiveRequests[videoId];
        if (!window.fetch) return Promise.resolve(null);
        deArrowActiveRequestCount++;

        var request;
        if (hashLookup && window.crypto && crypto.subtle && window.TextEncoder) {
            request = crypto.subtle.digest('SHA-256', new TextEncoder().encode(videoId)).then(function (buffer) {
                var bytes = new Uint8Array(buffer);
                var hash = '';
                for (var i = 0; i < bytes.length; i++) hash += ('0' + bytes[i].toString(16)).slice(-2);
                return fetch(DEARROW_API + '/' + hash.slice(0, 4) + '?fetchAll=true', { referrerPolicy: 'no-referrer' });
            }).then(function (response) {
                if (!response.ok && response.status !== 404) throw new Error('DeArrow HTTP ' + response.status);
                return response.json();
            }).then(function (bucket) {
                return normalizeDeArrowBranding(bucket && bucket[videoId]);
            });
        } else {
            request = fetch(DEARROW_API + '?videoID=' + encodeURIComponent(videoId) + '&fetchAll=true', {
                referrerPolicy: 'no-referrer'
            }).then(function (response) {
                if (!response.ok && response.status !== 404) throw new Error('DeArrow HTTP ' + response.status);
                return response.json();
            }).then(normalizeDeArrowBranding);
        }
        deArrowActiveRequests[videoId] = request.then(function (branding) {
            cacheDeArrowBranding(videoId, branding);
            delete deArrowActiveRequests[videoId];
            return branding;
        }, function (error) {
            delete deArrowActiveRequests[videoId];
            log('DeArrow unavailable', error);
            return null;
        });
        return deArrowActiveRequests[videoId];
    }

    function deArrowAcceptedTitle(branding) {
        var title = branding && branding.titles[0];
        // A word-leading ">" preserves capitalization; it is not display text.
        return title && title.original !== true && typeof title.title === 'string' && title.title.trim() &&
            (title.locked || Number(title.votes) >= 0) ? title.title.replace(/(^|\s)>(\S)/g, '$1$2').replace(/‹/g, '<').trim() : null;
    }

    function deArrowAcceptedThumbnail(branding) {
        var thumbnail = branding && branding.thumbnails[0];
        return thumbnail && thumbnail.original !== true && isFinite(thumbnail.timestamp) && thumbnail.timestamp >= 0 &&
            (thumbnail.locked || Number(thumbnail.votes) >= 0) ? Number(thumbnail.timestamp) : null;
    }

    // DeArrow supplies a stable randomTime when it has one. The deterministic
    // fallback avoids a thumbnail changing on every scan for older responses.
    // The branding endpoint reports videoDuration as null for many videos, so
    // the fraction is scaled by a fixed length when the server does not say.
    function deArrowRandomThumbnailTimestamp(videoId, branding) {
        var duration = Number(branding && branding.videoDuration);
        if (!isFinite(duration) || duration <= 0) duration = DEARROW_FALLBACK_DURATION;
        var fraction = branding && branding.randomTime;
        if (!isFinite(fraction) || fraction < 0) {
            var hash = 2166136261;
            for (var i = 0; i < videoId.length; i++) {
                hash ^= videoId.charCodeAt(i);
                hash = Math.imul(hash, 16777619);
            }
            fraction = (hash >>> 0) / 4294967296;
        }
        // Match DeArrow's policy of keeping fallback frames out of the ending.
        fraction = Math.min(Math.max(Number(fraction), 0), 0.9);
        return fraction * duration;
    }

    function deArrowVideoIdFromUrl(value) {
        try {
            var url = new URL(value, location.href);
            var id = url.searchParams.get('v');
            if (!id) {
                var match = url.pathname.match(/^\/(?:shorts|embed)\/([A-Za-z0-9_-]{11})/);
                id = match && match[1];
            }
            return id && /^[A-Za-z0-9_-]{11}$/.test(id) ? id : null;
        } catch (e) { return null; }
    }

    function deArrowCardVideoId(card) {
        var direct = card.getAttribute('data-video-id');
        if (direct && /^[A-Za-z0-9_-]{11}$/.test(direct)) return direct;
        var links = card.querySelectorAll('a[href], [href]');
        for (var i = 0; i < links.length; i++) {
            var id = deArrowVideoIdFromUrl(links[i].getAttribute('href'));
            if (id) return id;
        }
        return null;
    }

    function findDeArrowCardTitle(card) {
        var selectors = [
            '#video-title yt-formatted-string', 'yt-formatted-string#video-title',
            'a#video-title-link yt-formatted-string', 'a#video-title-link', 'a#video-title',
            '.yt-lockup-metadata-view-model__title span', '.yt-lockup-metadata-view-model__title',
            '.media-item-headline', 'h3 a[href]'
        ];
        for (var i = 0; i < selectors.length; i++) {
            var element = card.querySelector(selectors[i]);
            if (element) return element;
        }
        return null;
    }

    function findDeArrowCardThumbnail(card, videoId) {
        var links = card.querySelectorAll('a[href]');
        for (var i = 0; i < links.length; i++) {
            if (deArrowVideoIdFromUrl(links[i].getAttribute('href')) === videoId) {
                var image = links[i].querySelector('img');
                if (image) return image;
            }
        }
        return card.querySelector('#thumbnail img, ytm-thumbnail-cover img, img.yt-core-image');
    }

    function applyDeArrowTitleElement(element, customTitle) {
        if (!element) return;
        var saved = element._wblockDeArrowTextNodes || new WeakMap();
        element._wblockDeArrowTextNodes = saved;
        element._wblockDeArrowCustomText = customTitle;
        element.setAttribute('data-wblock-dearrow-title', '');
        // YouTube retains references to these nodes across SPA renders. Replacing
        // their parent textContent strands our title when YouTube removes its runs.
        var walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
        var node;
        var first = true;
        while ((node = walker.nextNode())) {
            var record = saved.get(node);
            if (!record || node.data !== record.applied) record = { original: node.data };
            var value = element._wblockDeArrowShowingOriginal ? record.original : (first ? customTitle : '');
            if (node.data !== value) node.data = value;
            record.applied = value;
            saved.set(node, record);
            first = false;
        }
    }

    function restoreDeArrowTitleElement(element) {
        if (!element || !element._wblockDeArrowTextNodes) return;
        var walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
        var node;
        while ((node = walker.nextNode())) {
            var record = element._wblockDeArrowTextNodes.get(node);
            if (record && node.data === record.applied && node.data !== record.original) node.data = record.original;
        }
        delete element._wblockDeArrowTextNodes;
        delete element._wblockDeArrowCustomText;
        delete element._wblockDeArrowShowingOriginal;
        element.removeAttribute('data-wblock-dearrow-title');
    }

    function restoreDeArrowAttribute(element, name, value) {
        if (value === null || value === undefined) element.removeAttribute(name);
        else element.setAttribute(name, value);
    }

    function deArrowThumbnailUrl(videoId, timestamp) {
        return DEARROW_THUMBNAIL_API + '?videoID=' + encodeURIComponent(videoId) +
            '&time=' + encodeURIComponent(String(timestamp));
    }

    // The thumbnail server may answer with a frame from a different time than
    // the one requested and reports the time it used in X-Timestamp. The API
    // docs require comparing that header with the branding timestamp and
    // requesting once more at the server's time when they differ, so the image
    // is fetched here rather than assigned straight to the element's src.
    function fetchDeArrowThumbnail(videoId, timestamp, retried) {
        var url = deArrowThumbnailUrl(videoId, timestamp);
        if (!window.fetch || !window.URL || typeof URL.createObjectURL !== 'function') return Promise.resolve(null);
        return fetch(url, { referrerPolicy: 'no-referrer' }).then(function (response) {
            if (response.status !== 200) {
                throw new Error('DeArrow thumbnail HTTP ' + response.status + ' ' +
                    (response.headers.get('X-Failure-Reason') || ''));
            }
            var served = parseFloat(response.headers.get('X-Timestamp'));
            if (!retried && isFinite(served) && served >= 0 && Math.abs(served - timestamp) > 0.001) {
                log('DeArrow thumbnail served at', served, 'instead of', timestamp);
                return fetchDeArrowThumbnail(videoId, served, true);
            }
            return response.blob().then(function (blob) {
                return { url: url, objectUrl: URL.createObjectURL(blob) };
            });
        }).catch(function (error) {
            log('DeArrow thumbnail unavailable', error);
            return null;
        });
    }

    function releaseDeArrowThumbnail(element) {
        var src = element._wblockDeArrowCustomSrc;
        if (src && src.indexOf('blob:') === 0) {
            try { URL.revokeObjectURL(src); } catch (e) { /* ignore */ }
        }
        delete element._wblockDeArrowCustomSrc;
        delete element._wblockDeArrowRequestedUrl;
        delete element._wblockDeArrowThumbnailFailed;
    }

    function showDeArrowThumbnail(element) {
        if (!element._wblockDeArrowCustomSrc) return;
        element.removeAttribute('srcset');
        element.setAttribute('referrerpolicy', 'no-referrer');
        if (element.getAttribute('src') !== element._wblockDeArrowCustomSrc) {
            element.setAttribute('src', element._wblockDeArrowCustomSrc);
        }
    }

    function applyDeArrowThumbnailElement(element, videoId, timestamp, card) {
        if (!element) return;
        var url = deArrowThumbnailUrl(videoId, timestamp);
        var currentSrc = element.getAttribute('src');
        if (element._wblockDeArrowOriginalSrc === undefined) {
            element._wblockDeArrowOriginalSrc = currentSrc;
            element._wblockDeArrowOriginalSrcset = element.getAttribute('srcset');
            element._wblockDeArrowOriginalReferrerPolicy = element.getAttribute('referrerpolicy');
        } else if (!element._wblockDeArrowShowingOriginal && currentSrc !== element._wblockDeArrowCustomSrc &&
            currentSrc !== element._wblockDeArrowOriginalSrc) {
            // YouTube recycles card image elements as the feed changes. Preserve
            // its newly assigned original before applying the cached thumbnail.
            element._wblockDeArrowOriginalSrc = currentSrc;
            element._wblockDeArrowOriginalSrcset = element.getAttribute('srcset');
            element._wblockDeArrowOriginalReferrerPolicy = element.getAttribute('referrerpolicy');
            releaseDeArrowThumbnail(element);
        }
        if (!element.hasAttribute('data-wblock-dearrow-thumbnail')) element.setAttribute('data-wblock-dearrow-thumbnail', '');
        if (element._wblockDeArrowThumbnailFailed === url || element._wblockDeArrowShowingOriginal) return;
        if (!element._wblockDeArrowErrorHooked) {
            element._wblockDeArrowErrorHooked = true;
            element.addEventListener('error', function () {
                if (!element._wblockDeArrowCustomSrc || element.getAttribute('src') !== element._wblockDeArrowCustomSrc) return;
                var failedUrl = element._wblockDeArrowRequestedUrl;
                releaseDeArrowThumbnail(element);
                element._wblockDeArrowThumbnailFailed = failedUrl;
                restoreDeArrowAttribute(element, 'src', element._wblockDeArrowOriginalSrc);
                restoreDeArrowAttribute(element, 'srcset', element._wblockDeArrowOriginalSrcset);
                restoreDeArrowAttribute(element, 'referrerpolicy', element._wblockDeArrowOriginalReferrerPolicy);
            });
        }
        if (element._wblockDeArrowRequestedUrl === url) {
            showDeArrowThumbnail(element);
            return;
        }
        releaseDeArrowThumbnail(element);
        element._wblockDeArrowRequestedUrl = url;
        fetchDeArrowThumbnail(videoId, timestamp, false).then(function (result) {
            if (element._wblockDeArrowRequestedUrl !== url || !card.isConnected ||
                deArrowCardVideoId(card) !== videoId || keepOriginalDeArrowThumbnail(card)) {
                if (element._wblockDeArrowRequestedUrl === url) restoreDeArrowThumbnailElement(element);
                if (result) { try { URL.revokeObjectURL(result.objectUrl); } catch (e) { /* ignore */ } }
                return;
            }
            if (!result) {
                // The original YouTube thumbnail was never replaced, so it stays.
                element._wblockDeArrowThumbnailFailed = url;
                return;
            }
            element._wblockDeArrowCustomSrc = result.objectUrl;
            element.setAttribute('data-wblock-dearrow-thumbnail', result.url);
            if (!element._wblockDeArrowShowingOriginal) showDeArrowThumbnail(element);
        });
    }

    function restoreDeArrowThumbnailElement(element) {
        if (!element || element._wblockDeArrowOriginalSrc === undefined) return;
        var currentSrc = element.getAttribute('src');
        if (currentSrc === element._wblockDeArrowCustomSrc || currentSrc === element._wblockDeArrowOriginalSrc) {
            restoreDeArrowAttribute(element, 'src', element._wblockDeArrowOriginalSrc);
            restoreDeArrowAttribute(element, 'srcset', element._wblockDeArrowOriginalSrcset);
            restoreDeArrowAttribute(element, 'referrerpolicy', element._wblockDeArrowOriginalReferrerPolicy);
        }
        delete element._wblockDeArrowOriginalSrc;
        delete element._wblockDeArrowOriginalSrcset;
        delete element._wblockDeArrowOriginalReferrerPolicy;
        releaseDeArrowThumbnail(element);
        delete element._wblockDeArrowShowingOriginal;
        element.removeAttribute('data-wblock-dearrow-thumbnail');
    }

    function installDeArrowHover(card) {
        if (card._wblockDeArrowHoverInstalled) return;
        card._wblockDeArrowHoverInstalled = true;
        card._wblockDeArrowMouseEnter = function () {
            if (!loadDeArrowSettings().showOriginalOnHover) return;
            card._wblockDeArrowShowingOriginal = true;
            var title = card._wblockDeArrowTitleElement;
            var image = card._wblockDeArrowThumbnailElement;
            if (title && title._wblockDeArrowTextNodes) {
                title._wblockDeArrowShowingOriginal = true;
                applyDeArrowTitleElement(title, title._wblockDeArrowCustomText);
            }
            if (image && image._wblockDeArrowOriginalSrc !== undefined) {
                image._wblockDeArrowShowingOriginal = true;
                restoreDeArrowAttribute(image, 'src', image._wblockDeArrowOriginalSrc);
                restoreDeArrowAttribute(image, 'srcset', image._wblockDeArrowOriginalSrcset);
                restoreDeArrowAttribute(image, 'referrerpolicy', image._wblockDeArrowOriginalReferrerPolicy);
            }
        };
        card._wblockDeArrowMouseLeave = function (event) {
            // YouTube's inline preview covers the hovered thumbnail from a shared
            // overlay outside the card. Keep the original until the pointer
            // leaves that overlay for somewhere other than this card.
            var to = event && event.relatedTarget;
            var preview = to && to.closest && to.closest('ytd-video-preview');
            if (preview) {
                preview.addEventListener('mouseleave', function onPreviewLeave(e) {
                    preview.removeEventListener('mouseleave', onPreviewLeave);
                    if (!(e.relatedTarget && card.contains(e.relatedTarget))) card._wblockDeArrowMouseLeave(e);
                });
                return;
            }
            card._wblockDeArrowShowingOriginal = false;
            var settings = loadDeArrowSettings();
            if (!settings.enabled) return;
            var title = card._wblockDeArrowTitleElement;
            var image = card._wblockDeArrowThumbnailElement;
            if (title) {
                title._wblockDeArrowShowingOriginal = false;
                if (settings.replaceTitles && title._wblockDeArrowCustomText) applyDeArrowTitleElement(title, title._wblockDeArrowCustomText);
            }
            if (image) {
                image._wblockDeArrowShowingOriginal = false;
                if (settings.replaceThumbnails && !keepOriginalDeArrowThumbnail(card) && image._wblockDeArrowCustomSrc &&
                    image._wblockDeArrowThumbnailFailed !== image._wblockDeArrowRequestedUrl) {
                    showDeArrowThumbnail(image);
                }
            }
        };
        card.addEventListener('mouseenter', card._wblockDeArrowMouseEnter);
        card.addEventListener('mouseleave', card._wblockDeArrowMouseLeave);
    }

    function restoreDeArrowCard(card) {
        if (!card) return;
        restoreDeArrowTitleElement(card._wblockDeArrowTitleElement);
        restoreDeArrowThumbnailElement(card._wblockDeArrowThumbnailElement);
        if (card._wblockDeArrowHoverInstalled) {
            card.removeEventListener('mouseenter', card._wblockDeArrowMouseEnter);
            card.removeEventListener('mouseleave', card._wblockDeArrowMouseLeave);
        }
        delete card._wblockDeArrowTitleElement;
        delete card._wblockDeArrowThumbnailElement;
        delete card._wblockDeArrowHoverInstalled;
        delete card._wblockDeArrowMouseEnter;
        delete card._wblockDeArrowMouseLeave;
        delete card._wblockDeArrowShowingOriginal;
        delete card._wblockDeArrowObserved;
        delete card._wblockDeArrowRequestedVideoId;
        delete card._wblockDeArrowProcessedVideoId;
        delete card._wblockDeArrowOriginalThumbnailChannel;
        card.removeAttribute('data-wblock-dearrow-card');
    }

    function applyDeArrowCard(card) {
        var videoId = deArrowCardVideoId(card);
        if (!videoId) return;
        if (card._wblockDeArrowRequestedVideoId && card._wblockDeArrowRequestedVideoId !== videoId) {
            restoreDeArrowCard(card);
        }
        var settings = loadDeArrowSettings();
        if (!settings.enabled) {
            restoreDeArrowCard(card);
            return;
        }
        card._wblockDeArrowRequestedVideoId = videoId;
        card.setAttribute('data-wblock-dearrow-card', '');
        fetchDeArrowBranding(videoId, false).then(function (branding) {
            if (!card.isConnected || card._wblockDeArrowRequestedVideoId !== videoId) return;
            var currentSettings = loadDeArrowSettings();
            if (!currentSettings.enabled) {
                restoreDeArrowCard(card);
                return;
            }
            var customTitle = deArrowAcceptedTitle(branding);
            var customTimestamp = deArrowAcceptedThumbnail(branding);
            if (customTimestamp === null && currentSettings.randomThumbnails) {
                customTimestamp = deArrowRandomThumbnailTimestamp(videoId, branding);
            }
            var titleElement = findDeArrowCardTitle(card);
            var thumbnailElement = findDeArrowCardThumbnail(card, videoId);
            if (currentSettings.replaceTitles && customTitle) {
                card._wblockDeArrowTitleElement = titleElement;
                applyDeArrowTitleElement(titleElement, customTitle);
            } else {
                restoreDeArrowTitleElement(card._wblockDeArrowTitleElement);
                delete card._wblockDeArrowTitleElement;
            }
            card._wblockDeArrowOriginalThumbnailChannel = keepOriginalDeArrowThumbnail(card);
            if (currentSettings.replaceThumbnails && !card._wblockDeArrowOriginalThumbnailChannel && customTimestamp !== null) {
                card._wblockDeArrowThumbnailElement = thumbnailElement;
                applyDeArrowThumbnailElement(thumbnailElement, videoId, customTimestamp, card);
            } else {
                restoreDeArrowThumbnailElement(card._wblockDeArrowThumbnailElement);
                delete card._wblockDeArrowThumbnailElement;
            }
            if (card._wblockDeArrowTitleElement || card._wblockDeArrowThumbnailElement) installDeArrowHover(card);
            card._wblockDeArrowProcessedVideoId = videoId;
        });
    }

    function queueDeArrowCard(card) {
        if (!card || card._wblockDeArrowShowingOriginal) return;
        var videoId = deArrowCardVideoId(card);
        if (!videoId) return;
        if (card._wblockDeArrowProcessedVideoId === videoId) {
            var title = card._wblockDeArrowTitleElement;
            var image = card._wblockDeArrowThumbnailElement;
            var titleNeedsRepair = title && title._wblockDeArrowCustomText &&
                title.textContent !== title._wblockDeArrowCustomText;
            var imageNeedsRepair = image && image._wblockDeArrowCustomSrc &&
                image._wblockDeArrowThumbnailFailed !== image._wblockDeArrowRequestedUrl &&
                image.getAttribute('src') !== image._wblockDeArrowCustomSrc;
            var channelPolicyChanged = card._wblockDeArrowOriginalThumbnailChannel !== keepOriginalDeArrowThumbnail(card);
            if (!titleNeedsRepair && !imageNeedsRepair && !channelPolicyChanged) return;
            applyDeArrowCard(card);
            return;
        }
        if (card._wblockDeArrowRequestedVideoId === videoId && card._wblockDeArrowObserved) return;
        if (typeof IntersectionObserver === 'undefined') {
            applyDeArrowCard(card);
            return;
        }
        if (!deArrowIntersectionObserver) {
            deArrowIntersectionObserver = new IntersectionObserver(function (entries) {
                entries.forEach(function (entry) {
                    if (!entry.isIntersecting) return;
                    try { deArrowIntersectionObserver.unobserve(entry.target); } catch (e) { /* ignore */ }
                    entry.target._wblockDeArrowObserved = false;
                    applyDeArrowCard(entry.target);
                });
            }, { rootMargin: '240px 0px', threshold: 0.01 });
        }
        if (!card._wblockDeArrowObserved) {
            card._wblockDeArrowObserved = true;
            card._wblockDeArrowRequestedVideoId = videoId;
            card.setAttribute('data-wblock-dearrow-card', '');
            deArrowIntersectionObserver.observe(card);
        }
    }

    function applyCurrentDeArrowTitle() {
        var settings = loadDeArrowSettings();
        var videoId = currentDeArrowVideoId();
        if (!settings.enabled || !settings.replaceTitles || !videoId) return;
        fetchDeArrowBranding(videoId, true).then(function (branding) {
            var currentSettings = loadDeArrowSettings();
            if (!currentSettings.enabled || !currentSettings.replaceTitles || currentDeArrowVideoId() !== videoId) return;
            var customTitle = deArrowAcceptedTitle(branding);
            var titles = document.querySelectorAll(DEARROW_WATCH_TITLE_SELECTOR);
            for (var i = 0; i < titles.length; i++) {
                if (customTitle) applyDeArrowTitleElement(titles[i], customTitle);
                else restoreDeArrowTitleElement(titles[i]);
            }
        });
    }

    function scanForDeArrow(root) {
        var settings = loadDeArrowSettings();
        if (!settings.enabled || !root) return;
        applyCurrentDeArrowTitle();
        var cards = [];
        if (root.nodeType === 1) {
            try {
                if (root.matches(DEARROW_CARD_SELECTOR)) cards.push(root);
                var closest = root.closest(DEARROW_CARD_SELECTOR);
                if (closest && cards.indexOf(closest) === -1) cards.push(closest);
            } catch (e) { /* ignore */ }
        }
        if (root.querySelectorAll) {
            var nested = root.querySelectorAll(DEARROW_CARD_SELECTOR);
            for (var i = 0; i < nested.length; i++) if (cards.indexOf(nested[i]) === -1) cards.push(nested[i]);
        }
        for (var j = 0; j < cards.length; j++) queueDeArrowCard(cards[j]);
    }

    function scheduleDeArrowScan(root) {
        if (root && root.nodeType === 3) root = root.parentElement;
        if (!loadDeArrowSettings().enabled) return;
        if (root === document) deArrowPendingScanRoots = [document];
        else if (deArrowPendingScanRoots.indexOf(document) === -1 && root && deArrowPendingScanRoots.indexOf(root) === -1) {
            deArrowPendingScanRoots.push(root);
            if (deArrowPendingScanRoots.length > 40) deArrowPendingScanRoots = [document];
        }
        if (deArrowScanScheduled) return;
        deArrowScanScheduled = true;
        Promise.resolve().then(function () {
            deArrowScanScheduled = false;
            var roots = deArrowPendingScanRoots;
            deArrowPendingScanRoots = [];
            for (var i = 0; i < roots.length; i++) {
                if (roots[i] === document || roots[i].isConnected) scanForDeArrow(roots[i]);
            }
        });
    }

    function restoreAllDeArrowBranding() {
        if (deArrowIntersectionObserver) {
            try { deArrowIntersectionObserver.disconnect(); } catch (e) { /* ignore */ }
            deArrowIntersectionObserver = null;
        }
        var cards = document.querySelectorAll('[data-wblock-dearrow-card]');
        for (var i = 0; i < cards.length; i++) restoreDeArrowCard(cards[i]);
        var titles = document.querySelectorAll('[data-wblock-dearrow-title]');
        for (var j = 0; j < titles.length; j++) restoreDeArrowTitleElement(titles[j]);
        var thumbnails = document.querySelectorAll('[data-wblock-dearrow-thumbnail]');
        for (var k = 0; k < thumbnails.length; k++) restoreDeArrowThumbnailElement(thumbnails[k]);
    }

    function refreshDeArrowBranding() {
        restoreAllDeArrowBranding();
        if (loadDeArrowSettings().enabled) scheduleDeArrowScan(document);
    }


    function currentDeArrowVideoId() {
        var fromURL = deArrowVideoIdFromUrl(location.href);
        if (fromURL) return fromURL;
        var details = window.ytInitialPlayerResponse && window.ytInitialPlayerResponse.videoDetails;
        return details && /^[A-Za-z0-9_-]{11}$/.test(details.videoId) ? details.videoId : null;
    }

    var brandingObserver = new MutationObserver(function (records) {
        for (var i = 0; i < records.length; i++) {
            scheduleDeArrowScan(records[i].target);
            for (var j = 0; j < records[i].addedNodes.length; j++) {
                if (records[i].addedNodes[j].nodeType === 1) scheduleDeArrowScan(records[i].addedNodes[j]);
            }
            for (var k = 0; k < records[i].removedNodes.length; k++) {
                var removed = records[i].removedNodes[k];
                if (removed.nodeType !== 1 || removed.isConnected) continue;
                if (removed.matches('[data-wblock-dearrow-card]')) restoreDeArrowCard(removed);
                var cards = removed.querySelectorAll('[data-wblock-dearrow-card]');
                for (var n = 0; n < cards.length; n++) restoreDeArrowCard(cards[n]);
            }
        }
    });
    brandingObserver.observe(document, {
        childList: true, subtree: true, attributes: true, characterData: true,
        attributeFilter: ['href', 'src', 'srcset', 'data-video-id', 'data-channel-id']
    });
    ['yt-navigate-finish', 'yt-page-data-updated'].forEach(function (event) {
        document.addEventListener(event, function () { scheduleDeArrowScan(document); }, true);
    });
    window.addEventListener('popstate', refreshDeArrowBranding);
    window.addEventListener('pagehide', restoreAllDeArrowBranding);
    window.addEventListener('pageshow', function () { scheduleDeArrowScan(document); });
    scheduleDeArrowScan(document);

    window.__wblockDeArrowDebug = {
        refresh: refreshDeArrowBranding,
        // Lets a page-console probe inspect the effective configuration and the
        // branding the script holds for a video without reaching into closures.
        state: function (videoId) {
            var branding = videoId ? cachedDeArrowBranding(videoId) : undefined;
            return {
                settings: JSON.parse(JSON.stringify(loadDeArrowSettings())),
                branding: branding === undefined ? 'not-fetched' : branding,
                watchVideoId: currentDeArrowVideoId(),
                requests: deArrowActiveRequestCount
            };
        },
        setSetting: function (key, value) {
            if (typeof __wblockDeArrowSettings !== 'object') return false;
            __wblockDeArrowSettings[key] = value;
            refreshDeArrowBranding();
            return true;
        }
    };
})();

})();

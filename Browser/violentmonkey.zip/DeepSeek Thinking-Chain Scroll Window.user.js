// ==UserScript==
// @name         DeepSeek 思维链滚动窗
// @name:zh-CN   DeepSeek 思维链滚动窗
// @namespace    local.dsw
// @license      MIT
// @version      2.1.0
// @name:en      DeepSeek Thinking-Chain Scroll Window
// @description:en Folds DeepSeek's reasoning chain into an auto-following scroll window: holds a few lines then smooth-scrolls with speed proportional to the backlog, fades in/out at both edges, no scrollbar, wheel never interrupts following. Click the "Thinking…" header to toggle (arrow down = windowed, arrow up = expanded); when reasoning finishes the chain folds as a whole (or stays expanded if you had expanded it). Works with web-search action rows and multi-segment reasoning.
// @description  把整条思维链（含"搜索到 N 个网页 / 浏览 N 个页面"动作行与多段思考）作为一个整体收进滚动窗：无滚动条、滚轮不可拨动，上下边缘淡入淡出；先攒几行再平滑跟随最新输出，滚动速度随积压行数动态变化；点标题行切换，箭头朝下=折叠滚动、朝上=全量展开；思考结束沿用当前状态（折叠→整条折叠，展开→整条展开）
// @author       zcode
// @match        https://chat.deepseek.com/*
// @match        https://*.deepseek.com/*
// @grant        GM_addStyle
// @grant        GM_registerMenuCommand
// @grant        GM_getValue
// @grant        GM_setValue
// @run-at       document-idle
// @downloadURL https://update.greasyfork.org/scripts/597788/DeepSeek%20%E6%80%9D%E7%BB%B4%E9%93%BE%E6%BB%9A%E5%8A%A8%E7%AA%97.user.js
// @updateURL https://update.greasyfork.org/scripts/597788/DeepSeek%20%E6%80%9D%E7%BB%B4%E9%93%BE%E6%BB%9A%E5%8A%A8%E7%AA%97.meta.js
// ==/UserScript==

(function () {
  'use strict';
  if (window.__DSW__) { try { window.__DSW__.destroy(); } catch (e) {} }

  /* ---------- 配置 ---------- */
  const store = {
    get(k, d) {
      try { if (typeof GM_getValue === 'function') return GM_getValue(k, d); } catch (e) {}
      try { const v = localStorage.getItem('dsw:' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; }
    },
    set(k, v) {
      try { if (typeof GM_setValue === 'function') { GM_setValue(k, v); return; } } catch (e) {}
      try { localStorage.setItem('dsw:' + k, JSON.stringify(v)); } catch (e) {}
    },
  };

  const CFG = {
    lines: Number(store.get('lines', 8)) || 8,   // 滚动窗高度（正文行数）
    minPx: 120,
    maxPx: 560,
  };

  // 自动跟随的滚动手感：先攒几行再滚，速度随"还没出现在窗口里的行数"动态变化
  const SCROLL = {
    holdLines: 2.5,  // 先攒够这些行才开始滚动
    perLine: 110,    // 每积压一行增加的速度 (px/s)
    minV: 40,        // 滚动中的最低速度 (px/s)
    maxV: 2000,      // 最高速度 (px/s)
    eps: 2,          // 追平判定阈值 (px)
  };

  // 滚动窗上下边缘的淡入淡出（px）：正文滚近标题行下缘时逐渐隐没，新内容从底缘逐渐显现
  const FADE = {
    top: 36,    // 标题行下缘的淡出带高度
    bottom: 30, // 窗口底缘的淡入带高度
  };

  // 标题识别：不同版本文案不同，按需在这里补
  const RE_THINK = /^(正在思考|思考中|思考中…|思考中\.\.\.|思考中。。|深度思考中|思考进行中|Thinking)/;
  const RE_DONE = /^(已深度思考|已思考|思考完成|思考完毕|深度思考完成|已停止|已中断|已取消|已暂停|Thought|Stopped|Interrupted)/;
  // 这些文案回答区也可能出现，必须找到思考正文才算数
  const RE_GENERIC_DONE = /^(已停止|已中断|已取消|已暂停|Stopped|Interrupted)/;

  function phaseOf(text) {
    const t = String(text || '').replace(/\s+/g, ' ').trim();
    if (!t || t.length > 60) return null;
    if (RE_THINK.test(t)) return 'thinking';
    if (RE_DONE.test(t)) return 'done';
    return null;
  }

  const BLOCK_TAG = /^(DIV|SECTION|ARTICLE|MAIN|P|UL|OL|PRE|BLOCKQUOTE|DETAILS|ASIDE|FIGURE)$/;
  const THINK_SEL = '.ds-think-content, [class*="ds-think-content"]';

  /* ---------- 样式 ---------- */
  function addStyle(css) {
    if (typeof GM_addStyle === 'function') { try { GM_addStyle(css); return; } catch (e) {} }
    const s = document.createElement('style');
    s.id = 'dsw-style';
    s.textContent = css;
    document.head.appendChild(s);
  }

  addStyle(`
.dsw-root { position: relative; }
/* 窗口模式：整条思维链（思考段 + 动作行）收进一个滚动窗 */
.dsw-root.dsw-window {
  overflow: hidden !important;
  scrollbar-width: none;
  -ms-overflow-style: none;
  -webkit-mask-image: var(--dsw-fade, none);
  mask-image: var(--dsw-fade, none);
}
.dsw-root.dsw-window::-webkit-scrollbar { display: none !important; width: 0 !important; height: 0 !important; }
/* 标题行钉在窗口顶部，正文从其下方流过 */
.dsw-root.dsw-window > .dsw-head {
  position: sticky; top: 0; z-index: 3;
  background: var(--dsw-bg, Canvas);
}
/* 折叠：整条只留标题行 */
.dsw-root.dsw-folded > :not(.dsw-head) { display: none !important; }
.dsw-root .dsw-click { cursor: pointer; }
.dsw-root .dsw-chev svg,
.dsw-root .dsw-click > *:last-child svg { transition: transform 0.18s ease; }
.dsw-root.dsw-expanded .dsw-chev svg,
.dsw-root.dsw-expanded .dsw-click > *:last-child svg { transform: rotate(180deg) !important; }
`);

  /* ---------- DOM 定位 ---------- */
  function inComposer(el) {
    if (el.closest && el.closest('form')) return true;
    let n = el.parentElement;
    for (let i = 0; i < 5 && n; i++, n = n.parentElement) {
      const box = n.querySelector('textarea, [contenteditable="true"], [role="textbox"]');
      if (box && (n.innerText || '').length < 300) return true;
    }
    return false;
  }

  function findLabels(scope) {
    const out = [];
    const els = (scope || document).querySelectorAll('div,span,p,button,summary,section,header,a,h1,h2,h3,h4,h5');
    for (const el of els) {
      if (el.closest && el.closest('.dsw-fab, .dsw-chev')) continue;
      // 思考正文/markdown 里出现的"思考"字样不算标题
      if (el.closest && el.closest(THINK_SEL + ', .dsw-content, .ds-markdown')) continue;
      const phase = phaseOf(el.textContent);
      if (!phase) continue;
      let smallest = true;
      for (const c of el.children) {
        if (phaseOf(c.textContent)) { smallest = false; break; }
      }
      if (!smallest) continue;
      if (inComposer(el)) continue;
      out.push({ el, phase });
    }
    return out;
  }

  function resolveClickZone(label) {
    let node = label;
    let best = label.parentElement || label;
    for (let i = 0; i < 3 && node && node !== document.body; i++) {
      node = node.parentElement;
      if (!node) break;
      const txt = (node.textContent || '').trim();
      if (txt.length > 80) break;
      if (node.tagName === 'BUTTON' || node.getAttribute('role') === 'button') return node;
      best = node;
      if (node.querySelector && node.querySelector('svg,button,[class*="icon"]')) break;
    }
    return best;
  }

  // 标题行（点击区）可能不在根的直接子级上，向上找到根的直接子级作为"标题单元"
  function headOf(zone, root) {
    if (!zone || !root || zone === root || !root.contains(zone)) return null;
    let n = zone;
    while (n.parentElement && n.parentElement !== root) n = n.parentElement;
    return n.parentElement === root ? n : null;
  }

  // 标题行钉顶时需要不透明底色，取自身/祖先第一个非透明背景
  function bgOf(el) {
    let n = el;
    while (n && n !== document.documentElement) {
      const c = (getComputedStyle(n).backgroundColor || '').replace(/\s+/g, '');
      if (c && c !== 'transparent' && c !== 'rgba(0,0,0,0)') return c;
      n = n.parentElement;
    }
    return null;
  }

  function plausibleContent(el) {
    if (!el || !el.classList) return false;
    if (el.classList.contains('dsw-chev') || el.classList.contains('dsw-click')) return false;
    const t = (el.textContent || '').trim();
    if (!t) return false;
    if (phaseOf(t)) return false;
    return BLOCK_TAG.test(el.tagName) || t.length >= 40;
  }

  function resolveContent(label) {
    // DeepSeek 思考正文自带稳定的 ds-think-content 类，优先取标题之后的第一个
    // （联网搜索时会有多段思考 + 动作行交错，这里只拿第一段做行高采样/归属校验，
    //   窗口与折叠作用于整个根节点，天然覆盖全部段落）
    const thinks = document.querySelectorAll(THINK_SEL);
    for (const t of thinks) {
      if (t.contains(label)) continue;
      if (label.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_FOLLOWING) return t;
    }
    // 退化路径：标题行之后紧邻的内容块（同一容器里的兄弟节点）
    let row = label;
    for (let i = 0; i < 5 && row; i++, row = row.parentElement) {
      const parent = row.parentElement;
      if (!parent) break;
      const kids = Array.from(parent.children);
      const idx = kids.indexOf(row);
      for (let j = idx + 1; j < kids.length; j++) {
        if (plausibleContent(kids[j])) return kids[j];
      }
    }
    // 兜底：文档顺序上标题之后的第一个 markdown 块
    const mds = document.querySelectorAll('.ds-markdown, [class*="markdown"]');
    for (const md of mds) {
      if (md.contains(label)) continue;
      if (label.compareDocumentPosition(md) & Node.DOCUMENT_POSITION_FOLLOWING) return md;
    }
    return null;
  }

  function isThinkContent(el) {
    return !!(el && el.matches && el.matches(THINK_SEL));
  }

  function resolveRoot(label, content) {
    let n = label;
    while (n && n !== document.documentElement && !n.contains(content)) n = n.parentElement;
    if (!n || n === document.body || n === document.documentElement) return null;
    return n;
  }

  function lineHeightOf(content) {
    const cs = getComputedStyle(content);
    let lh = parseFloat(cs.lineHeight);
    if (!lh || isNaN(lh)) lh = (parseFloat(cs.fontSize) || 16) * 1.7;
    return lh;
  }

  function heightFor(content) {
    const h = lineHeightOf(content) * CFG.lines;
    return Math.round(Math.min(CFG.maxPx, Math.max(CFG.minPx, h)));
  }

  // 标题行里最后一个图标就是 DeepSeek 自带的展开/收起箭头，复用它做状态指示
  function ensureChev(zone, st) {
    if (!zone) return;
    if (st.chev && zone.contains(st.chev)) {
      st.chev.classList.add('dsw-chev');
      return;
    }
    let chev = zone.querySelector('.dsw-chev');
    if (!chev) {
      // 最后一个图标是箭头；若唯一的图标是行首的脑图标，则自造一个箭头
      const icons = Array.from(zone.children).filter((c) => c.querySelector && c.querySelector('svg'));
      const cand = icons.length ? icons[icons.length - 1] : null;
      if (cand && cand !== zone.firstElementChild) chev = cand;
    }
    if (!chev) {
      chev = document.createElement('span');
      chev.className = 'dsw-chev dsw-chev-own';
      chev.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12"><path d="M2 4l4 4 4-4" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>';
      zone.appendChild(chev);
    }
    chev.classList.add('dsw-chev');
    st.chev = chev;
  }

  /* ---------- 状态与行为 ---------- */
  const blocks = new Map(); // root -> state

  function isWindowed(root, st) {
    return root.dataset.dswPhase === 'thinking' && root.dataset.dswView === 'window';
  }

  function isCollapsed(root, st) {
    return isWindowed(root, st) || root.dataset.dswFolded === '1';
  }

  function stopScroll(st) {
    if (st.raf) cancelAnimationFrame(st.raf);
    st.raf = null;
    st.sweeping = false;
  }

  // 平滑跟随：攒够 SCROLL.holdLines 行后开始滚动，速度正比于积压行数，追平即停
  // 滚动对象是根节点本身——多段思考与动作行都在根里，跨段落也是同一段连续滚动
  function ensureScroll(root, st) {
    if (st.raf) return;
    st.lastT = performance.now();
    const step = () => {
      if (!root.isConnected || !isWindowed(root, st)) {
        st.raf = null;
        st.sweeping = false;
        return;
      }
      const now = performance.now();
      const dt = Math.min(0.08, Math.max(0, (now - st.lastT) / 1000));
      st.lastT = now;
      const src = st.content && st.content.isConnected ? st.content : root;
      const lh = lineHeightOf(src);
      const distance = root.scrollHeight - root.scrollTop - root.clientHeight;
      if (!st.sweeping && distance >= SCROLL.holdLines * lh) st.sweeping = true;
      if (st.sweeping && distance <= SCROLL.eps) st.sweeping = false;
      if (st.sweeping) {
        const lines = distance / lh;
        const v = Math.min(SCROLL.maxV, Math.max(SCROLL.minV, lines * SCROLL.perLine));
        root.scrollTop += Math.min(distance, v * dt);
      }
      st.raf = requestAnimationFrame(step);
    };
    st.raf = requestAnimationFrame(step);
  }

  function apply(root, st) {
    const zone = st.zone && root.contains(st.zone) ? st.zone : null;
    st.head = headOf(zone, root);
    if (st.head) st.head.classList.add('dsw-head');
    const folded = root.dataset.dswFolded === '1';
    // 标题单元没定位到时不折叠，宁可全展开也不能把标题行一起藏掉
    root.classList.toggle('dsw-folded', folded && !!st.head);
    root.classList.toggle('dsw-phase-thinking', root.dataset.dswPhase === 'thinking');
    root.classList.toggle('dsw-phase-done', root.dataset.dswPhase === 'done');
    root.classList.toggle('dsw-expanded', !isCollapsed(root, st));
    if (zone) {
      zone.classList.add('dsw-click');
      ensureChev(zone, st);
    }
    root.classList.toggle('dsw-window', isWindowed(root, st));
    if (isWindowed(root, st)) {
      const headH = st.head ? st.head.offsetHeight : 0;
      const src = st.content && st.content.isConnected ? st.content : root;
      const winH = heightFor(src);
      root.style.setProperty('max-height', (headH + winH) + 'px', 'important');
      // 渐变蒙版：标题行区域全显，其下 FADE.top 内淡入，底缘 FADE.bottom 内淡出；
      // 用固定像素做止点，内容不足一窗时止点落在盒外，整段保持不透明
      root.style.setProperty('--dsw-fade', 'linear-gradient(to bottom, #000 0px, #000 ' + headH + 'px, transparent ' + headH + 'px, #000 ' + (headH + FADE.top) + 'px, #000 ' + (headH + winH - FADE.bottom) + 'px, transparent ' + (headH + winH) + 'px)');
      const bg = bgOf(root);
      if (bg) root.style.setProperty('--dsw-bg', bg);
      ensureScroll(root, st);
    } else {
      root.style.removeProperty('max-height');
      root.style.removeProperty('--dsw-fade');
      stopScroll(st);
    }
  }

  function toggle(root, st) {
    if (root.dataset.dswPhase === 'thinking') {
      root.dataset.dswView = root.dataset.dswView === 'window' ? 'full' : 'window';
    } else {
      root.dataset.dswFolded = root.dataset.dswFolded === '1' ? '0' : '1';
    }
    apply(root, st);
  }

  function bindRoot(label, phase) {
    const content = resolveContent(label);
    if (RE_GENERIC_DONE.test((label.textContent || '').replace(/\s+/g, ' ').trim()) && !isThinkContent(content)) {
      return null;
    }
    const root = content ? resolveRoot(label, content) : null;
    if (!root) return null;
    let st = blocks.get(root);
    if (!st) {
      st = { label: null, zone: null, head: null, content: null, chev: null, finalized: false, raf: null, sweeping: false, lastT: 0 };
      blocks.set(root, st);
      root.classList.add('dsw-root');
      root.dataset.dswView = root.dataset.dswView || 'window';
      root.dataset.dswFolded = root.dataset.dswFolded || '0';
    }
    st.label = label;
    st.zone = resolveClickZone(label);
    st.content = content;
    root.dataset.dswPhase = phase;
    // 思考结束的瞬间，把滚动窗/全量展开映射为 整体折叠/整体展开
    if (phase === 'done' && !st.finalized) {
      st.finalized = true;
      root.dataset.dswFolded = root.dataset.dswView === 'window' ? '1' : '0';
    }
    // 思考重新开始（多段链文案回跳等）时清掉残留折叠，否则窗口/展开切换会被旧折叠盖住
    if (phase === 'thinking') { st.finalized = false; root.dataset.dswFolded = '0'; }
    apply(root, st);
    return root;
  }

  function updatePhase(root, st, phase) {
    if (root.dataset.dswPhase !== phase) {
      root.dataset.dswPhase = phase;
      if (phase === 'done' && !st.finalized) {
        st.finalized = true;
        root.dataset.dswFolded = root.dataset.dswView === 'window' ? '1' : '0';
      }
      if (phase === 'thinking') { st.finalized = false; root.dataset.dswFolded = '0'; }
    }
  }

  function scan() {
    for (const { el, phase } of findLabels(document)) {
      let root = el.closest ? el.closest('.dsw-root') : null;
      if (root) {
        const st = blocks.get(root);
        if (st) {
          // 只认标题行里的文案；动作行（搜索到/浏览 N 个页面）里的字样不改状态
          if (st.head && !st.head.contains(el)) continue;
          updatePhase(root, st, phase);
          apply(root, st);
          continue;
        }
      }
      bindRoot(el, phase);
    }
  }

  function syncAll() {
    for (const [root, st] of Array.from(blocks.entries())) {
      if (!root.isConnected) { blocks.delete(root); continue; }
      // React 重渲染会换掉内部节点，这里逐一找回；标签优先在标题单元里找
      if (!st.head || !root.contains(st.head)) st.head = null;
      if (!st.label || !root.contains(st.label)) {
        const hits = findLabels(root);
        const inHead = st.head ? hits.find((h) => st.head.contains(h.el)) : null;
        const hit = inHead || hits[0];
        if (hit) st.label = hit.el;
      }
      if (!st.zone || !root.contains(st.zone)) {
        st.zone = st.label ? resolveClickZone(st.label) : null;
      }
      if (!st.content || !root.contains(st.content)) {
        st.content = st.label ? resolveContent(st.label) : null;
      }
      apply(root, st);
    }
    scan();
  }

  /* ---------- 事件 ---------- */
  function onClick(e) {
    for (const [root, st] of blocks) {
      if (!root.isConnected || !root.contains(e.target)) continue;
      const zone = st.zone && root.contains(st.zone) ? st.zone : null;
      if (zone && zone.contains(e.target)) {
        e.preventDefault();
        e.stopPropagation();
        if (e.stopImmediatePropagation) e.stopImmediatePropagation();
        toggle(root, st);
        return;
      }
    }
  }

  let intervalId = null;
  let debounceId = null;
  let observer = null;
  function onMutate() {
    if (debounceId) return;
    debounceId = setTimeout(() => { debounceId = null; syncAll(); }, 150);
  }

  function boot() {
    document.addEventListener('click', onClick, true);
    observer = new MutationObserver(onMutate);
    observer.observe(document.body, { subtree: true, childList: true, characterData: true });
    intervalId = setInterval(syncAll, 800);
    syncAll();
  }

  /* ---------- 调试 / 菜单 ---------- */
  function diag() {
    const out = [];
    for (const [root, st] of blocks) {
      out.push({
        phase: root.dataset.dswPhase,
        view: root.dataset.dswView,
        folded: root.dataset.dswFolded,
        expanded: root.classList.contains('dsw-expanded'),
        label: st.label ? (st.label.textContent || '').trim().slice(0, 30) : null,
        headTag: st.head ? st.head.tagName + '.' + (st.head.className || '').toString().slice(0, 40) : null,
        zoneTag: st.zone ? st.zone.tagName + '.' + (st.zone.className || '').toString().slice(0, 40) : null,
        rootKids: root.children.length,
        contentLen: st.content ? (st.content.textContent || '').length : 0,
      });
    }
    return out;
  }

  window.__DSW__ = {
    version: '2.1.0',
    diag,
    setLines(n) { CFG.lines = Number(n) || CFG.lines; store.set('lines', CFG.lines); syncAll(); },
    destroy() {
      document.removeEventListener('click', onClick, true);
      if (observer) observer.disconnect();
      if (intervalId) clearInterval(intervalId);
      if (debounceId) clearTimeout(debounceId);
      for (const [root, st] of blocks) {
        stopScroll(st);
        root.classList.remove('dsw-root', 'dsw-folded', 'dsw-phase-thinking', 'dsw-phase-done', 'dsw-expanded', 'dsw-window');
        root.style.removeProperty('max-height');
        root.style.removeProperty('--dsw-bg');
        root.style.removeProperty('--dsw-fade');
        delete root.dataset.dswPhase; delete root.dataset.dswView; delete root.dataset.dswFolded;
        if (root.querySelectorAll) {
          root.querySelectorAll('.dsw-head, .dsw-click, .dsw-chev').forEach((n) => {
            n.classList.remove('dsw-head', 'dsw-click');
            if (n.classList.contains('dsw-chev-own')) n.remove();
            else n.classList.remove('dsw-chev');
          });
        }
        if (st.chev && st.chev.classList && st.chev.classList.contains('dsw-chev-own')) st.chev.remove();
      }
      blocks.clear();
      const s = document.getElementById('dsw-style');
      if (s) s.remove();
      delete window.__DSW__;
    },
  };

  try {
    if (typeof GM_registerMenuCommand === 'function') {
      GM_registerMenuCommand('设置滚动窗行数（当前 ' + CFG.lines + ' 行）', () => {
        const v = prompt('滚动窗高度（行数）', String(CFG.lines));
        if (v && !isNaN(Number(v)) && Number(v) > 2) window.__DSW__.setLines(Number(v));
      });
    }
  } catch (e) {}

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
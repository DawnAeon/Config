// ==UserScript==
// @name         网站签到工具
// @version      3.0.4
// @description  用于各种论坛和网站自动签到 论坛签到工具、签到工具、整合吾爱破解、飘云阁、卡饭论坛、网易云音乐、天使动漫论坛等论坛和网站自动点击签到 根据论坛签到工具 二次开发 需要添加其他网站请私聊我留下网站地址
// @author       Fxy29
// @homepage     https://greasyfork.org/zh-CN/scripts/439136-%E7%BD%91%E7%AB%99%E7%AD%BE%E5%88%B0%E5%B7%A5%E5%85%B7
// @icon         https://www.dismall.com/favicon.ico
// @match        https://www.52pojie.cn/*
// @match        https://www.chinapyg.com/*
// @match        https://music.163.com/
// @match        https://www.acfun.cn/*
// @match        https://www.wenshushu.cn/*
// @match        https://www.itsk.com/*
// @match        https://bbs.kafan.cn/*
// @match        https://bbs.wstx.com/*
// @match        https://*.hifiti.com/*
// @match        https://zhutix.com/*
// @match        https://*.tsdm39.com/*
// @match        https://*.smzdm.com/
// @match        https://*.iya.app/*
// @match        *://*.1000qm.vip/*
// @match        https://*.mydigit.cn/*
// @match        https://bbs.jqhdd.com/*
// @match        https://*.chinadsl.net/*
// @match        https://*.chenyuanqingshui.cn/*
// @match        https://*.sayhanabi.net/*
// @match        https://bbs.binmt.cc/*
// @match        https://littleskin.cn/user
// @match        https://*.4ksj.com/*
// @match        https://*.xlebbs.com/*
// @match        https://cnlang.org/*
// @match        https://zxcsol.com/
// @match        https://blog.51cto.com/
// @match        https://*.52cnp.com/*
// @match        https://forum.naixi.net/*
// @match        https://3d.jzsc.net/*
// @match        https://*.znzmo.com/*
// @match        https://*.975w.com/*
// @match        https://klpbbs.com/*
// @match        https://*.mudaiba.com/
// @match        https://*.zyrhires.com/*
// @match        https://*.tekqart.com/*
// @match        https://winmoes.com/task
// @match        *://*.ydwgames.com/*
// @match        https://bbs.108mir.com/*
// @match        https://lixianla.com/
// @match        https://70games.net/
// @match        https://gztown.org/*
// @match        https://*.bugutv.vip/*
// @match        *://*.nmandy.net/*
// @match        https://vip.lzzcc.cn/
// @match        https://*.iios.club/*
// @match        https://*.macat.vip/user
// @match        https://bbs.66ccff.cc/
// @match        *://*.openedv.com/*
// @match        https://juejin.cn/user/*
// @match        https://fishc.com.cn/*
// @match        https://home.x64bbs.cn/
// @match        *://*.ymmfa.com/*
// @match        https://*.manhuabudangbbs.com/*
// @match        https://*.55188.com/*
// @match        https://*.xianyudanji.to/*
// @match        https://bbs2.seikuu.com/*
// @match        https://bbs.yamibo.com/*
// @match        https://bingfong.com/*
// @match        https://*.jyeoo.com/*
// @match        https://duokan.club/*
// @match        https://xhzyku.com/*
// @match        https://*.xbgame.net/*
// @match        https://bbs.steamtools.net/*
// @match        https://club.excelhome.net/*
// @match        https://aistudio.baidu.com/*
// @match        https://*.luogu.com.cn/*
// @match        https://bbs.foodmate.net/*
// @match        *://apk.tw/*
// @match        https://*.fotor.com/*
// @match        https://*.mnpc.net/*
// @match        https://*.byzhihuo.com/*
// @match        https://*.caigamer.cn/*
// @match        https://*.5abbk.com/*
// @match        https://*.minebbs.com/
// @match        https://www.sglynp.com/*
// @match        https://bbs.kfpromax.com/*
// @match        https://www.acgns.org/*
// @match        https://bbs.125.la/*
// @match        https://www.kungal.com/*
// @match        https://rainkmc.com/*
// @match        https://141love.net/*
// @match        https://*.stcaimcu.com/*
// @match        https://youxiou.com/*
// @match        https://forum.zwsoft.cn/*
// @match        https://www.kuafuzys.com/*
// @match        https://www.jkju.cc/*
// @match        https://www.joinquant.com/view/user*
// @match        https://bbs.vc52.cn/*
// @match        https://*.hadsky.com/*
// @match        https://*.lhndy.cn/*
// @match        https://www.sonkwo.cn/*
// @match        https://i.zaimanhua.com/*
// @match        https://*.pc528.net/*
// @match        https://*.right.com.cn/*
// @match        https://bbs.acgrip.com/*
// @match        https://bbs.itzmx.com/*
// @match        https://developer.aliyun.com/*
// @match        https://ld246.com/*
// @match        https://cg.163.com/*
// @match        https://*.xiuxitong.com/*
// @match        https://*.yunmc.vip/*
// @include      https://*ikuuu*
// @include      *://*/plugin.php?id=*sign*
// @exclude      https://leaves.red/*
// @exclude      http://www.txtnovel.pro/*
// @require      https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js
// @grant        GM_addStyle
// @grant        GM_getResourceText
// @grant        GM_xmlhttpRequest
// @grant        unsafeWindow
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM.deleteValue
// @grant        GM_registerMenuCommand
// @grant        GM_openInTab
// @run-at       document-end
// @copyright 	 2025 Fxy29
// @license      Apache-2.0
// @namespace http://tampermonkey.net/
// @downloadURL https://update.greasyfork.org/scripts/439136/%E7%BD%91%E7%AB%99%E7%AD%BE%E5%88%B0%E5%B7%A5%E5%85%B7.user.js
// @updateURL https://update.greasyfork.org/scripts/439136/%E7%BD%91%E7%AB%99%E7%AD%BE%E5%88%B0%E5%B7%A5%E5%85%B7.meta.js
// ==/UserScript==

(function () {

    var APPNAME=GM_info.script.name+"-"+GM_info.script.version;
    var NOLOGIN="-----------------------------\n["+APPNAME+"]\n状态异常或未登录，登录后自动签到\n-----------------------------";
    var QIANDAO="-----------------------------\n["+APPNAME+"]\n签到完成！\n-----------------------------";
    var QIANDAOTEXT="-----------------------------\n["+APPNAME+"]\n领取完成！\n-----------------------------";

    /* globals jQuery, $, waitForKeyElements */

    var SITES = [
        // 吾爱破解论坛
        { name: "吾爱破解论坛", test: function(h){ return h.indexOf("52pojie.cn") !== -1 && h.indexOf("search.php") === -1 && h.indexOf("home.php") === -1; }, run: function(){
            window.setTimeout(function(){
                if (document.body.textContent.indexOf('注册[Register]') !== -1){
                    return;
                }else if(document.getElementById("g_upmine") == null && document.body.textContent.indexOf('Forbidden') === -1){
                    window.setTimeout(function(){
                        alert(NOLOGIN);
                    },1200);
                }else{
                    var qq_bind = $("#um p:eq(1) a:eq(0) img").attr('src');
                    if (typeof qq_bind !== "string") return;
                    var g_upmine = document.getElementById("g_upmine");
                    if (qq_bind.indexOf("qds.png") !== -1) {
                        window.setTimeout(function(){$("#um p:eq(1) a:eq(0) img").click();},1000);
                        return;
                    }
                }
            },2000);
        }},
        // 飘云阁
        { name: "飘云阁", test: function(h){ return h.indexOf("chinapyg.com") !== -1; }, run: function(){
            qd4('签到领奖!', 'kx_s');
        }},

        // 网易云音乐
        { name: "网易云音乐", test: function(h){ return h.indexOf("music.163.com") !== -1; }, run: function(){
            window.setTimeout(function(){
                if(!window.find("登录") && !window.find("登录网易云音乐")){
                    var iframe = document.querySelector('#g_iframe');
                    if (!iframe || !iframe.contentDocument) return;
                    var iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                    var sign_button = iframeDoc.getElementsByClassName('sign')[0];
                    if (sign_button && sign_button.text.indexOf("签 到") === 0) { sign_button.click(); return; }
                }else{
                    alert(NOLOGIN);
                }
            },3000);
        }},
        // acfun
        { name: "acfun", test: function(h){ return h.indexOf("www.acfun.cn") !== -1; }, run: function(){
            var acfun_member = 'https://www.acfun.cn/member/';
            if (isURL(acfun_member)) {
                setTimeout(function () {
                    var signInBtn = document.getElementsByClassName("sign-in-btn")[0];
                    if (!signInBtn) return;
                    if (signInBtn.textContent.indexOf("已签到") !== -1) return;
                    signInBtn.click();
                    window.setTimeout(function(){
                        var modal = document.getElementById("signin-modal-show");
                        var webBtn = document.getElementsByClassName("signin-web-btn")[0];
                        if (modal) modal.checked = true;
                        if (webBtn) { webBtn.click(); window.location.reload(); }
                    },1000);
                }, 2000);
            }
        }},
        // 文叔叔
        { name: "文叔叔", test: function(h){ return h.indexOf("wenshushu.cn") !== -1; }, run: function(){
            window.setTimeout(function(){
                for (var i=0; i<5; i++)
                {
                    if (typeof $(".btn-icon")[i] != 'undefined') {
                        $(".btn-icon")[i].click();
                    }
                }
                var clock = document.getElementsByClassName('icon-cont_clock')[0];
                if (clock) clock.click();
            },5000);
        }},
        // IT天空
        { name: "IT天空", test: function(h){ return h.indexOf("itsk.com") !== -1; }, run: function(){
            const timer = setInterval(() => {
                const btn = document.querySelector('.sign-res button.el-button--success');
                if (btn) {
                    btn.click();
                    clearInterval(timer);
                }
            }, 1000);
        }},
        // 卡饭论坛 冰楓論壇
        { name: "卡饭论坛/冰楓論壇", test: function(h){ return h.indexOf("bbs.kafan.cn") !== -1 || h.indexOf("bingfong.com") !== -1; }, run: function(){
            window.setTimeout(function(){
                var el = document.getElementById("pper_a");
                if (!el) return;
                var imgs3 = el.getElementsByTagName("IMG");
                if (imgs3[0] && imgs3[0].src.indexOf("wb.png") === -1) el.click();
            },2000);
        }},
        // 鱼C论坛 数码之家 MT论坛 华印社区 奶昔论坛 苦力怕论坛 奇速网单 ExcelHome 不移之火 茹伊映画 巨大爱好者
        { name: "鱼C/数码之家/MT/华印/奶昔/苦力怕/奇速/ExcelHome/不移之火/茹伊/巨大爱好者", test: function(h){ return h.indexOf("fishc.com.cn") !== -1 || h.indexOf("mydigit.cn") !== -1 || h.indexOf("bbs.binmt.cc") !== -1 || h.indexOf("52cnp.com") !== -1 || h.indexOf("naixi.net") !== -1 || h.indexOf("klpbbs.com") !== -1 || h.indexOf("108mir.com") !== -1 || h.indexOf("club.excelhome.net") !== -1 || h.indexOf("byzhihuo.com") !== -1 || h.indexOf("ruyanhk") !== -1 || h.indexOf("52gts") !== -1; }, run: function(){
            window.setTimeout(function(){
                if (isURL('k_misign-sign.html') || isURL('plugin.php?id=k_misign:sign') || isURL('k_misign:sign') || isURL('sign.php')) {
                    if (window.find("您今天还没有签到")||window.find("您今天還沒有簽到")) {
                        $("#JD_sign").click();
                        return;
                    }
                }
            },2000);
        }},
        // 深影论坛
        { name: "深影论坛", test: function(h){ return h.indexOf("sybbs.vip/plugin.php?id=gsignin:index") !== -1; }, run: function(){
            window.setTimeout(function(){
                var el = document.getElementsByClassName('right')[0];
                if (el) el.click();
            },2000);
        }},
        // 樱花萌ACG 三国情论坛
        { name: "樱花萌ACG/三国情", test: function(h){ return h.indexOf("jiuyh") !== -1 || h.indexOf("975w.com") !== -1; }, run: function(){
            if (isURL('yinxingfei_zzza:yinxingfei_zzza_hall') || isURL("yinxingfei_zzza-yinxingfei_zzza_hall.html")) {
                window.setTimeout(function(){
                    var el = document.getElementById("zzza_go");
                    if (el) el.click();
                },2000);
            }
        }},
        // HiFiTi
        { name: "HiFiTi", test: function(h){ return h.indexOf("hifiti.com") !== -1; }, run: function(){
            window.setTimeout(function(){
                var imgs5 = document.getElementById("sg_sign");
                if (!imgs5) return;
                if(imgs5.textContent.indexOf("请登录") !== -1) {
                    alert(NOLOGIN);
                    return;
                }else if(imgs5.textContent.indexOf("已签") !== -1){
                    return;
                }else if(imgs5.textContent.indexOf("签到") !== -1){
                    imgs5.click();
                    return;
                }
            },2000);
        }},
        // 致美化 task
        { name: "致美化(task)", test: function(h){ return h.indexOf("zhutix.com/task") !== -1; }, run: function(){
            window.setTimeout(function(){
                var task_day_list = document.getElementsByClassName("task-day-list")[0];
                if (!task_day_list) return;
                var task_day_list_ul = task_day_list.childNodes.item(0);
                if (!task_day_list_ul) return;
                var task_day_list_ul_lis = task_day_list_ul.childNodes;
                var task_day_list_spanno15 = task_day_list.getElementsByTagName('span')[15];
                if (!task_day_list_spanno15 || task_day_list_spanno15.className.trim() !== 'task-finish-icon-go') return;
                var link = task_day_list.getElementsByTagName('a')[3];
                if (link) { link.click(); alert(QIANDAO); }
            },1000);
        }},
        // 致美化 mission/today
        { name: "致美化(mission)", test: function(h){ return h.indexOf("zhutix.com/mission/today") !== -1; }, run: function(){
            window.setTimeout(function(){
                var row = document.getElementsByClassName('gold-row')[0];
                if (!row) return;
                var span = row.getElementsByTagName('span')[0];
                var button = row.getElementsByTagName('button')[0];
                if (button && span && span.innerText.includes('签到')) { button.click(); alert(QIANDAO); }
            },6500);
        }},
        // 天使动漫论坛
        { name: "天使动漫论坛", test: function(h){ return h.indexOf("tsdm") !== -1; }, run: function(){
            qd4('签到领奖!', 'kx_s');
        }},
        // 什么值得买
        { name: "什么值得买", test: function(h){ return h.indexOf("smzdm") !== -1; }, run: function(){
            window.setTimeout(function(){
                if(!window.find("登录") && !window.find("注册")){
                    var imgs6 = document.getElementsByClassName('J_punch')[0];
                    if (imgs6 && imgs6.text.indexOf("签到领奖") === 0) { imgs6.click(); return; }
                }else{
                    alert(NOLOGIN);
                }
            },2800);
        }},
        // iYa.App 软件交流社区
        { name: "iYa.App", test: function(h){ return h.indexOf("www.iya.app") !== -1; }, run: function(){
            if (window.find("签到领奖!")) {
                window.location.href = "https://www.iya.app/plugin.php?id=dsu_paulsign:sign";
                return;
            }
            qd();
        }},
        // 阡陌居
        { name: "阡陌居", test: function(h){ return h.indexOf("1000qm") !== -1; }, run: function(){
            qd4('签到领奖!', 'kx_s');
            window.setTimeout(function(){
                toURL_once('/home.php?mod=task&do=apply&id=1')
            },2000);
        }},
        // 宽带技术网
        { name: "宽带技术网", test: function(h){ return h.indexOf("chinadsl") !== -1; }, run: function(){
            window.setTimeout(function(){
                if (isURL('home.php?mod=task&do=view&id=1')) {
                    var taskbtnEl = document.getElementsByClassName('taskbtn')[0];
                    if (taskbtnEl && taskbtnEl.href && taskbtnEl.href.indexOf("javascript") === -1) {
                        taskbtnEl.click();
                        return;
                    }
                }
            },1000);
        }},
        // 尘缘轻水 中望技术社区
        { name: "尘缘轻水/中望技术社区", test: function(h){ return h.indexOf("chenyuanqingshui") !== -1 || h.indexOf("forum.zwsoft.cn") !== -1; }, run: function(){
            window.setTimeout(function(){
                if (window.find("点击领取今天的签到奖励")) {
                    var el = $(".user-w-qd.cur")[0];
                    if (el) el.click();
                    return;
                }
            },2000);
        }},
        // LittleSkin
        { name: "LittleSkin", test: function(h){ return h.indexOf("littleskin") !== -1; }, run: function(){
            window.setTimeout(function(){
                if(window.find("签到")){
                    var el = $(".bg-gradient-primary")[0];
                    if (el) el.click();
                }
            },2000);
        }},
        // 4K世界 5A版本库 国芯 镜客居
        { name: "4K世界/5A/国芯/镜客居", test: function(h){ return h.indexOf("4ksj") !== -1 || h.indexOf("5abbk") !== -1 || h.indexOf("stcaimcu") !== -1 || h.indexOf("jkju.cc/plugin.php?id=zqlj_sign") !== -1; }, run: function(){
            if (isURL('qiandao.php') || isURL('zqlj_sign')) {
                window.setTimeout(function(){
                    var btna = document.getElementsByClassName("btna")[0];
                    if (btna && btna.textContent.indexOf("点击打卡") === 0) btna.click();
                },2000);
            }
        }},
        // iKuuu VPN
        { name: "iKuuu VPN", test: function(h){ return h.indexOf("ikuuu") !== -1; }, run: function(){
            window.setTimeout(function(){
                if (isURL('user')) {
                    if (window.find("每日签到")) {
                        var el = $(".btn-primary")[0];
                        if (el) el.click();
                        return;
                    }
                }
            },1000);
        }},
        // 国语视界 食品论坛 Anime字幕论坛 ZMX-IT
        { name: "国语视界/食品论坛/Anime字幕/ZMX-IT", test: function(h){ return h.indexOf("cnlang.org") !== -1 || h.indexOf("foodmate.net") !== -1 || h.indexOf("acgrip.com") !== -1 || h.indexOf("bbs.itzmx.com") !== -1; }, run: function(){
            if (isURL('dsu_paulsign-sign.html')) {
                if (window.find("今天签到了吗") && window.find("写下今天最想说的话")) {
                    $("#kx").click();
                    $("#todaysay").val("每天签到水一发。。。");
                    showWindow('qwindow', 'qiandao', 'post', '0');
                }
            }
        }},
        // 幻天领域
        { name: "幻天领域", test: function(h){ return h.indexOf("acgns") !== -1; }, run: function(){
            window.setTimeout(function(){
                if(window.find("签到")){
                    var el = $(".inn-nav__point-sign-daily__btn")[0];
                    if (el) el.click();
                }
            },5000);
        }},
        // 调侃网
        { name: "调侃网", test: function(h){ return h.indexOf("tiaokanwang") !== -1; }, run: function(){
            window.setTimeout(function(){
                if(window.find("今日签到")){
                    var el = $(".erphpdown-sc-btn")[0];
                    if (el) el.click();
                }
            },2000);
        }},
        // 知轩藏书 梦楠分享 道言分享网
        { name: "知轩藏书/梦楠/道言", test: function(h){ return h.indexOf("zxcsol") !== -1 || h.indexOf("mnpc.net") !== -1 || h.indexOf("lhndy.cn") !== -1; }, run: function(){
            window.setTimeout(function() {
                var checkinLinks = document.querySelectorAll('a.initiate-checkin');
                checkinLinks.forEach(function(link) {
                    if (link.textContent.includes('今日奖励') || link.textContent.includes('每日签到')) {
                        link.click();
                        return false;
                    }
                });
            }, 2000);
        }},
        // 51cto
        { name: "51cto", test: function(h){ return h.indexOf("blog.51cto.com") !== -1; }, run: function(){
            window.setTimeout(function(){
                var imgs8 = document.getElementById('sign');
                if(imgs8 && imgs8.textContent.indexOf("签到领勋章")==0){
                    $('#sign').click();
                }
            },2000);
        }},
        // 布谷TV 马克喵 咸鱼单机 小黑资源库
        { name: "布谷TV/马克喵/咸鱼单机/小黑资源库", test: function(h){ return h.indexOf("bugutv.vip/user") !== -1 || h.indexOf("macat.vip/user") !== -1 || h.indexOf("xianyudanji.to/user") !== -1 || h.indexOf("xhzyku.com/user") !== -1; }, run: function(){
            window.setTimeout(function(){
                var button = document.querySelector('.go-user-qiandao');
                if (button && button.textContent.includes('每日签到')) {
                    button.click();
                }
            },2000);
        }},
        // 典尚三维模型网
        { name: "典尚三维模型网", test: function(h){ return h.indexOf("3d.jzsc.net") !== -1; }, run: function(){
            window.setTimeout(function(){
                var el = document.getElementById("setsign");
                if (el && el.textContent.indexOf("已签到") === -1) el.click();
            },2000);
        }},
        // 知末网
        { name: "知末网", test: function(h){ return h.indexOf("znzmo.com") !== -1; }, run: function(){
            window.setTimeout(function(){
                if (isURL('usercenter_task.html?subaction=sign')) {
                    var el = $(".task_signIn_week_item_img.heartbeat")[0];
                    if (el) el.click();
                    window.setTimeout(function(){
                        var el2 = $(".signIn-progress-btn")[0];
                        if (el2) el2.click();
                    },1000);
                }
            },9500);
        }},
        // 母带吧音乐
        { name: "母带吧音乐", test: function(h){ return h.indexOf('mudaiba.com') !== -1; }, run: function(){
            window.setTimeout(function(){
                var span = document.querySelector('.m_sign');
                if (span && span.textContent === '签到') {
                    var btn = document.getElementById('m_sign');
                    if (btn) btn.click();
                }
            },2000);
        }},
        // 知音人音乐网 诺曼底影视 SteamTools
        { name: "知音人/诺曼底/SteamTools", test: function(h){ return h.indexOf("zyrhires.com") !== -1 || h.indexOf("nmandy.net") !== -1 || h.indexOf("steamtools.net") !== -1; }, run: function(){
            window.setTimeout(function(){
                var aElement = document.getElementById('dcsignin_tips');
                if (!aElement) return;
                var backgroundImage = window.getComputedStyle(aElement).getPropertyValue('background-image');
                if (!backgroundImage.includes('signin_no.png')) return;
                aElement.click();
                window.setTimeout(function() {
                    var ulElement = document.querySelector('.dcsignin_list');
                    var ninthLi = ulElement && ulElement.children[8];
                    if (ninthLi) ninthLi.click();
                    var submitButton = document.querySelector('button[name="signpn"]');
                    if (submitButton) submitButton.click();
                }, 2000);
            },2000);
        }},
        // 枫の主题社
        { name: "枫の主题社", test: function(h){ return h.indexOf('winmoes.com') !== -1; }, run: function(){
            window.setTimeout(function(){
                var el = document.getElementsByClassName('link-block')[7];
                if (el) el.click();
            },2000);
        }},
        // 游蝶网单
        { name: "游蝶网单", test: function(h){ return h.indexOf('ydwgames.com') !== -1 || h.indexOf('yamibo.com/plugin.php?id=zqlj_sign') !== -1; }, run: function(){
            window.setTimeout(function(){
                qd4('签到领奖!', 'kx_s');
            },2000);
        }},
        // 离线啦 海外单机游戏论坛
        { name: "离线啦/海外单机", test: function(h){ return h.indexOf("lixianla.com") !== -1 || h.indexOf("youxiou.com") !== -1; }, run: function(){
            window.setTimeout(function(){
                var span = document.querySelector('#sg_sign .btn-group button span');
                if (span.textContent.trim() === '签到') {
                    span.closest('button').click();
                }
            },2800);
        }},
        // 70Games
        { name: "70Games", test: function(h){ return h.indexOf("70games.net") !== -1; }, run: function(){
            window.setTimeout(function(){
                if (window.find("已签")) return;
                var el = document.getElementById('sg_sign');
                if (el) el.click();
            },2800);
        }},
        // 大海资源库
        { name: "大海资源库", test: function(h){ return h.indexOf("vip.lzzcc.cn") !== -1; }, run: function(){
            window.setTimeout(function(){
                var qiandao_element = document.getElementsByClassName('img-badge')[3];
                if (qiandao_element && qiandao_element.classList.contains("initiate-checkin")) {
                    qiandao_element.click();
                }
            },2000);
        }},
        // 苹果软件站
        { name: "苹果软件站", test: function(h){ return h.indexOf("iios.club/#/points") !== -1; }, run: function(){
            window.setTimeout(function() {
                const elements = document.querySelectorAll('div');
                elements.forEach(element => {
                    if (element.textContent === '立即签到') {
                        element.click();
                    }
                });
            }, 2000);
        }},
        // V次元
        { name: "V次元", test: function(h){ return h.indexOf("66ccff.cc") !== -1; }, run: function(){
            window.setTimeout(function() {
                var checkinLinks = document.querySelectorAll('a.initiate-checkin');
                checkinLinks.forEach(function(link) {
                    if (link.textContent.includes('签到')) {
                        link.click();
                        return false;
                    }
                });
            }, 3000);
        }},
        // OpenEdv
        { name: "OpenEdv", test: function(h){ return h.indexOf("openedv.com") !== -1; }, run: function(){
            var style = $('#dcsignin_tips').attr("style");
            if (!style || style.indexOf("signin_no") === -1) return;
            $("#dcsignin_tips").click();
            window.setTimeout(function(){
                var li8 = $(".dcsignin_list li")[8];
                var pnc0 = $('.pnc')[0];
                if (li8) li8.click();
                $('#emotid').val('8');
                if (pnc0) pnc0.click();
            },2000);
        }},
        // 掘金 签到
        { name: "掘金(签到)", test: function(h){ return h.indexOf("juejin.cn/user/center/signin") !== -1; }, run: function(){
            window.setTimeout(function() {
                const buttons = document.querySelectorAll('.signin.btn');
                buttons.forEach(button => {
                    if (button.textContent.includes('立即签到')) {
                        button.click();
                    }
                });
            }, 1000);
        }},
        // 掘金 免费自动抽奖
        { name: "掘金(抽奖)", test: function(h){ return h.indexOf("juejin.cn/user/center/lottery?from=sign_in_success") !== -1; }, run: function(){
            window.setTimeout(function() {
                const buttons = document.querySelectorAll('button');
                Array.from(buttons).find(button => button.textContent.includes('去抽奖'))?.click();
                var turntable = document.getElementById('turntable-item-0');
                if (turntable && turntable.querySelector('.text-free')) {
                    turntable.click();
                }
            }, 1000);
        }},
        // X64论坛
        { name: "X64论坛", test: function(h){ return h.indexOf("ome.x64bbs.cn") !== -1; }, run: function(){
            window.setTimeout(function() {
                var divUm = document.getElementById('um');
                var links = divUm.getElementsByTagName('a');
                for (var i = 0; i < links.length; i++) {
                    if (links[i].textContent.includes('打卡签到')) {
                        links[i].click();
                        return;
                    }
                }
            }, 2000);
        }},
        // 工控人家园
        { name: "工控人家园", test: function(h){ return h.indexOf("ymmfa.com/read-gktid-142599.html") !== -1; }, run: function(){
            window.setTimeout(function() {
                const chinaTime = new Date().toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' });
                const today = chinaTime.split(' ')[0];
                const time1 = GM_getValue('time1', '');
                const time2 = GM_getValue('time2', '');
                const isTime2Today = time2.split(' ')[0] === today;
                if (!isTime2Today && !time1) {
                    const link1 = document.getElementById('url_1');
                    if (link1) {
                        link1.click();
                        GM_setValue('time1', chinaTime);
                    }
                } else {
                    const time1Date = new Date(time1);
                    const now = new Date(chinaTime);
                    const diffInMinutes = (now - time1Date) / 60000;
                    if(!isTime2Today){
                        const checkCondition = () => {
                            const currentTime = new Date().toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' });
                            const currentTimeDate = new Date(currentTime);
                            const time1Date = new Date(time1);
                            const diffInMinutes = (currentTimeDate - time1Date) / 60000;

                            if (diffInMinutes > 60) {
                                const link2 = document.getElementById('url_2');
                                if (link2) {
                                    link2.click();
                                    GM_setValue('time2', currentTime);
                                    GM_setValue('time1', '');
                                    alert(QIANDAO);
                                }
                            } else {
                                setTimeout(checkCondition, 10 * 60 * 1000);
                            }
                        };
                        checkCondition();
                    }
                }
            }, 1000);
        }},
        // 補檔冰室
        { name: "補檔冰室", test: function(h){ return h.indexOf("manhuabudangbbs.com/u.php") !== -1; }, run: function(){
            window.setTimeout(function() {
                var punchElement = document.getElementById('punch');
                if (punchElement && (punchElement.textContent.includes('每日打卡') || punchElement.textContent.includes('未打卡')) ) {
                    punchElement.click();
                }
            }, 2000);
        }},
        // 理想股票技术论坛
        { name: "理想股票技术论坛", test: function(h){ return h.indexOf("55188.com/plugin.php?id=sign") !== -1; }, run: function(){
            window.setTimeout(function(){
                if (!window.find("您今天还没有签到哦")) return;
                var el = document.getElementById('addsign');
                if (el) el.click();
            },1000);
        }},
        // 星空论坛
        { name: "星空论坛", test: function(h){ return h.indexOf("seikuu.com") !== -1; }, run: function(){
            window.setTimeout(function(){
                var kx = document.getElementById("kx");
                var todaySayTextArea = document.getElementById("todaysay");
                if (kx) kx.click();
                if (todaySayTextArea) todaySayTextArea.value = "今天天气真好~签到。";
                if (typeof unsafeWindow !== "undefined" && unsafeWindow.showWindow) unsafeWindow.showWindow('qwindow', 'qiandao', 'post', '0');
            },10000);
        }},
        // 菁优网
        { name: "菁优网", test: function(h){ return h.indexOf("jyeoo.com/profile") !== -1; }, run: function(){
            window.setTimeout(function(){
                var signEl = document.getElementById('sign');
                if (signEl && signEl.textContent === '立即签到') signEl.click();
            },2000);
        }},
        // 多看聚影 品技 港知堂社区
        { name: "多看聚影/品技/港知堂", test: function(h){ return h.indexOf("duokan.club/sign.php") !== -1 || h.indexOf("tekqart.com/plugin.php?id=zqlj_sign") !== -1 || h.indexOf("gztown.org") !== -1; }, run: function(){
            window.setTimeout(function() {
                var btna = document.getElementsByClassName('btna')[0];
                if (btna && btna.textContent.includes('点击打卡')) btna.click();
            }, 1000);
        }},
        // 飞浆
        { name: "飞浆", test: function(h){ return h.indexOf("aistudio.baidu.com") !== -1; }, run: function(){
            window.setTimeout(function() {
                var hoverElement = document.querySelector('.a-s-header-tool-item.header-tool-item-console');
                if (hoverElement) {
                    var mouseoverEvent = new MouseEvent('mouseover', {
                        bubbles: true,
                        cancelable: true
                    });
                    hoverElement.dispatchEvent(mouseoverEvent);
                    window.setTimeout(function() {
                        var titleElement = document.querySelector('.user-sign-highlight .user-sign-item-title');
                        if (titleElement && titleElement.textContent.includes('签到')) {
                            titleElement.closest('.user-sign-highlight').click();
                        }
                    }, 1000);
                }
            }, 3000);
        }},
        // 洛谷
        { name: "洛谷", test: function(h){ return h.indexOf("luogu.com.cn") !== -1; }, run: function(){
            window.setTimeout(function(){
                var am_btn = document.getElementsByClassName('am-btn-warning')[0];
                if (am_btn && am_btn.textContent === '点击打卡') am_btn.click();
            },2000);
        }},
        // 小白游戏网
        { name: "小白游戏网", test: function(h){ return h.indexOf("xbgame.net/task") !== -1; }, run: function(){
            window.setTimeout(function(){
                var el = document.getElementsByClassName('link-block')[3];
                if (el) el.click();
            },2000);
        }},
        // apk.tw
        { name: "apk.tw", test: function(h){ return h.indexOf("apk.tw") !== -1; }, run: function(){
            window.setTimeout(function(){
                function eventFire(el, etype){
                    if (el.fireEvent) {
                        el.fireEvent('on' + etype);
                    } else {
                        var evObj = document.createEvent('Events');
                        evObj.initEvent(etype, true, false);
                        el.dispatchEvent(evObj);
                    }
                }
                var amupper = document.getElementById('my_amupper');
                if (amupper) eventFire(amupper, 'click');
                document.cookie = 'adblock_forbit=1;expires=0';
            },1000);
        }},
        // fotor
        { name: "fotor", test: function(h){ return h.indexOf("fotor.com/cn/rewards") !== -1 || h.indexOf("fotor.com/tw/rewards") !== -1; }, run: function(){
            window.setTimeout(function(){
                // 综合特征检测
                const candidate = Array.from(document.querySelectorAll('button')).find(btn => {
                    return (btn.textContent.includes('立即领取') || btn.textContent.includes('立即領取')) &&
                        btn.querySelector('span.PointsActivityPageSection_credits__104Wy') &&
                        btn.closest('[class*="dailyCheckIn"]');
                });
                if (candidate) {
                    candidate.click();
                }
            },3000);
        }},
        // 菜玩社区
        { name: "菜玩社区", test: function(h){ return h.indexOf("caigamer.cn") !== -1; }, run: function(){
            window.setTimeout(function(){
                var sign_span = document.getElementById('sign_title');
                if (sign_span && sign_span.textContent.indexOf("立即签到") > 0) sign_span.click();
            },2000);
        }},
        // MineBBS我的世界中文论坛
        { name: "MineBBS", test: function(h){ return h.indexOf("minebbs.com") !== -1; }, run: function(){
            window.setTimeout(function(){
                var button_cta = document.getElementsByClassName('button--cta')[0];
                if(button_cta && button_cta.textContent.indexOf("每日签到")==0){
                    button_cta.click();
                }
            },2000);
        }},
        // 三宫六院
        { name: "三宫六院", test: function(h){ return h.indexOf("sglynp") !== -1; }, run: function(){
            window.setTimeout(function(){
                if (window.find("已签到")) return;
                var topb = document.getElementById('k_misign_topb');
                var link = topb && topb.querySelector('a');
                if (link) { link.click(); location.reload(); }
                setTimeout(function() {
                    window.location.href = 'https://www.sglynp.com/home.php?mod=space&do=notice&view=system';
                }, 1000 + Math.random() * 2000);
            },2000);
        }},
        // 绯月ScarletMoon
        { name: "绯月ScarletMoon", test: function(h){ return h.indexOf("kfpromax.com/kf_growup.php") !== -1; }, run: function(){
            window.setTimeout(function(){
                if (window.find("今天的每日奖励已经领过了")) return;
                var el = document.querySelector('a[href*="kf_growup.php?ok=3"]');
                if (el) el.click();
            },2000);
        }},
        // 精易论坛
        { name: "精易论坛", test: function(h){ return h.indexOf("bbs.125.la/plugin.php?id=dsu_paulsign:sign") !== -1; }, run: function(){
            window.setTimeout(function(){
                if (!window.find("您今日已经签到")) {
                    window.location.href = 'https://bbs.125.la/';
                    return;
                }
                var signEl = document.getElementById('sign');
                if (signEl) signEl.click();
                setTimeout(function() {
                    var layerBtn = document.querySelector('a.layui-layer-btn0');
                    if (layerBtn) layerBtn.click();
                }, 1000 + Math.random() * 2000);
            },2000);
        }},
        // 鲲Galgame
        { name: "鲲Galgame", test: function(h){ return h.indexOf("kungal") !== -1; }, run: function(){
            window.setTimeout(() => {
                document.querySelector('div[data-v-729e1e50] > div.cursor-pointer')?.click();
                const signInBtn = document.evaluate('//button[contains(text(),"每日签到")]', document).iterateNext()
                || document.querySelector('button.text-secondary')
                || document.querySelector('div.func button:nth-child(3)');
                if(signInBtn?.disabled === false) {
                    signInBtn.click();
                    location.reload();
                    setTimeout(() => {
                        document.querySelector('div[data-v-729e1e50] > div.cursor-pointer')?.click();
                    }, 1000 + Math.random() * 2000);
                    console.log('签到成功');
                } else {
                    console.log('鲲Galgame未找到每日签到按钮，可能是:\n1.已签到完成；\n2.菜单没有展开；\n3.被弹窗遮挡；\n4.文本代码没加载；\n5.网站代码更新了,给我提交反馈。');
                }
            }, 2000);
        }},
        // 雨中小町
        { name: "雨中小町", test: function(h){ return h.indexOf("rainkmc") !== -1; }, run: function(){
            window.setTimeout(function(){
                if (window.find("连续签到")){
                    return;
                }else{
                    document.querySelector('.punch_btn').click();
                    setTimeout(() => {
                        location.reload();
                    }, 1000 + Math.random() * 2000);
                }
            },2000);
        }},
        // 人人影视
        { name: "人人影视", test: function(h){ return h.indexOf("yysub") !== -1; }, run: function(){
            window.setTimeout(function(){
                setTimeout(() => {
                    location.reload();
                }, 1000 + Math.random() * 2000);
            },2000);
        }},
        // 141华人社区
        { name: "141华人社区", test: function(h){ return h.indexOf("141love.net/forum.php") !== -1; }, run: function(){
            window.setTimeout(function(){
                if (document.querySelector('img[src*="pperwb.gif"]')) {
                    return;
                }else{
                    document.querySelector('img[onclick="showWindow(\'pper\', \'dsu_amupper-ppering\');"]').click();
                    setTimeout(() => document.querySelector('.pn.pnc').click(), 500);
                    setTimeout(() => document.querySelector('#myprompt').click(), 500);
                    document.querySelector('#myprompt').click();
                }
            },2000);
        }},
        // 夸父资源社
        { name: "夸父资源社", test: function(h){ return h.indexOf("kuafuzys.com") !== -1; }, run: function(){
            window.setTimeout(function(){
                var tt_sign = document.getElementById("tt_sign");
                if (!tt_sign) return;
                if (tt_sign.textContent.indexOf("登录") !== -1) { alert(NOLOGIN); return; }
                if (tt_sign.textContent.indexOf("立即签到") !== -1) { tt_sign.click(); return; }
            },2000);
        }},
        // JoinQuant
        { name: "JoinQuant", test: function(h){ return h.indexOf("joinquant.com/view/user/floor") !== -1; }, run: function(){
            window.setTimeout(function(){
                var btn = document.getElementsByClassName("menu-credit-button")[0];
                if (btn && btn.textContent.indexOf("签到领积分") !== -1) btn.click();
            },2000);
        }},
        // HadSky 任务页
        { name: "HadSky(任务页)", test: function(h){ return h.indexOf("hadsky.com/app-puyuetian_phptask-index.html") !== -1; }, run: function(){
            window.setTimeout(function(){
                function clickAllRewardButtons() {
                    const buttons = document.querySelectorAll('button.btn.get');
                    let clickedCount = 0;

                    buttons.forEach(button => {
                        const span = button.querySelector('span');
                        if (span) {
                            const text = span.textContent.replace(/\s+/g, '');
                            if (text.includes('领取奖励')) {
                                button.click();
                                clickedCount++;
                                return new Promise(resolve => setTimeout(resolve, 1000));
                            }
                        }
                    });
                    return clickedCount;
                }
                clickAllRewardButtons();
            },2000);
        }},
        // HadSky
        { name: "HadSky", test: function(h){ return h.indexOf("hadsky.com") !== -1; }, run: function(){
            window.setTimeout(function(){
                const signButton = document.querySelector("img.pk-hadsky");
                if (signButton) {
                    if (signButton.src.includes("NcnZla.png")) {
                        signButton.click();
                    }
                }
            },2000);
        }},
        // 杉果游戏
        { name: "杉果游戏", test: function(h){ return h.indexOf('sonkwo.cn') !== -1; }, run: function(){
            window.setTimeout(function(){
                var el = document.getElementsByClassName('store_user_card_action_check')[0];
                if (el) el.click();
            },2000);
        }},
        // 再漫画
        { name: "再漫画", test: function(h){ return h.indexOf('i.zaimanhua.com') !== -1; }, run: function(){
            window.setTimeout(function(){
                var el = document.getElementsByClassName('ant-btn-primary')[0];
                if (el) el.click();
            },2000);
        }},
        // 不忘初心系统博客
        { name: "不忘初心系统博客", test: function(h){ return h.indexOf('pc528.net/user-center.html?pd=qiandao') !== -1; }, run: function(){
            window.setTimeout(function(){
                var el = document.getElementById("qiandao_ajax");
                if (el) el.click();
            },2000);
        }},
        // 恩山无线论坛
        { name: "恩山无线论坛", test: function(h){ return h.indexOf('right.com.cn/forum/erling_qd-sign_in.html') !== -1; }, run: function(){
            window.setTimeout(function(){
                var el = document.getElementById("signin-btn");
                if (el) el.click();
            },2000);
        }},
        // 阿里云开发者社区
        { name: "阿里云开发者社区-领积分", test: function(h){ return h.indexOf('developer.aliyun.com/score') !== -1; }, run: function(){
            setTimeout(() => {
                const row = Array.from(document.querySelectorAll('.user-level-bottom-box-wrapper'))
                .find(el => el.innerText.includes('待领取积分'));
                const num = parseInt(row?.querySelector('.user-level-bottom-box-wrapper-num')?.innerText);
                if (num > 0) row.querySelector('button')?.click();
            }, 3300);
        }},
        { name: "阿里云开发者社区", test: function(h){ return h.indexOf('developer.aliyun.com') !== -1; }, run: function(){
            setTimeout(() => {
                const btn = document.querySelector('.unlogin .today-text')?.closest('.unlogin');
                if (window.find("退出登录") && btn && !btn.innerText.includes('签到')) {
                    btn.click();
                    // 延迟1秒点击弹窗确认
                    setTimeout(() => document.querySelector('.next-dialog-footer .next-btn-primary')?.click(), 1000);
                }
            }, 2200);
        }},
        { name: "链滴", test: function(h){ return h.indexOf('ld246.com/activity/checkin') !== -1; }, run: function(){
            setTimeout(() => {
                const checkinBtn = Array.from(document.querySelectorAll('a.btn.green'))
                .find(el => el.textContent.includes('领取今日签到奖励'));
                if (checkinBtn) {
                    checkinBtn.click();
                }
            }, 2200);
        }},
        { name: "网易云游戏", test: function(h){ return h.indexOf('cg.163.com') !== -1; }, run: function(){
            setTimeout(() => {
                const btn = document .querySelector( '.checkin-main .g-Btn-green2' );
                if (btn && btn.innerText.includes( '签到' )) {
                    btn.click();
                }
            }, 2000);
        }},
        { name: "修系统", test: function(h){ return h.indexOf('xiuxitong.com') !== -1; }, run: function(){
            setTimeout(() => {
                const btn1 = document.querySelector('.checkin-btn-area a.checkin-btn');
                if (btn1) {
                    if (btn1.innerText.includes('登录签到') || btn1.outerHTML.includes('loginbox')) {
                        alert('提示：当前尚未登录，请先登录！');
                    } else if (btn1.innerText.includes('立即签到') || btn1.outerHTML.includes('pd=sign')) {
                        btn1.click();
                    }
                }
                const btn2 = document.querySelector('a.usercheck.erphp-checkin');
                if (btn2 && !btn2.classList.contains('disabled') && !btn2.classList.contains('active')) {
                    if (btn2.innerText.includes('今日签到')) {
                        btn2.click();
                    }
                }
            }, 2000);
        }},
        { name: "海绵科创", test: function(h){ return h.indexOf('yunmc.vip/addons?_plugin=points_mall&_controller=index&_action=index') !== -1; }, run: function(){
            setTimeout(() => {
                const signBtn = document.querySelector('button[onclick*="sign()"]');
                if (signBtn && signBtn.innerText.includes('立即签到')) {
                    signBtn.click();
                }
            }, 2000);
        }}
    ];
    var href = window.location.href;
    for (var i = 0; i < SITES.length; i++) {
        if (SITES[i].test(href)) {
            SITES[i].run();
            return;
        }
    }
    if (document.getElementById("kx")) qd2();
    if (typeof p !== "undefined" && p && p.elements) qd3();
})();

//传递的url和当前url是否包含
function isURL(x) {
    return window.location.href.indexOf(x) !== -1;
}

//跳转到传递的地址
function toURL(x) {
    window.location.href=x;
}

function qd() {
    if (window.find("今天签到了吗") && window.find("写下今天最想说的话")) {
        var kxImg = document.getElementById("kx_s");
        var todaySayTextArea = document.getElementById("todaysay");
        if (kxImg == null) {
            return;
        }
        kxImg.setAttribute('checked', true);
        todaySayTextArea.value = "今天天气真好~签到。";
        var button = document.getElementById("qiandao");
        if (!button) return;
        button.submit();
        return;
    }
}

function qd2() {
    var kx = document.getElementById("kx");
    if (!kx) return;
    kx.click();
    var todaySayTextArea = document.getElementById("todaysay");
    if (todaySayTextArea) todaySayTextArea.value = "今天天气真好~签到。";
    if (typeof unsafeWindow !== "undefined" && unsafeWindow.showWindow) unsafeWindow.showWindow('qwindow', 'qiandao', 'post', '0');
}

function qd3() {
    var elements = p.elements,i = 0;
    setTimeout(function () {
        try {
            var els;
            if (elements instanceof Array){ els = p.elements;}
            else {
                els = p.elements();
            }
            while (els[i]) {
                var obj = (p.elements instanceof Array) ? document.querySelector(els[i]) : els[i];
                if (obj == null) return;
                if (obj.tagName === "A" && obj.href.indexOf("javascript") < 0 && obj.onclick === "undefined") GM_openInTab(obj.href);
                else obj.click();
                i++;
            }
        } catch (e) {
            alert(e);
        }
    }, 400);
    setTimeout(function () {
        if (autoClose) window.close();
    }, delay + 100);
    return;
}

function qd4(checkElement, emojiImg) {
    if (isURL('dsu_paulsign:sign') || isURL('dsu_paulsign-sign.html') || isURL('hack.php?H_name=qiandao')) {
        if ((window.find("今天签到了吗") && window.find("写下今天最想说的话")) || window.find("今天未签到")) {
            $("#" + emojiImg).attr('checked', true);
            $("#todaysay").val("每天签到水一发。。。");
            if ($("#qiandao").length) $("#qiandao").submit();
        }
    } else if (window.find(checkElement)) {
        toURL("plugin.php?id=dsu_paulsign:sign");
    }
}

function qd5(checkElement, emojiImg) {
    if (isURL('dsu_paulsign-sign.html')) {
        if (window.find("今天签到了吗") && window.find("写下今天最想说的话")) {
            $("#" + emojiImg).click();
            $("#todaysay").val("每天签到水一发。。。");
            if ($("#qiandao").length) $("#qiandao").submit();
        }
    } else if (window.find(checkElement)) {
        toURL("dsu_paulsign-sign.html");
    }
}

function toURL_once(url,name='time'){
    const t = new Date();
    const time = [t.getFullYear(),t.getMonth()+1,t.getDate()].join("/");
    const itemName = "qd_"+name;
    if (localStorage.getItem(itemName) !== time) {
        localStorage.setItem(itemName,time);
        toURL(url);
    }
}

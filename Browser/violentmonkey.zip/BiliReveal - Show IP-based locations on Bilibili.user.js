// ==UserScript==
// @name                 BiliReveal - 哔哩哔哩网页版显示 IP 属地
// @name:zh-Hans         BiliReveal - 哔哩哔哩网页版显示 IP 属地
// @name:zh-Hant         BiliReveal - 嗶哩嗶哩網頁版顯示 IP 屬地
// @name:en              BiliReveal - Show IP-based locations on Bilibili
// @name:ja              BiliReveal - BilibiliのWeb版でIP所在地を表示
// @name:th              BiliReveal - แสดงพื้นที่ตาม IP บนเว็บ Bilibili
// @name:ar              BiliReveal - عرض الموقع الجغرافي حسب IP على ويب Bilibili
// @name:pt              BiliReveal - Mostrar localização por IP no Bilibili
// @name:es              BiliReveal - Mostrar la ubicación por IP en Bilibili
// @name:id              BiliReveal - Tampilkan lokasi berdasarkan IP di Bilibili
// @name:ms              BiliReveal - Paparkan lokasi berdasarkan IP di Bilibili
// @name:ru              BiliReveal - Показывать местоположение по IP на Bilibili
// @name:tr              BiliReveal - Bilibili web sürümünde IP konumunu göster
// @name:vi              BiliReveal - Hiển thị vị trí theo IP trên web Bilibili
// @name:zh-CN           BiliReveal - 哔哩哔哩网页版显示 IP 属地
// @name:zh-SG           BiliReveal - 哔哩哔哩网页版显示 IP 属地
// @name:zh-TW           BiliReveal - 嗶哩嗶哩網頁版顯示 IP 屬地
// @name:zh-HK           BiliReveal - 嗶哩嗶哩網頁版顯示 IP 屬地
// @name:zh-MO           BiliReveal - 嗶哩嗶哩網頁版顯示 IP 屬地
// @namespace            http://zhangmaimai.com
// @version              2.4.0
// @author               MaxChang3
// @description          我不喜欢 IP 属地，但是你手机都显示了，为什么电脑不显示呢？在哔哩哔哩网页版大部分场景中显示 IP 属地。
// @description:zh-Hans  我不喜欢 IP 属地，但是你手机都显示了，为什么电脑不显示呢？在哔哩哔哩网页版大部分场景中显示 IP 属地。
// @description:zh-Hant  我不喜歡 IP 屬地，但是你手機都顯示了，為什麼電腦不顯示呢？在嗶哩嗶哩網頁版大部分場景中顯示 IP 屬地。
// @description:en       I don't like IP location labels, but if they're shown on mobile, why not on the web? Show IP locations across most Bilibili web pages.
// @description:ja       IP所在地の表示は好きではありませんが、スマホで表示されるなら、パソコンでも表示してよいのでは？BilibiliのWeb版のさまざまなページでIP所在地を表示します。
// @description:th       ฉันไม่ชอบการแสดงพื้นที่ตาม IP แต่ในเมื่อแสดงบนมือถือแล้ว ทำไมบนคอมพิวเตอร์จะไม่แสดงบ้างล่ะ? แสดงพื้นที่ตาม IP ในหน้าส่วนใหญ่ของเว็บ Bilibili
// @description:ar       لا أحب عرض الموقع الجغرافي حسب عنوان IP، لكن ما دام يظهر على الهاتف، فلماذا لا يظهر على الكمبيوتر؟ يعرض الموقع الجغرافي حسب IP في معظم صفحات موقع Bilibili.
// @description:pt       Não gosto de rótulos de localização por IP, mas, se aparecem no celular, por que não no computador? Exibe a localização por IP na maioria das páginas do Bilibili na web.
// @description:es       No me gustan las etiquetas de ubicación por IP, pero, si aparecen en el móvil, ¿por qué no en el ordenador? Muestra la ubicación por IP en la mayoría de las páginas web de Bilibili.
// @description:id       Saya tidak suka label lokasi berdasarkan IP, tetapi jika sudah muncul di ponsel, mengapa tidak di komputer? Menampilkan lokasi berdasarkan IP di sebagian besar halaman web Bilibili.
// @description:ms       Saya tidak suka label lokasi berdasarkan IP, tetapi jika ia dipaparkan pada telefon, mengapa tidak pada komputer? Memaparkan lokasi berdasarkan IP pada kebanyakan halaman web Bilibili.
// @description:ru       Мне не нравятся метки местоположения по IP, но если они видны на телефоне, почему их нет на компьютере? Показывает местоположение по IP на большинстве страниц веб-версии Bilibili.
// @description:tr       IP konumu etiketlerini sevmiyorum ama telefonda gösteriliyorsa neden bilgisayarda gösterilmesin? Bilibili web sürümünün çoğu sayfasında IP konumunu gösterir.
// @description:vi       Tôi không thích nhãn vị trí theo IP, nhưng điện thoại đã hiển thị rồi thì tại sao máy tính lại không? Hiển thị vị trí theo IP trên hầu hết các trang web Bilibili.
// @description:zh-CN    我不喜欢 IP 属地，但是你手机都显示了，为什么电脑不显示呢？在哔哩哔哩网页版大部分场景中显示 IP 属地。
// @description:zh-SG    我不喜欢 IP 属地，但是你手机都显示了，为什么电脑不显示呢？在哔哩哔哩网页版大部分场景中显示 IP 属地。
// @description:zh-TW    我不喜歡 IP 屬地，但是你手機都顯示了，為什麼電腦不顯示呢？在嗶哩嗶哩網頁版大部分場景中顯示 IP 屬地。
// @description:zh-HK    我不喜歡 IP 屬地，但是你手機都顯示了，為什麼電腦不顯示呢？在嗶哩嗶哩網頁版大部分場景中顯示 IP 屬地。
// @description:zh-MO    我不喜歡 IP 屬地，但是你手機都顯示了，為什麼電腦不顯示呢？在嗶哩嗶哩網頁版大部分場景中顯示 IP 屬地。
// @license              MIT
// @icon                 https://www.bilibili.com/favicon.ico
// @match                https://t.bilibili.com/*
// @match                https://www.bilibili.com/opus/*
// @match                https://space.bilibili.com/*
// @match                https://www.bilibili.com/cheese/play/*
// @match                https://www.bilibili.com/festival/*
// @match                https://www.bilibili.com/blackboard/*
// @match                https://www.bilibili.com/blackroom/ban/*
// @match                https://www.bilibili.com/read/*
// @match                https://www.bilibili.com/v/topic/detail*
// @match                https://live.bilibili.com/*
// @match                https://www.bilibili.com/video/*
// @match                https://www.bilibili.com/zh-Hans/video/*
// @match                https://www.bilibili.com/zh-Hant/video/*
// @match                https://www.bilibili.com/en/video/*
// @match                https://www.bilibili.com/ja/video/*
// @match                https://www.bilibili.com/th/video/*
// @match                https://www.bilibili.com/ar/video/*
// @match                https://www.bilibili.com/pt/video/*
// @match                https://www.bilibili.com/es/video/*
// @match                https://www.bilibili.com/id/video/*
// @match                https://www.bilibili.com/ms/video/*
// @match                https://www.bilibili.com/ru/video/*
// @match                https://www.bilibili.com/tr/video/*
// @match                https://www.bilibili.com/vi/video/*
// @match                https://www.bilibili.com/list/*
// @match                https://www.bilibili.com/zh-Hans/list/*
// @match                https://www.bilibili.com/zh-Hant/list/*
// @match                https://www.bilibili.com/en/list/*
// @match                https://www.bilibili.com/ja/list/*
// @match                https://www.bilibili.com/th/list/*
// @match                https://www.bilibili.com/ar/list/*
// @match                https://www.bilibili.com/pt/list/*
// @match                https://www.bilibili.com/es/list/*
// @match                https://www.bilibili.com/id/list/*
// @match                https://www.bilibili.com/ms/list/*
// @match                https://www.bilibili.com/ru/list/*
// @match                https://www.bilibili.com/tr/list/*
// @match                https://www.bilibili.com/vi/list/*
// @match                https://www.bilibili.com/bangumi/play/*
// @match                https://www.bilibili.com/zh-Hans/bangumi/play/*
// @match                https://www.bilibili.com/zh-Hant/bangumi/play/*
// @match                https://www.bilibili.com/en/bangumi/play/*
// @match                https://www.bilibili.com/ja/bangumi/play/*
// @match                https://www.bilibili.com/th/bangumi/play/*
// @match                https://www.bilibili.com/ar/bangumi/play/*
// @match                https://www.bilibili.com/pt/bangumi/play/*
// @match                https://www.bilibili.com/es/bangumi/play/*
// @match                https://www.bilibili.com/id/bangumi/play/*
// @match                https://www.bilibili.com/ms/bangumi/play/*
// @match                https://www.bilibili.com/ru/bangumi/play/*
// @match                https://www.bilibili.com/tr/bangumi/play/*
// @match                https://www.bilibili.com/vi/bangumi/play/*
// @match                https://www.bilibili.com/v/topic/detail/*
// @match                https://www.bilibili.com/zh-Hans/v/topic/detail/*
// @match                https://www.bilibili.com/zh-Hant/v/topic/detail/*
// @match                https://www.bilibili.com/en/v/topic/detail/*
// @match                https://www.bilibili.com/ja/v/topic/detail/*
// @match                https://www.bilibili.com/th/v/topic/detail/*
// @match                https://www.bilibili.com/ar/v/topic/detail/*
// @match                https://www.bilibili.com/pt/v/topic/detail/*
// @match                https://www.bilibili.com/es/v/topic/detail/*
// @match                https://www.bilibili.com/id/v/topic/detail/*
// @match                https://www.bilibili.com/ms/v/topic/detail/*
// @match                https://www.bilibili.com/ru/v/topic/detail/*
// @match                https://www.bilibili.com/tr/v/topic/detail/*
// @match                https://www.bilibili.com/vi/v/topic/detail/*
// @match                https://manga.bilibili.com/detail/*
// @match                https://manga.bilibili.com/zh-Hans/detail/*
// @match                https://manga.bilibili.com/zh-Hant/detail/*
// @match                https://manga.bilibili.com/en/detail/*
// @match                https://manga.bilibili.com/ja/detail/*
// @match                https://manga.bilibili.com/th/detail/*
// @match                https://manga.bilibili.com/ar/detail/*
// @match                https://manga.bilibili.com/pt/detail/*
// @match                https://manga.bilibili.com/es/detail/*
// @match                https://manga.bilibili.com/id/detail/*
// @match                https://manga.bilibili.com/ms/detail/*
// @match                https://manga.bilibili.com/ru/detail/*
// @match                https://manga.bilibili.com/tr/detail/*
// @match                https://manga.bilibili.com/vi/detail/*
// @grant                GM.setValue
// @grant                GM_getValue
// @grant                GM_info
// @grant                GM_registerMenuCommand
// @grant                GM_setClipboard
// @grant                GM_setValue
// @grant                GM_unregisterMenuCommand
// @grant                unsafeWindow
// @run-at               document-start
// @downloadURL https://update.greasyfork.org/scripts/466815/BiliReveal%20-%20%E5%93%94%E5%93%A9%E5%93%94%E5%93%A9%E7%BD%91%E9%A1%B5%E7%89%88%E6%98%BE%E7%A4%BA%20IP%20%E5%B1%9E%E5%9C%B0.user.js
// @updateURL https://update.greasyfork.org/scripts/466815/BiliReveal%20-%20%E5%93%94%E5%93%A9%E5%93%94%E5%93%A9%E7%BD%91%E9%A1%B5%E7%89%88%E6%98%BE%E7%A4%BA%20IP%20%E5%B1%9E%E5%9C%B0.meta.js
// ==/UserScript==

(function() {
	"use strict";
	var _GM = (() => typeof GM != "undefined" ? GM : void 0)();
	var _GM_getValue = (() => typeof GM_getValue != "undefined" ? GM_getValue : void 0)();
	var _GM_info = (() => typeof GM_info != "undefined" ? GM_info : void 0)();
	var _GM_registerMenuCommand = (() => typeof GM_registerMenuCommand != "undefined" ? GM_registerMenuCommand : void 0)();
	var _GM_setClipboard = (() => typeof GM_setClipboard != "undefined" ? GM_setClipboard : void 0)();
	var _GM_setValue = (() => typeof GM_setValue != "undefined" ? GM_setValue : void 0)();
	var _GM_unregisterMenuCommand = (() => typeof GM_unregisterMenuCommand != "undefined" ? GM_unregisterMenuCommand : void 0)();
	var _unsafeWindow = (() => typeof unsafeWindow != "undefined" ? unsafeWindow : void 0)();
	var REPLACEMENTS_KEY = "locationReplacements";
	var safeJSONParse = (text, defaultValue) => {
		try {
			return JSON.parse(text);
		} catch {
			return defaultValue;
		}
	};
	var parseReplacements = (rawJson) => {
		const parsed = safeJSONParse(rawJson || _GM_getValue("locationReplacements", "{}"), {});
		return new Map(Object.entries(parsed));
	};
	var replacements = parseReplacements();
	var DEBUG_MODE_KEY = "bili_reveal_debug_mode";
	var LOG_VERSION = 1;
	var isDebugMode = _GM_getValue(DEBUG_MODE_KEY, false);
	var memoryLogs = [];
	var logger = {
		log: (level, ...args) => {
			if (!isDebugMode) {
				if (level === "error") console.error("[BiliReveal]", ...args);
				return;
			}
			(level === "error" ? console.error : level === "warn" ? console.warn : console.log)(`[BiliReveal][${level.toUpperCase()}]`, ...args);
			try {
				const MAX_LOGS = 1e3;
				const logString = `[${new Date().toLocaleTimeString()}] [${level.toUpperCase()}] ${args.map((a) => typeof a === "object" ? JSON.stringify(a) : String(a)).join(" ")}`;
				memoryLogs.push(logString);
				if (memoryLogs.length > MAX_LOGS) memoryLogs = memoryLogs.slice(-1e3);
				updateLogMenu();
			} catch (e) {
				console.error("Failed to process log", e);
			}
		},
		debug: (...args) => logger.log("debug", ...args),
		info: (...args) => logger.log("info", ...args),
		warn: (...args) => logger.log("warn", ...args),
		error: (...args) => logger.log("error", ...args),
		incrementIpCount: () => {
			if (ipInjectCount === 0) logger.info("[IP属地插入] 首次成功解析并插入 IP 属地");
			ipInjectCount++;
			updateLogMenu();
		}
	};
	var ipInjectCount = 0;
	var logMenuId;
	var menuUpdateTimer = null;
	var updateLogMenu = () => {
		if (!isDebugMode || false) return;
		if (menuUpdateTimer) clearTimeout(menuUpdateTimer);
		menuUpdateTimer = setTimeout(() => {
			const count = memoryLogs.length;
			if (logMenuId !== void 0) try {
				_GM_unregisterMenuCommand(logMenuId);
			} catch {}
			logMenuId = _GM_registerMenuCommand(`📄 复制本页日志 (${count})`, () => {
				if (memoryLogs.length === 0) return;
				_GM_setClipboard([
					`=== BiliReveal Debug Info v${LOG_VERSION}===`,
					`Script Version: ${_GM_info?.script?.version || "Unknown"} (Lite: false)`,
					`Script Handler: ${_GM_info?.scriptHandler || "Unknown"} v${_GM_info?.version || "Unknown"}`,
					`User Agent: ${navigator.userAgent}`,
					`URL: ${location.href}`,
					`Time: ${new Date().toLocaleDateString("sv-SE")}`,
					`IP Insertions: ${ipInjectCount}`,
					`=============================`,
					""
				].join("\n") + memoryLogs.join("\n"), "text");
			});
		}, 100);
	};
	var isElementLoaded = async (selector, root = document) => {
		const getElement = () => root.querySelector(selector);
		return new Promise((resolve) => {
			const element = getElement();
			if (element) {
				logger.debug(`[DOM] 元素就绪 (瞬时): ${selector}`);
				return resolve(element);
			}
			logger.debug(`[DOM] 等待元素渲染: ${selector}`);
			const observer = new MutationObserver(() => {
				const element = getElement();
				if (!element) return;
				logger.debug(`[DOM] 元素就绪 (异步): ${selector}`);
				resolve(element);
				observer.disconnect();
			});
			const target = root === document ? root.documentElement ?? root : root;
			observer.observe(target, {
				childList: true,
				subtree: true
			});
		});
	};
	var preprocessLocation = (location) => {
		if (!location || replacements.size === 0) return location;
		let result = location;
		for (const [target, replacement] of replacements) if (result.includes(target)) result = result.replaceAll(target, replacement);
		return result;
	};
	var getLocationString = (replyItem) => {
		const locationString = replyItem?.reply_control?.location;
		return preprocessLocation(locationString);
	};
	var Router = class {
		routes = [];
		serve(prefix, action, constrait = {}) {
			if (Array.isArray(prefix)) {
				prefix.forEach((p) => {
					this.routes.push({
						prefix: p,
						action,
						constrait
					});
				});
				return;
			}
			this.routes.push({
				prefix,
				action,
				constrait
			});
		}
		match(url) {
			for (const { prefix, action, constrait } of this.routes) {
				if (!url.startsWith(prefix)) continue;
				if (constrait.endsWith && !url.endsWith(constrait.endsWith)) continue;
				logger.info(`[Router] 匹配到路由: ${prefix}`, constrait.endsWith ? `(要求以 ${constrait.endsWith} 结尾)` : "");
				action(url);
				break;
			}
		}
	};
	var fromError = (error) => error instanceof Error ? error.message : String(error);
	var registerConfigMenus = () => {
		_GM_registerMenuCommand("配置文本替换", () => {
			const currentRules = JSON.stringify(Object.fromEntries(replacements), null, 2);
			const input = prompt("请输入新的位置替换规则（JSON格式的键值对，例如 {\"旧字符串\": \"新字符串\"}）：", currentRules);
			if (!input) return;
			try {
				const parsed = JSON.parse(input);
				if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) throw new Error("必须是键值对对象格式");
			} catch (error) {
				alert(`JSON 格式错误：${fromError(error)}`);
				return;
			}
			_GM.setValue(REPLACEMENTS_KEY, input).then(() => {
				location.reload();
			}).catch((error) => {
				alert(`更新替换规则失败：${fromError(error)}`);
			});
		});
		_GM_registerMenuCommand(isDebugMode ? "🟢 关闭调试模式" : "开启调试模式", () => {
			_GM_setValue(DEBUG_MODE_KEY, !isDebugMode);
			location.reload();
		});
		if (isDebugMode) updateLogMenu();
	};
	var fetchArticleViewInfo = async (cv) => {
		try {
			const { data } = await (await fetch(`https://api.bilibili.com/x/article/viewinfo?id=${cv}`, { credentials: "include" })).json();
			return data;
		} catch (error) {
			logger.error("获取文章 IP 属地失败：", error);
			return;
		}
	};
	var opusLocationObserver;
	var serveNewOpusArticle = async (initialState) => {
		const basic = initialState?.detail?.basic;
		if (!basic?.rid_str || basic.article_type !== 0) return;
		const viewinfo = await fetchArticleViewInfo(basic.rid_str);
		if (!viewinfo?.location) {
			logger.warn(`[IP属地解析] 新版专栏 (opus) 未携带 IP 数据 (cv: ${basic.rid_str})`);
			return;
		}
		const location = viewinfo.location;
		const insertLocation = () => {
			const currentAuthorPub = document.querySelector(".opus-module-author__pub");
			if (!currentAuthorPub) return;
			const text = `${location} ·\u00a0`;
			const existingLocation = currentAuthorPub.querySelector(".opus-module-author__pub__bilireveal");
			if (existingLocation) {
				if (existingLocation.textContent !== text) existingLocation.textContent = text;
				return;
			}
			logger.incrementIpCount();
			const locationEl = document.createElement("span");
			locationEl.textContent = text;
			locationEl.className = "opus-module-author__pub__bilireveal";
			currentAuthorPub.insertAdjacentElement("afterbegin", locationEl);
		};
		opusLocationObserver?.disconnect();
		opusLocationObserver = new MutationObserver(insertLocation);
		opusLocationObserver.observe(document, {
			childList: true,
			subtree: true
		});
		insertLocation();
	};
	var injectArticleLocation = async (url) => {
		const match = url.match(/\/cv(\d+)/);
		const cv = match ? match[1] : void 0;
		if (!cv) {
			if (_unsafeWindow.__INITIAL_STATE__) {
				serveNewOpusArticle(_unsafeWindow.__INITIAL_STATE__);
				return;
			}
			let initialState;
			Object.defineProperty(_unsafeWindow, "__INITIAL_STATE__", {
				get: () => initialState,
				set: (value) => {
					initialState = value;
					serveNewOpusArticle(initialState);
				},
				configurable: true
			});
			return;
		}
		const viewinfo = await fetchArticleViewInfo(cv);
		if (!viewinfo?.location) {
			logger.warn(`[IP属地解析] 专栏文章 未携带 IP 数据 (cv: ${cv})`);
			return;
		}
		const publishText = (await isElementLoaded(".article-detail"))?.querySelector(".publish-text");
		if (!publishText) return;
		if (publishText.parentElement?.querySelector(".article-location-bilireveal")) return;
		logger.incrementIpCount();
		const locationEl = document.createElement("span");
		locationEl.textContent = `${viewinfo.location} · `;
		locationEl.className = "article-location-bilireveal";
		publishText.insertAdjacentElement("afterend", locationEl);
	};
	var updateLocationElement = (thisArg) => {
		const pubDateEl = thisArg.shadowRoot.querySelector("#pubdate");
		if (!pubDateEl) return;
		let locationEl = thisArg.shadowRoot.querySelector("#location");
		const locationString = getLocationString(thisArg.data);
		if (!locationString) {
			logger.warn("[IP属地解析] lit-component 未携带 IP 数据 (解析为空)");
			if (locationEl) locationEl.remove();
			return;
		}
		if (locationEl) {
			locationEl.textContent = locationString;
			return;
		}
		logger.incrementIpCount();
		locationEl = document.createElement("div");
		locationEl.id = "location";
		locationEl.textContent = locationString;
		pubDateEl.insertAdjacentElement("afterend", locationEl);
	};
	var createPatch = (ActionButtonsRender) => {
		const applyHandler = (target, thisArg, args) => {
			const result = Reflect.apply(target, thisArg, args);
			try {
				updateLocationElement(thisArg);
			} catch (error) {
				logger.error("[Hook异常] lit-component 处理失败", error);
			}
			return result;
		};
		ActionButtonsRender.prototype.update = new Proxy(ActionButtonsRender.prototype.update, { apply: applyHandler });
		return ActionButtonsRender;
	};
	var hookLit = () => {
		logger.info("[Strategy] 启用 hookLit (Web Components)");
		const { define: originalDefine } = _unsafeWindow.customElements;
		const applyHandler = (target, thisArg, args) => {
			const [name, classConstructor, ...rest] = args;
			if (typeof classConstructor !== "function" || name !== "bili-comment-action-buttons-renderer") return Reflect.apply(target, thisArg, args);
			const PatchActionButtonsRender = createPatch(classConstructor);
			return Reflect.apply(target, thisArg, [
				name,
				PatchActionButtonsRender,
				...rest
			]);
		};
		_unsafeWindow.customElements.define = new Proxy(originalDefine, { apply: applyHandler });
	};
	var injectBBComment = (bbComment, { variation } = { variation: false }) => {
		const { _createListCon: createListCon, _createSubReplyItem: createSubReplyItem } = bbComment.prototype;
		const applyHandler = (target, thisArg, args) => {
			const [item] = args;
			const result = Reflect.apply(target, thisArg, args);
			try {
				const replyTimeRegex = /<span class="reply-time">(.*?)<\/span>/;
				const location = getLocationString(item);
				if (!location) {
					logger.warn("[IP属地解析] vue-legacy 未携带 IP 数据 (解析为空)");
					return result;
				}
				logger.incrementIpCount();
				if (variation) return result.replace(/<span class="time">(.*?)<\/span>/, `<span class="time">$1&nbsp;&nbsp;${location}</span>`);
				return result.replace(replyTimeRegex, `<span class="reply-time">$1</span><span class="reply-location">${location}</span>`);
			} catch (error) {
				logger.error("[Hook异常] vue-legacy 处理失败", error, `(rpid=${item?.rpid}, hasLocation=${!!item?.reply_control?.location})`);
				return result;
			}
		};
		bbComment.prototype._createListCon = new Proxy(createListCon, { apply: applyHandler });
		bbComment.prototype._createSubReplyItem = new Proxy(createSubReplyItem, { apply: applyHandler });
	};
	var hookBBComment = ({ variation } = { variation: false }) => {
		logger.info("[Strategy] 启用 hookBBComment", variation ? "(变体)" : "");
		if (_unsafeWindow.bbComment) {
			injectBBComment(_unsafeWindow.bbComment, { variation });
			return;
		}
		let bbComment;
		Object.defineProperty(_unsafeWindow, "bbComment", {
			get: () => bbComment,
			set: (value) => {
				bbComment = value;
				injectBBComment(value, { variation });
			},
			configurable: true
		});
	};
	var realProxy = _unsafeWindow.Proxy;
	var vueUnhooked = new WeakSet();
	var vueHooked = new WeakMap();
	var watchedVNodes = new WeakSet();
	var watchedApps = new WeakSet();
	var isProxyHookInstalled = false;
	var isVueApp = (value) => {
		if (!value || typeof value !== "object") return false;
		const app = value;
		return typeof app.uid === "number" && app.uid >= 0 && !!app.vnode;
	};
	var handleVueApp = (app) => {
		const el = app.vnode.el;
		if (el) {
			recordVue(el, app);
			recordDOM(el, app);
			watchIsUnmounted(app);
			return;
		}
		vueUnhooked.add(app);
		watchEl(app.vnode);
	};
	var watchEl = (vnode) => {
		if (watchedVNodes.has(vnode)) return;
		watchedVNodes.add(vnode);
		let value = vnode.el;
		let hooked = false;
		Object.defineProperty(vnode, "el", {
			configurable: true,
			enumerable: true,
			get() {
				return value;
			},
			set(newValue) {
				value = newValue;
				const component = this.component;
				if (!hooked && newValue && component) {
					hooked = true;
					recordVue(newValue, component);
					recordDOM(newValue, component);
					watchIsUnmounted(component);
				}
			}
		});
	};
	var watchIsUnmounted = (app) => {
		if (watchedApps.has(app)) return;
		watchedApps.add(app);
		let value = app.isUnmounted;
		let unhooked = false;
		Object.defineProperty(app, "isUnmounted", {
			configurable: true,
			enumerable: true,
			get() {
				return value;
			},
			set(newValue) {
				value = newValue;
				if (!unhooked && this.isUnmounted) {
					unhooked = true;
					cleanupAppReference(this);
				}
			}
		});
	};
	var cleanupAppReference = (app) => {
		const el = app.vnode.el;
		if (!el) return;
		const domValue = el.__vue__;
		const nextDomValue = removeAppFromRecord(domValue, app);
		if (nextDomValue === void 0) el.__vue__ = void 0;
		else el.__vue__ = nextDomValue;
		const nextMapValue = removeAppFromRecord(vueHooked.get(el), app);
		if (nextMapValue === void 0) vueHooked.delete(el);
		else vueHooked.set(el, nextMapValue);
	};
	var removeAppFromRecord = (record, app) => {
		if (!record) return void 0;
		if (!Array.isArray(record)) return record === app ? void 0 : record;
		const next = record.filter((item) => item !== app);
		if (next.length === 0) return void 0;
		return next.length === 1 ? next[0] : next;
	};
	var appendAppToRecord = (record, app) => {
		if (!record) return app;
		if (!Array.isArray(record)) return record === app ? record : [record, app];
		return record.includes(app) ? record : [...record, app];
	};
	var recordVue = (el, app) => {
		vueUnhooked.delete(app);
		vueHooked.set(el, appendAppToRecord(vueHooked.get(el), app));
	};
	var recordDOM = (el, app) => {
		el.__vue__ = appendAppToRecord(el.__vue__, app);
	};
	var proxyInterceptor = new Proxy(realProxy, { construct: (target, args, newTarget) => {
		const app = args[0]?._;
		if (isVueApp(app)) handleVueApp(app);
		return Reflect.construct(target, args, newTarget);
	} });
	var hookVue3App = () => {
		if (isProxyHookInstalled) return;
		_unsafeWindow.Proxy = proxyInterceptor;
		isProxyHookInstalled = true;
	};
	var extractLocationFromReplyElement = (replyItemEl) => {
		let replyElement;
		let locationString;
		if (replyItemEl.className.startsWith("sub")) {
			replyElement = replyItemEl;
			locationString = getLocationString(replyElement?.__vue__.vnode.props.subReply);
		} else {
			replyElement = replyItemEl;
			locationString = getLocationString(replyElement?.__vue__.vnode.props.reply);
		}
		return locationString;
	};
	var hasLocationInjected = (replyInfo) => replyInfo.children.length !== 0 && replyInfo.children[0].innerHTML.includes("IP属地");
	var insertLocation = (replyItemEl) => {
		const replyInfo = replyItemEl.className.startsWith("sub") ? replyItemEl.querySelector(".sub-reply-info") : replyItemEl.querySelector(".reply-info");
		if (!replyInfo) throw new Error("Can not detect reply info");
		const locationString = extractLocationFromReplyElement(replyItemEl);
		if (!locationString) {
			logger.warn("[IP属地解析] vue3 未携带 IP 数据 (解析为空)");
			return;
		}
		if (hasLocationInjected(replyInfo)) return;
		logger.incrementIpCount();
		replyInfo.children[0].innerHTML += `&nbsp;&nbsp;${locationString}`;
	};
	var isReplyItem = (el) => el instanceof HTMLDivElement && ["reply-item", "sub-reply-item"].includes(el.className);
	var observeAndInjectComments = async (root) => {
		logger.info("[Strategy] 启用 observeAndInjectComments (Vue3)");
		hookVue3App();
		const targetNode = await isElementLoaded(".reply-list", root);
		new MutationObserver((mutationsList) => {
			for (const mutation of mutationsList) {
				if (mutation.type !== "childList") continue;
				mutation.addedNodes.forEach((node) => {
					if (!isReplyItem(node)) return;
					try {
						insertLocation(node);
						if (node.className.startsWith("sub")) return;
						const subReplyListEl = node.querySelector(".sub-reply-list");
						if (!subReplyListEl) return;
						const subReplyList = Array.from(subReplyListEl.children);
						subReplyList.pop();
						subReplyList.forEach(insertLocation);
					} catch (error) {
						logger.error("[Hook异常] observeAndInjectComments (Vue3) 处理失败", error);
					}
				});
			}
		}).observe(targetNode, {
			childList: true,
			subtree: true
		});
	};
	var handleOpusRoute = async (url) => {
		logger.info("[handleOpusRoute] 处理新版专栏:", url);
		hookLit();
		injectArticleLocation(url);
	};
	var handleSpaceHomeRoute = async () => {
		const isFreshSpace = (await isElementLoaded("#biliMainHeader"))?.tagName === "HEADER";
		logger.info("[handleSpaceHomeRoute] 是否新版空间:", isFreshSpace);
		(await isElementLoaded(isFreshSpace ? ".nav-tab__item:nth-child(2)" : ".n-dynamic")).addEventListener("click", hookLit, { once: true });
	};
	var handleDynamicHomeRoute = () => {
		logger.info("[handleDynamicHomeRoute] 挂接新旧版动态评论组件");
		hookLit();
		hookBBComment();
	};
	var handleDynamicItemRoute = async () => {
		const isNewDyn = !(await isElementLoaded(".bili-dyn-item")).querySelector(".bili-dyn-item__footer");
		logger.info("[handleDynamicItemRoute] 动态详情页是否新版:", isNewDyn);
		if (isNewDyn) hookLit();
		else hookBBComment();
	};
	var registerRoutes = (router) => {
		router.serve([
			"https://www.bilibili.com/video/",
			"https://www.bilibili.com/list/",
			"https://www.bilibili.com/bangumi/play/",
			"https://www.bilibili.com/cheese/play/",
			"https://www.bilibili.com/v/topic/detail",
			"https://manga.bilibili.com/detail/",
			"https://www.bilibili.com/festival/",
			"https://live.bilibili.com/"
		], hookLit);
		router.serve("https://www.bilibili.com/blackboard/feed-topic.html", () => hookBBComment());
		router.serve("https://www.bilibili.com/blackboard/", () => {
			hookBBComment({ variation: true });
			observeAndInjectComments();
		});
		router.serve(["https://www.bilibili.com/read/", "https://www.bilibili.com/opus/"], handleOpusRoute);
		router.serve("https://space.bilibili.com/", hookLit, { endsWith: "dynamic" });
		router.serve("https://space.bilibili.com/", handleSpaceHomeRoute);
		router.serve("https://t.bilibili.com/", handleDynamicHomeRoute, { endsWith: "/" });
		router.serve("https://t.bilibili.com/", handleDynamicItemRoute);
		router.serve("https://www.bilibili.com/blackroom/ban/", () => hookBBComment({ variation: true }));
	};
	var localePrefix = new RegExp(`^/(?:${[
		"zh-Hans",
		"zh-Hant",
		"en",
		"ja",
		"th",
		"ar",
		"pt",
		"es",
		"id",
		"ms",
		"ru",
		"tr",
		"vi"
	].join("|")})(?=/|$)`);
	var stripLocalePrefix = (pathname) => pathname.replace(localePrefix, "") || "/";
	var router = new Router();
	registerRoutes(router);
	var { origin, pathname } = new URL(location.href);
	var urlWithoutQueryOrHash = `${origin}${stripLocalePrefix(pathname)}`;
	router.match(urlWithoutQueryOrHash);
	registerConfigMenus();
})();

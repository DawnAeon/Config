// ==UserScript==
// @name         Grok.com - Wider & Better Layout
// @namespace    https://github.com/yourname
// @version      1.4
// @description  Makes grok.x.ai (Grok.com) use a much wider layout – perfect for big monitors
// @author       Tutudid
// @match        https://grok.x.ai/*
// @match        https://grok.com/*
// @grant        none
// @run-at       document-start
// @downloadURL https://update.greasyfork.org/scripts/567661/Grokcom%20-%20Wider%20%20Better%20Layout.user.js
// @updateURL https://update.greasyfork.org/scripts/567661/Grokcom%20-%20Wider%20%20Better%20Layout.meta.js
// ==/UserScript==

(function () {
    'use strict';

    const style = document.createElement('style');
    style.textContent = `
        /* === WIDER GROK LAYOUT === */

        /* Main container - remove max-width limits */
        div[class*="mx-auto"] {
            max-width: none !important;
            width: 95% !important;
            max-width: 1600px !important;
        }

        /* Chat area - make it wider */
        main,
        div[class*="flex col"],
        div[class*="w-full"][class*="max-w-"],
        div[data-testid="conversation-turn"] > div {
            max-width: none !important;
        }

        /* Message bubbles - allow them to grow wider */
        div[class*="prose"] {
            max-width: 100% !important;
        }

        /* The actual message content container */
        div[class*="break-words"] {
            max-width: 100% !important;
        }

        /* Center the entire page content nicely */
        body > div */
        body > div:first-child,
        div[class*="min-h-screen"] {
            max-width: none !important;
            padding-left: 2rem !important;
            padding-right: 2rem !important;
        }

        /* Optional: make the input box wider too */
        textarea, div[contenteditable="true"] {
            max-width: 100% !important;
        }

        /* Keep sidebar visible and give it fixed width */
        aside {
            min-width: 260px !important;
            max-width: 260px !important;
        }

        /* Main chat flex container - give chat more space */
        div[class*="flex-1"] {
            flex: 1 1 1000px !important;
        }

        /* Responsive fallback for smaller screens */
        @media (max-width: 1400px) {
            body > div:first-child,
            div[class*="min-h-screen"] {
                padding-left: 1rem !important;
                padding-right: 1rem !important;
            }
        }
    `;

    document.head.appendChild(style);

    // Re-inject style on dynamic page changes (Grok is a SPA)
    const observer = new MutationObserver(() => {
        if (!document.head.querySelector('#grok-wider-layout-style')) {
            style.id = 'grok-wider-layout-style';
            document.head.appendChild(style);
        }
    });

    observer.observe(document.documentElement, {
        childList: true,
        subtree: true
    });

    console.log('✨ Grok.com wider layout activated – enjoy the extra space!');
})();